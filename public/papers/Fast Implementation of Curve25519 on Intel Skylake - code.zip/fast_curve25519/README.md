# Advanced Systems Lab

```
    _________   _____________________  ____  ______   ___   ____ 
   / ____/   | / ___/_  __/ ____/ __ \/ __ \/ ____/  |__ \ / __ \
  / /_  / /| | \__ \ / / / /   / / / / / / / __/     __/ // / / /
 / __/ / ___ |___/ // / / /___/ /_/ / /_/ / /___    / __// /_/ / 
/_/   /_/  |_/____//_/  \____/\____/_____/_____/   /____/\____/  
```

## Benchmarking

Use `benchmark.sh` to build and run benchmarks and validate implementations.

```
./benchmark.sh build    # build benchmarks
./benchmark.sh validate # run tests
./benchmark.sh run      # run benchmarks
./benchmark.sh          # build, validate, run
./benchmark.sh clean    # clean up build output
```

Create the file `benchmark.sh.implementations.local` using
`benchmark.sh.implementations` as a template to benchmark only selected
implementations.

### Compiler flags

The benchmarked sets of compiler flags are defined in `src/benchmark.sh`.
Different flags can be simply added there, the benchmarks will be built for all
defined sets of flags automatically.

## Adding an implementation

- Create a new directory in `src/`.
- Include `crypto_scalarmult.h` and implement its functions.
- Add the implementation to the corresponding array in `src/benchmark.sh`.

## Optimization projects

| name | description | | |
| ------ | ------ | ------ | ------ |
| AVX2 32-bit | use vector intrinsics in basic implementation like sandy2x paper | phil | ongoing |
| AVX2 64-bit | 64 bit multiplication built in AVX2 [See this Stackoverflow post](https://stackoverflow.com/questions/28807341/simd-signed-with-unsigned-multiplication-for-64-bit-64-bit-to-128-bit), [or this](https://stackoverflow.com/questions/17863411/sse-multiplication-of-2-64-bit-integers). (It looks difficult, but there seem to be cases when this is better than simple `mulx`. E.g. how can the reduction be incorporated?) | fab | ongoing |
| AVX2 FMA | Find a way to represent the field using 64-bit doubles and make use of FMAs | luk | ongoing |
| Multiplication | Speed up the multiplication with different multiplication algorithms [bernsteins' list](https://cr.yp.to/papers/m3.pdf), [vector instructions for modular exponentiation](https://link.springer.com/chapter/10.1007/978-3-642-31662-3_9) | flo | ongoing |

further project ideas:
- use [extended precision](https://en.wikipedia.org/wiki/Extended_precision) libraries such as [libquadmath](https://gcc.gnu.org/onlinedocs/libquadmath/) and [gmp](https://gmplib.org/)
- avoid carry operations by using datatypes with more space left

## Implementations

| folder | based on | target | cycles |
| ------ | -------- | ------ | - |
| `64bit_51` | `supercop/amd64-51` | implement radix51 (5 limbs) on int64 | 197724 | 
| `64bit_51_mul_naive` | `64bit_51` | naive multiplication instead of schoolbook method | 210842 | 
| `basic` | [go](https://godoc.org/golang.org/x/crypto/curve25519) | implement radix 25.5 (10 limbs) on int32 | 306492 |
| `fast_double/avx2` | `ref10`, `athlon` | Radix 21.25 (12 limb) implementation on doubles (vectorized) | - |
| `fast_double/scalar` | `ref10`, `athlon` | Radix 21.25 (12 limb) implementation on doubles (scalar) | 450610 |
| `generic/any_radix` | `generic/integral_radix` | to compare effects of radix / data types on runtime. supports any radix which is an exact multiple of 255 | 45000 |
| `generic/any_radix_codegeneration` | `generic/any_radix` | generates code instead of loops. uses [cog](https://github.com/nedbat/cog). | 22000 |
| `generic/integral_radix` | `64bit_51` | to compare effects of radix / data types on runtime. supports any whole-number radix | 26000 |
| `multiplication/karatsuba` | `64bit_51` | use Karatsuba [complexity](http://cr.yp.to/papers/m3.pdf) [paper](https://img.chainnews.com/paper/b571f7bd5c3397a9c04b2702c8f759b7.pdf) [improvement](https://link.springer.com/content/pdf/10.1007/978-3-662-44709-3_18.pdf) | 209330 |
| `multiplication/naive` | `64bit_51` | multiply each limb with each other limb and sum up. at the end, take the modul from the high-order limbs and add them to the lower limbs | 202354 |
| `multiplication/schoolbook` | `64bit_51` | multiply each limb with each other limb and sum up. fuse modulo operations within the normal muliplication (exact same implementation as `64bit_51`) | 194452 |
| `multiplication/toom_cook` | `64bit_51` | use Toom Cook algorithm [explanation](http://cs.indstate.edu/~syedugani/ToomCook.pdf) [performance](http://www.bodrato.it/software/toom.html) [gmp-three-way](ftp://ftp.gnu.org/old-gnu/Manuals/gmp/html_node/Toom-Cook-3-Way-Multiplication.html) | >159924 |
| `supercop/amd64-51` | | Reference (assembly) implementation for radix51, using the scalar 64-bit multiplier. | 127136 |
| `supercop/ref10` | | Reference (C) implementation for radix25.5, using the scalar 32-bit multiplier. | 278770 |
| `supercop/ref` | | Reference implementation for radix10 (slow) | 3447222 |
| `supercop/sandy2x` | | Reference (assembly) implementation for radix25.5, using AVX. Designed for Sandy Bridge. | 120768 |

_cycles measured on `Intel(R) Core(TM) i7-6700 CPU @ 3.40GHz` with `gcc version 9.3.0 (Arch Linux 9.3.0-1)` and flags `-O3 -mavx2 -mfma -fomit-frame-pointer -funroll-loops -flto=0`._


## References

- Bernsteins paper: https://cr.yp.to/ecdh/curve25519-20060209.pdf
- RFC 7748: https://tools.ietf.org/html/rfc7748
- C# implementation: https://github.com/hanswolff/curve25519
- js implementation: https://github.com/indutny/elliptic
- go implementation: https://godoc.org/golang.org/x/crypto/curve25519
- SUPERCOP benchmarks: https://bench.cr.yp.to/impl-scalarmult/curve25519.html
- SUPERCOP scalarmult: https://bench.cr.yp.to/primitives-scalarmult.html
- SUPERCOP sources: https://github.com/floodyberry/supercop
- sandy2x paper: https://tungchou.github.io/papers/sandy2x.pdf
- Brazilian avx2 paper: https://burstwiki.org/media/15xxxx-BURST_25519_avx2.pdf
- Useful floating point arithmetic: https://cr.yp.to/antiforgery/hash127-20040918.pdf

## Notes from lecture

As mentioned in the lecture:

- Performance plots should always be made with the ceiling; difference should
  be explainable
- At first, only consider actual computations (no index computations)
- If possible, include index computations too so the roof decreases

## Installing vtune (Arch Linux)

Download installer from https://dynamicinstaller.intel.com/system-studio/download.
