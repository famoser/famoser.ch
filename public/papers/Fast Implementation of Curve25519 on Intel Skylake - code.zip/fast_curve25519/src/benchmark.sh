#!/usr/bin/env bash

shopt -s nullglob
esc_red="\e[1;31m"
esc_green="\e[1;32m"
esc_blue="\e[1;34m"
esc_reset="\e[0m"

# rumber of benchmark runs, default to 10000
n_runs=${BENCHMARK_RUNS:-10000}

include_dir=include
build_dir=build/benchmarks
test_dir=build/tests
profile_dir=build/profile

# create directories that don't exist
[[ -d $build_dir ]] || mkdir -p $build_dir
[[ -d $test_dir ]] || mkdir -p $test_dir
[[ -d $profile_dir ]] || mkdir -p $profile_dir

compiler=gcc

# csv output for benchmark results
benchmark_log="benchmark.csv"

# put all implementations into this file
implementations_file=./benchmark.sh.implementations

# create a ./benchmark.sh.implementations.local to test a subset of
# implementations
if [[ -f "${implementations_file}.local" ]]; then
    implementations_file="${implementations_file}.local"
fi
readarray -t implementations < "${implementations_file}"

cflags_common="-std=c99 -ggdb3 -Wall -Wextra -march=native -lm"
if [[ $compiler == "icc" ]]; then
    cflags_common+=" -no-inline-max-size -no-inline-max-total-size"
fi

# all benchmarks will be built with all the flags in the list
cflags_list=(
    "-O3 -fno-tree-vectorize"
    "-O3 -mavx2 -mfma"
    # "-O0"
    # "-O3 -mavx2 -mfma -fomit-frame-pointer"
    # "-O3 -mavx2 -mfma -funroll-loops"
    # "-O3 -mavx2 -mfma -flto"
    # "-O3 -mavx2 -mfma -fomit-frame-pointer -funroll-loops -flto"
)

# special case cflags for compiling the supercop/athlon implementation.
cflags_athlon='-m32 -fpie'

# the compiler flag set used for profiling
profile_flags=2

print_cpuinfo() {
    cpu=$(lscpu | grep 'Model name' | sed 's/^Model name:\s*//')

    sse4=no
    avx=no
    avx2=no
    cat /proc/cpuinfo | grep -o 'sse4' > /dev/null && sse4=yes
    cat /proc/cpuinfo | grep -o 'avx' > /dev/null && avx=yes
    cat /proc/cpuinfo | grep -o 'avx2' > /dev/null && avx2=yes

    turbo=yes
    if [[ $(cat /sys/devices/system/cpu/intel_pstate/no_turbo) == 1 ]]; then
        turbo=no
    fi

    l1="$(( $(getconf LEVEL1_DCACHE_SIZE) / 1024 )) KB"
    l2="$(( $(getconf LEVEL2_CACHE_SIZE) / 1024 )) KB"
    l3="$(( $(getconf LEVEL3_CACHE_SIZE) / 1024 )) KB"

    printf "$cpu\n"
    printf "L1: $l1, L2: $l2, L3: $l3\n"
    printf "sse4: $sse4 | avx: $avx | avx2: $avx2\n"
    printf "Turbo Boost enabled: $turbo\n"
}

clean() {
    rm $build_dir/* 2>/dev/null
    rm $test_dir/* 2>/dev/null
    rm $profile_dir/* 2>/dev/null
}

validate_implementations() {
    printf "${esc_blue}Validating implementations${esc_reset}:\n"
    for impl in "${implementations[@]}"; do
        if [[ $impl == 'supercop/athlon' ]]; then
            # can't validate supercop/athlon, because we don't have
            # 32-bit cmocka
            printf "${esc_green}%-22s${esc_reset}$impl ($test_dir/$out)\n" \
                'assume correct:'
            continue
        fi

        out="$(tr '/' '_' <<< "$impl")""_test"
        $compiler $cflags_common -O0 -ggdb3 -fsanitize=address \
            -I$include_dir \
            -lcmocka \
            validate.c $impl/*.{s,S,c} \
            -o $test_dir/$out

        log_file=$test_dir/$out.log
        $test_dir/$out > $log_file 2>&1
        if [[ $(grep 'ERROR' $log_file) ]]; then
            printf "${esc_red}%-22s${esc_reset}$impl ($test_dir/$out)\n" \
                'validation failed:'
            # exit 0
        else
            printf "${esc_green}%-22s${esc_reset}$impl ($test_dir/$out)\n" \
                'validation succeeded:'
        fi
    done
}

build_benchmarks() {
    i=0
    printf "${esc_blue}Building benchmarks${esc_reset}:\n"
    for cflags in "${cflags_list[@]}"; do
        printf "cflags_$i: $cflags\n"
        ((i++))
    done

    for impl in "${implementations[@]}"; do
        cflags_special=''
        if [[ $impl == 'supercop/athlon' ]]; then
            cflags_special="$cflags_athlon"
        fi

        i=0
        for cflags in "${cflags_list[@]}"; do
            out="$(tr '/' '_' <<< "$impl")_cflags_$i"
            # echo "building: $out ($cflags)"
            $compiler $cflags_special $cflags_common $cflags \
                -I$include_dir \
                benchmark.c $impl/*.{s,S,c} \
                -o $build_dir/$out
                # -o $build_dir/$out \
                # >/dev/null 2>&1
            ((i++))
        done
    done
}

run_benchmarks() {
    printf "${esc_blue}Running benchmarks (n=$n_runs):${esc_reset}\n"
    print_cpuinfo
    echo
    printf '' > $benchmark_log
    for binary in $build_dir/*; do
        cycles=$($binary $n_runs)
        if [[ $? == 139 ]]; then
            cycles='segfault'
        fi
        bname=$(basename "$binary")
        impl=$(sed 's/_cflags_.*//' <<< "$bname")
        printf "$impl,$bname,$cycles\n" >> $benchmark_log
    done

    # print data to console
    cat $benchmark_log | column \
        --separator ',' \
        --table \
        --table-right 'Cycles' \
        --table-columns 'Implementation,Flag variant,Cycles'
}

profile() {
    printf "${esc_blue}Profiling benchmarks:${esc_reset}\n"
    printf "building benchmarks ...\n"
    clean
    build_benchmarks >/dev/null
    echo

    for binary in $build_dir/*cflags_$profile_flags; do
        printf "profiling $binary ...\n"
        bname=$(basename "$binary")
        out="$profile_dir/$bname.profile"
        valgrind \
            --tool=callgrind \
            --callgrind-out-file="$out" \
            --dump-instr=yes \
            --collect-jumps=yes \
            "$binary" 1000

        callgrind_annotate \
            --show-percs=yes \
            $out

        echo
    done
}

build_and_run() {
    clean
    validate_implementations
    echo
    build_benchmarks
    echo
    run_benchmarks
}

all_compilers() {
    implementations=('fast_int/avx2_all' 'fast_double/avx2_all' 'supercop/amd64-51' 'supercop/sandy2x')
    cflags_list=("-O3 -mavx2 -mfma")

    ccs=( 'gcc' 'icc' 'clang' )
    for cc in "${ccs[@]}"; do
        printf "${esc_red}RUNNING FOR COMPILER: ${cc}${esc_reset}\n"
        compiler="$cc"
        benchmark_log="benchmark-$compiler.csv"
        cflags_common="-std=c99 -ggdb3 -Wall -Wextra -march=native"
        if [[ $compiler == "icc" ]]; then
            cflags_common+=" -no-inline-max-size -no-inline-max-total-size"
        fi
        build_and_run
        echo
    done
}

all_radixes() {
    cflags_list=("-O3 -mavx2 -mfma")
    cflags_common="-std=c99 -march=native"
    implementations=('generic/any_radix_codegeneration')
    
    algos=('51' '42.5' '36.4285714285714' '31.875' '28.3333333333333' '25.5' '23.1818181818181' '21.25' '19.6153846153846' '18.2142857142857' '17' '15.9375' '15' '14.1666666666666' '13.4210526315789' '12.75' '12.1428571428571' '11.5909090909090' '11.0869565217391' '10.625' '10.2' '9.80769230769230' '9.44444444444444' '9.10714285714285' '8.79310344827586' '8.5')
    first_iter="1"
    for algo in "${algos[@]}"; do
        printf "${esc_red}RUNNING FOR RADIX: ${algo}${esc_reset}\n"
        config_arg="${algo}_schoolbook"
        cog -r -D config=$config_arg ./generic/any_radix_codegeneration/curve25519_basic.c
        benchmark_log="benchmark-generic_$config_arg.csv"
        build_and_run

        ops_file=./generic/any_radix_codegeneration/ops.csv
        readarray -t ops_content < "${ops_file}"
        if [[ $first_iter == "1" ]]; then
            printf "radix,algorithm,compiler_flags,cycles,${ops_content[0]}\n" > benchmark-generic.csv
            first_iter="0"
        fi

        readarray -t benchmark_results < "${benchmark_log}"
        for row in "${benchmark_results[@]}"; do
            printf "${algo},${row}," >> benchmark-generic.csv
            printf "${ops_content[1]}\n" >> benchmark-generic.csv
        done

        rm $benchmark_log

        echo
    done

    cog -r ./generic/any_radix_codegeneration/curve25519_basic.c
}

all_multiplications() {
    cflags_list=("-O3 -mavx2 -mfma")
    cflags_common="-std=c99 -march=native"
    implementations=('generic/any_radix_codegeneration')
    
    radixes=('51' '17' '15')
    multiplications=('naive' 'schoolbook' 'karatsuba')
    first_iter="1"
    for radix in "${radixes[@]}"; do
        for multiplication in "${multiplications[@]}"; do
            printf "${esc_red}RUNNING FOR RADIX ${radix} with ${multiplication}${esc_reset}\n"
            config_arg="${radix}_${multiplication}"
            cog -r -D config=$config_arg ./generic/any_radix_codegeneration/curve25519_basic.c
            benchmark_log="benchmark-generic_$config_arg.csv"
            build_and_run

            ops_file=./generic/any_radix_codegeneration/ops.csv
            readarray -t ops_content < "${ops_file}"
            if [[ $first_iter == "1" ]]; then
                printf "radix,multiplication,algorithm,compiler_flags,cycles,${ops_content[0]}\n" > benchmark-multiplications.csv
                first_iter="0"
            fi

            readarray -t benchmark_results < "${benchmark_log}"
            for row in "${benchmark_results[@]}"; do
                printf "${radix},${multiplication},${row}," >> benchmark-multiplications.csv
                printf "${ops_content[1]}\n" >> benchmark-multiplications.csv
            done

            rm $benchmark_log

            echo
        done
    done

    cog -r ./generic/any_radix_codegeneration/curve25519_basic.c
}

case "$1" in
    build)         build_benchmarks ;;
    run)           run_benchmarks ;;
    validate)      clean; validate_implementations ;;
    profile)       profile ;;
    clean)         clean ;;
    all_compilers) all_compilers ;;
    all_radixes)   all_radixes ;;
    all_multiplications)   all_multiplications ;;
    '')            build_and_run ;;
    *)             echo "unknown command: $1" ;;
esac
