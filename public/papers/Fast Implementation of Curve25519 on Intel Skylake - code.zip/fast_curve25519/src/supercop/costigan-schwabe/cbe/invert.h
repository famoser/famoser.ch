/*
version 20090331
Peter Schwabe & Neil Costigan
Public domain.
*/

#ifndef INVERT_H
#define INVERT_h

void invert(vector unsigned int *, const vector unsigned int *);

#endif
