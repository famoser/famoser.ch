/*
version 20090331
Peter Schwabe & Neil Costigan
Public domain.
*/

#define CRYPTO_BYTES 32
#define CRYPTO_SCALARBYTES 32
