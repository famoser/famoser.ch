/*
version 20090331
Peter Schwabe & Neil Costigan
Public domain.
*/

#ifndef FROMRED_H
#define FROMRED_H

void fromred(unsigned char*, const vector unsigned int*);

#endif
