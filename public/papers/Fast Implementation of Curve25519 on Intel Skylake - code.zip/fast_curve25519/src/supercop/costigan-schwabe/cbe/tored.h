/*
version 20090331
Peter Schwabe & Neil Costigan
Public domain.
*/

#ifndef TORED_H
#define TORED_h

void tored(vector unsigned int*, const unsigned char*);

#endif
