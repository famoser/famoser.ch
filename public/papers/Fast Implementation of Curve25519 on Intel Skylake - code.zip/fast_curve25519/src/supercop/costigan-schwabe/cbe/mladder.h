/*
version 20090331
Peter Schwabe & Neil Costigan
Public domain.
*/

#ifndef MLADDER_H
#define MLADDER_H

void mladder(vector unsigned int*, unsigned char*, const vector unsigned int*);

#endif
