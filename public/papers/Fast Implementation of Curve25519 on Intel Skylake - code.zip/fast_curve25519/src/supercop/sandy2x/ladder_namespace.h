#ifndef LADDER_NAMESPACE_H
#define LADDER_NAMESPACE_H

#define  ladder  crypto_scalarmult_curve25519_sandy2x_ladder
#define _ladder _crypto_scalarmult_curve25519_sandy2x_ladder

#endif //ifndef LADDER_NAMESPACE_H

