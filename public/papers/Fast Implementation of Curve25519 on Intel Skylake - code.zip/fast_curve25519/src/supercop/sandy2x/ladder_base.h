#ifndef LADDER_BASE_H
#define LADDER_BASE_H

#include "fe.h"
#include "ladder_base_namespace.h"

extern void ladder_base(fe *, const unsigned char *);

#endif //ifndef LADDER_BASE_H

