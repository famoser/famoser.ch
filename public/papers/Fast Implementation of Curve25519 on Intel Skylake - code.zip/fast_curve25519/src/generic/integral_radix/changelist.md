# change list

various small changes on the code base that can be tried fast

compiler flags: `-O3 -mavx2 -mfma`

| name | description |  |
| ------ | ------ | ------ |
| generic | base case | 258132 |
| avoid carry array | in propgate carry, use single temp variable instead of array | 258258 (+) |