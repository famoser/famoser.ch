#define TOKENPASTE(x, y) x ## y

#define FIELD_PROPAGATE_CARRY(T) TOKENPASTE(field_propagate_carry_, T)


void FIELD_PROPAGATE_CARRY(LIMB_SOURCE_MUL_TYPE) (field_t dst, LIMB_SOURCE_MUL_TYPE mul_results[]) {
    LIMB_SOURCE_MUL_TYPE carry[LIMB_COUNT];

    int i = 0;
    for (; i < LIMB_COUNT-1; i++) {
        carry[i] = (mul_results[i] + ((field_entry_t)1 << (LIMB_BIT_COUNT-1))) >> LIMB_BIT_COUNT;
        mul_results[i] -= carry[i] << LIMB_BIT_COUNT;
        mul_results[i+1] += carry[i];
    }

    carry[i] = (mul_results[i] + ((field_entry_t)1 << (LIMB_BIT_COUNT-1))) >> LIMB_BIT_COUNT;
    mul_results[i] -= carry[i] << LIMB_BIT_COUNT;
    mul_results[0] += carry[i] * 19;

    carry[0] = (mul_results[0] + ((field_entry_t)1 << (LIMB_BIT_COUNT-1))) >> LIMB_BIT_COUNT;
    mul_results[0] -= carry[0] << LIMB_BIT_COUNT;
    mul_results[1] += carry[0];

    for (int i = 0; i < LIMB_COUNT; i++) {
        dst[i] = (field_entry_t)mul_results[i];
    }
}