# code generation

it uses the python library `cog`.

install dependencies with ```pip install -r requirements.pip```  
generate code with `cog -r curve25519_basic.c`  
remove generate code with `cog -xr curve25519_basic.c`

you can pass `-D config=51_naive` to decide radix 51 and algorithm naive