from algorithm.methods.representation import FieldRepresentation
from algorithm.methods.evaluation import OperationCount
import cog

def less_overflow(field: FieldRepresentation, dst, src, LIMB_SOURCE_MUL_TYPE):
    operationCount = OperationCount()

    cog.outl(f'{LIMB_SOURCE_MUL_TYPE} carry[{field.limb_count}];')

    # ops for loop only
    operationCount.add("<<", field.last_limb_index)
    operationCount.add(">>", field.last_limb_index)
    operationCount.add("-", field.last_limb_index)
    operationCount.add("+", 2*field.last_limb_index)

    for i in range(0, field.last_limb_index):
        cog.outl(f'carry[{i}] = ({src}[{i}] + ((field_entry_t){1 << field.limb_bit_count[i]-1})) >> {field.limb_bit_count[i]};')
        cog.outl(f'{src}[{i}] -= carry[{i}] << {field.limb_bit_count[i]};')
        cog.outl(f'{src}[{i+1}] += carry[{i}];')

    # ops for next two carry 
    operationCount.add("<<", 2)
    operationCount.add(">>", 2)
    operationCount.add("-", 2)
    operationCount.add("+", 4)
    operationCount.add("*")

    last_index = field.limb_count - 1
    cog.outl(f'carry[{last_index}] = ({src}[{last_index}] + ((field_entry_t){1 << field.limb_bit_count[last_index]-1})) >> {field.limb_bit_count[last_index]};')
    cog.outl(f'{src}[{last_index}] -= carry[{last_index}] << {field.limb_bit_count[last_index]};')
    cog.outl(f'{src}[0] += carry[{last_index}] * 19;')

    cog.outl(f'carry[0] = ({src}[0] + ((field_entry_t){1 << field.limb_bit_count[0]-1})) >> {field.limb_bit_count[0]};')
    cog.outl(f'{src}[0] -= carry[0] << {field.limb_bit_count[0]};')
    cog.outl(f'{src}[1] += carry[0];')

    cog.outl('')

    for i in range(0, field.limb_count):
        cog.outl(f'{dst}[{i}] = (field_entry_t){src}[{i}];')
    
    return operationCount


def naive(field: FieldRepresentation, dst, src, LIMB_SOURCE_MUL_TYPE):
    operationCount = OperationCount()

    # ops for loop only
    if LIMB_SOURCE_MUL_TYPE == "field_entry_mul_t":
        operationCount.add("++", field.limb_count+1)
        operationCount.add(">>>>", field.limb_count+1)
    else:
        operationCount.add("+", field.limb_count+1)
        operationCount.add(">>", field.limb_count+1)
    operationCount.add("&", field.limb_count+1)

    for i in range(0, field.last_limb_index):
        cog.outl(f'{src}[{i+1}] += {src}[{i}] >> {field.limb_bit_count[i]};')
        cog.outl(f'{src}[{i}] &= {(1<<field.limb_bit_count[i]) - 1};')

    last_index = field.limb_count - 1
    cog.outl(f'{src}[0] += ({src}[{last_index}] >> {field.limb_bit_count[last_index]}) * 19;')
    cog.outl(f'{src}[{last_index}] &= {(1<<field.limb_bit_count[last_index]) - 1};')

    cog.outl(f'{src}[1] += {src}[0] >> {field.limb_bit_count[0]};')
    cog.outl(f'{src}[0] &= {(1<<field.limb_bit_count[0]) - 1};')

    cog.outl('')

    for i in range(0, field.limb_count):
        cog.outl(f'{dst}[{i}] = (field_entry_t){src}[{i}];')
    
    return operationCount
