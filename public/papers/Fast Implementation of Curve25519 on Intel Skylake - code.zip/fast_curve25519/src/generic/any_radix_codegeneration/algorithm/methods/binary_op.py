import cog
from algorithm.methods.evaluation import OperationCount

def naive(op, count, dst, a, b):
    operationCount = OperationCount()
    operationCount.add(op, count)

    for i in range(0, count):
        cog.outl(f'{dst}[{i}] = {a}[{i}] {op} {b}[{i}];')

    return operationCount

def full_partial_naive(op, dst, dst_offset, a, a_offset, a_count, b, b_offset, b_count):
    operationCount = OperationCount()

    max_count = max(a_count, b_count)
    for i in range(0, max_count):
        out = f'{dst}[{dst_offset+i}] = '
        if i < a_count:
            out += f'{a}[{a_offset+i}]'
            if i < b_count:
                operationCount.add(op, 1)
                out += f' {op} '

        if i < b_count:
            out += f'{b}[{b_offset+i}]'
        

        cog.outl(f'{out};')

    return operationCount

def partial_naive(op, dst, dst_offset, a, b, ab_offset, ab_count):
    operationCount = OperationCount()
    operationCount.add(op, count)

    for i in range(0, ab_count):
        cog.outl(f'{dst}[{dst_offset+i}] = {a}[{ab_offset+i}] {op} {b}[{ab_offset+i}];')

    return operationCount

def self_naive(op, dst, dst_offset, a, a_offset, count):
    operationCount = OperationCount()
    operationCount.add(op, count)

    for i in range(0, count):
        cog.outl(f'{dst}[{dst_offset+i}] {op}= {a}[{a_offset+i}];')
    
    return operationCount
