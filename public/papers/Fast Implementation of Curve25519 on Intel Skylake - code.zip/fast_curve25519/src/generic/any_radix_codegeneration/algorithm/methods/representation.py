import math
from algorithm.methods.evaluation import OperationCount

class InputRepresentation:
    def __init__(self, total_bits = 255, limb_count = 32, limb_bit_count = 8):
        self.total_bits = total_bits
        self.limb_count = limb_count
        self.limb_bit_count = limb_bit_count

class FieldRepresentation:
    def __init__(self, radix, prime_power_of_two = 255, prime_power_of_two_offset = -19): 
        self.radix = radix
        self.prime_power_of_two = prime_power_of_two
        self.prime_power_of_two_offset = prime_power_of_two_offset

        self.limb_count = int(float(prime_power_of_two)/radix)
        self.last_limb_index = self.limb_count - 1

        self.__set_limb_bit_count()
        self.__set_limb_mul_collection()

    def __set_limb_bit_count(self):
        self.limb_bit_count = []
        previous_bit_count = 0
        for i in range(0, self.limb_count - 1):
            target_bit_count = math.ceil(self.radix*(i+1))
            self.limb_bit_count.insert(i, target_bit_count - previous_bit_count)
            previous_bit_count = target_bit_count

        self.limb_bit_count.insert(self.limb_count-1, self.prime_power_of_two - previous_bit_count)

    def __set_limb_mul_collection(self):
        source_limp_1_bit = 0
        self.limb_mul_collection = []
        for i in range(0, self.limb_count):
            source_limp_2_bit = 0
            target_limp_bit = source_limp_1_bit
            for j in range(0, self.limb_count):
                shift = (source_limp_1_bit + source_limp_2_bit - target_limp_bit) % 255
                self.limb_mul_collection.insert(i*self.limb_count+j, int(math.pow(2, shift)));

                target_limp_bit += self.limb_bit_count[(i+j) % self.limb_count]
                source_limp_2_bit += self.limb_bit_count[j]

            source_limp_1_bit += self.limb_bit_count[i]