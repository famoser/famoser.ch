from algorithm.naive import Naive

import algorithm.methods.mul as mul
import algorithm.methods.square as square

class Schoolbook(Naive):
    def __init__(self, RADIX):
        super().__init__(RADIX)
    
    def mul(self, dst, a, b):
        operationCount = mul.schoolbook(self.field_representation, dst, a, b)
        self.add_operation_count("mul", operationCount)
    
    def square(self, dst, src):
        operationCount = square.schoolbook(self.field_representation, dst, src)
        self.add_operation_count("square", operationCount)