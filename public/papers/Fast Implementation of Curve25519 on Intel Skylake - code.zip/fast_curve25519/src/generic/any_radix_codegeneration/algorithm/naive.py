from algorithm.methods.representation import InputRepresentation
from algorithm.methods.representation import FieldRepresentation
from algorithm.methods.evaluation import OperationCount

import cog
import json
from pathlib import Path
import algorithm.methods.add as add
import algorithm.methods.sub as sub
import algorithm.methods.mul as mul
import algorithm.methods.mul_a24 as mul_a24
import algorithm.methods.square as square
import algorithm.methods.propagate_carry as propagate_carry
import algorithm.methods.propagate_carry_pre_encode_point as propagate_carry_pre_encode_point 
import algorithm.methods.swap as swap
import algorithm.methods.encode_point as encode_point
import algorithm.methods.decode_point as decode_point

class Naive:
    def __init__(self, RADIX):
        self.input_representation = InputRepresentation()
        self.field_representation = FieldRepresentation(RADIX)
        self._operation_count = {}
    
    def typedefs(self):
        cog.outl(f'typedef input_t byte32_t[{self.input_representation.limb_count}];')
        cog.outl(f'typedef field_entry_t field_t[{self.field_representation.limb_count}];')
    
    def add(self, dst, a, b):
        operationCount = add.naive(self.field_representation, dst, a, b)
        self.add_operation_count("add", operationCount)
    
    def sub(self, dst, a, b):
        operationCount = sub.naive(self.field_representation, dst, a, b)
        self.add_operation_count("sub", operationCount)
    
    def mul(self, dst, a, b):
        operationCount = mul.naive(self.field_representation, dst, a, b)
        self.add_operation_count("mul", operationCount)
    
    def mul_a24(self, dst, src):
        operationCount = mul_a24.naive(self.field_representation, dst, src)
        self.add_operation_count("mul_a24", operationCount)
    
    def square(self, dst, src):
        operationCount = square.naive(self.field_representation, dst, src)
        self.add_operation_count("square", operationCount)

    def propagate_carry(self, dst, src, LIMB_SOURCE_MUL_TYPE):
        operationCount = propagate_carry.naive(self.field_representation, dst, src, LIMB_SOURCE_MUL_TYPE)
        self.add_operation_count(f'propagate_carry_{LIMB_SOURCE_MUL_TYPE}', operationCount)

    def propagate_carry_pre_encode_point(self, dst):
        operationCount = propagate_carry_pre_encode_point.naive(self.field_representation, dst)
        self.add_operation_count("propagate_carry_pre_encode_point", operationCount)

    def swap(self, decider, a, b):
        operationCount = swap.naive(self.field_representation, decider, a, b)
        self.add_operation_count("swap", operationCount)

    def encode_point(self, dst, src):
        operationCount = encode_point.naive(self.field_representation, self.input_representation, dst, src)
        self.add_operation_count("encode_point", operationCount)

    def decode_point(self, dst, src):
        operationCount = decode_point.naive(self.field_representation, self.input_representation, dst, src)
        self.add_operation_count("decode_point", operationCount)
    
    def add_operation_count(self, name, operation_count):
        if operation_count is None:
            raise Exception(f'operation count from {name} must no be None')
        if name in self._operation_count:
            self._operation_count[name].sum(operation_count)
        else:
            self._operation_count[name] = operation_count

    def _print_header(self, name):
        space = " " * len(name)
        cog.outl(f'// ##### {space} #####')
        cog.outl(f'// ##### {name} #####')
        cog.outl(f'// ##### {space} #####')
        cog.outl(f'// ')

    def evaluate(self, double_add):
        self._print_header("operations by method")

        operations = {
            "add": self._operation_count["add"],
            "sub": self._operation_count["sub"],
            "square": self._operation_count["square"] + self._operation_count["propagate_carry_field_entry_mul_t"],
            "mul": self._operation_count["mul"] + self._operation_count["propagate_carry_field_entry_mul_t"],
            "mul a24": self._operation_count["mul_a24"] + self._operation_count["propagate_carry_field_entry_mul_t"],
            "decode point": self._operation_count["decode_point"] + self._operation_count["propagate_carry_field_entry_t"],
            "encode point": self._operation_count["propagate_carry_pre_encode_point"] + self._operation_count["encode_point"],
            "swap": self._operation_count["swap"],
            "invert": (26 + 228) * self._operation_count["square"] + 11 * self._operation_count["mul"],  # 26 (single) + 228 (loops) squares + 11 mults
            "decode scalar": OperationCount(adds = 3)
        }

        swap_operations = OperationCount(xors = 1, slts = 1, ands = 2)
        inner_operations = swap_operations + 2 * operations["swap"] + 4 * operations["add"] + 4 * operations["sub"] + 4 * operations["square"] + 5 * operations["mul"] + operations["mul a24"]
        operations["curve mul"] = 255 * inner_operations + 2 * operations["swap"] + operations["invert"] + operations["mul"]

        for name, entry in operations.items():
            cog.outl(f'// {entry.print(name, double_add)}')
        
        cog.outl('// ==========================================================')
        operations["total"] = operations["decode scalar"] + operations["decode point"] + operations["curve mul"] + operations["encode point"] 
        cog.outl(f'// {operations["total"].print("curve25519", double_add)}')

        header = ",".join(operations["total"].serialization_order())
        body = ",".join(operations["total"].serialize(double_add))

        path = str(Path(__file__).resolve().parent.parent) + "/ops.csv"
        file = open(path, "w")
        file.write(header + "\n" + body)
        file.close()

        cog.outl('')
        cog.outl('')

        self._print_header("method * call_count)")
        operations = {
            **operations, # get values from old dict
            "add": 255 * 4 * operations["add"],
            "sub": 255 * 4 * operations["sub"],
            "square": 255 * 4 * operations["square"],
            "mul": (255 * 5 + 1) * operations["mul"],
            "mul a24": 255 * operations["mul a24"],
            "swap": (255 * 2 + 2) * operations["swap"]
        }

        serialized_entries = []
        for name, entry in operations.items():
            cog.outl(f'// {entry.print(name, double_add)}')
            serialized_entries.append(name + "," + ",".join(entry.serialize(double_add)))
        
        cog.outl('// ==========================================================')
        cog.outl(f'// {operations["total"].print("curve25519", double_add)}')

        header = "name," + ",".join(operations["total"].serialization_order())

        path = str(Path(__file__).resolve().parent.parent) + "/method_ops.csv"
        file = open(path, "w")
        file.write(header + "\n" + ("\n".join(serialized_entries)))
        file.close()


        total_header = []
        total_body = []
        for name, entry in operations.items():
            total_header.append(name)
            total_body.append(str(entry.total(double_add)))

        path = str(Path(__file__).resolve().parent.parent) + "/methods.csv"
        file = open(path, "w")
        file.write(",".join(total_header) + "\n" + ",".join(total_body))
        file.close()

        

        