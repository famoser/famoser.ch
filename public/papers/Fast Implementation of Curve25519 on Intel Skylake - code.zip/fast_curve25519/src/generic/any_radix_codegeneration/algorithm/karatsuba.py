from algorithm.naive import Naive

import algorithm.methods.mul as mul

class Karatsuba(Naive):
    def __init__(self, RADIX):
        super().__init__(RADIX)
    
    def mul(self, dst, a, b):
        operationCount = mul.karatsuba(self.field_representation, dst, a, b)
        self.add_operation_count("mul", operationCount)
    