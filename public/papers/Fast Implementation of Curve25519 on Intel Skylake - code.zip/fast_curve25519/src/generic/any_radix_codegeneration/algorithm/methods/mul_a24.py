from algorithm.methods.representation import FieldRepresentation
from algorithm.methods.evaluation import OperationCount
import cog

def naive(field: FieldRepresentation, dst, src):
    operationCount = OperationCount()
    cog.outl(f'field_entry_mul_t {dst}[{field.limb_count}] = ' + "{0};\n")
    
    operationCount.add("*", field.limb_count)
    for i in range(0, field.limb_count):
        cog.outl(f'{dst}[{i}] = (field_entry_mul_t){src}[{i}] * a24;')

    return operationCount