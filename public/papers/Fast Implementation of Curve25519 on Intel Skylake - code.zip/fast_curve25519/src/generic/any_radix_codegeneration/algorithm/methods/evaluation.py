import math

class OperationCount:
    def __init__(self, adds = 0, dadds = 0, subs = 0, mults = 0, slts = 0, srts = 0, dsrts = 0, ands = 0, ors = 0, xors = 0, divs = 0):
        self.adds = adds
        self.dadds = dadds
        self.subs = subs
        self.mults = mults
        self.slts = slts
        self.srts = srts
        self.dsrts = dsrts
        self.ands = ands
        self.ors = ors
        self.xors = xors
        self.divs = divs

    def add(self, op, count = 1):
        if op == "+":
            self.adds = self.adds + count
        elif op == "++":
            self.dadds = self.dadds + count
        elif op == "-":
            self.subs = self.subs + count
        elif op == "*":
            self.mults = self.mults + count
        elif op == "<<":
            self.slts = self.slts + count
        elif op == ">>":
            self.srts = self.srts + count
        elif op == ">>>>":
            self.dsrts = self.dsrts + count
        elif op == "&":
            self.ands = self.ands + count
        elif op == "|":
            self.ors = self.ors + count
        elif op == "^":
            self.xors = self.xors + count
        elif op == "/":
            self.divs = self.divs + count
        else:
            raise Exception(f'unknown operation {op}')

    def sum(self, other):
        self.adds = self.adds + other.adds
        self.dadds = self.dadds + other.dadds
        self.subs = self.subs + other.subs
        self.mults = self.mults + other.mults
        self.slts = self.slts + other.slts
        self.srts = self.srts + other.srts
        self.dsrts = self.dsrts + other.dsrts
        self.ands = self.ands + other.ands
        self.ors = self.ors + other.ors
        self.xors = self.xors + other.xors
        self.divs = self.divs + other.divs

    def __rmul__(self, other):
        if isinstance(other, (int, float)):
            return OperationCount(
                self.adds * other, 
                self.dadds * other, 
                self.subs * other, 
                self.mults * other,
                self.slts * other,
                self.srts * other,
                self.dsrts * other,
                self.ands * other,
                self.ors * other,
                self.xors * other,
                self.divs * other
            )
        else:
            return NotImplemented

    def __add__(self, other):
        if isinstance(other, OperationCount):
            return OperationCount(
                self.adds + other.adds, 
                self.dadds + other.dadds, 
                self.subs + other.subs, 
                self.mults + other.mults,
                self.slts + other.slts,
                self.srts + other.srts,
                self.dsrts + other.dsrts,
                self.ands + other.ands,
                self.ors + other.ors,
                self.xors + other.xors,
                self.divs + other.divs
            )
        else:
            return NotImplemented

    def print(self, name, double_count):
        output = [
            self.format(self.adds + (double_count+1)*self.dadds, "adds"), 
            self.format(self.subs, "subs"), 
            self.format(self.mults, "mults"), 
            self.format(self.slts, "slts"), 
            self.format(self.srts + (double_count+1)*self.dsrts, "srts"), 
            self.format(self.ands, "ands"), 
            self.format(self.ors, "ors"), 
            self.format(self.xors, "xors"), 
            self.format(self.divs, "divs")
        ]
        
        return " ".join(output) + f' | {name}'
    
    def serialization_order(self):
        header = [
            "adds", "subs", "mults", "slts", "srts", "ands", "ors", "xors", "divs"
        ]

        return header

    def serialize(self, double_count):
        row = [
            str(self.adds + (double_count + 1)*self.dadds),
            str(self.subs),
            str(self.mults), 
            str(self.slts),  
            str(self.srts + (double_count + 1)*self.dsrts),  
            str(self.ands),  
            str(self.ors),
            str(self.xors), 
            str(self.divs)
        ]

        return row
    
    def total(self, double_add):
        return self.adds + (1+double_add)*self.dadds + self.subs + self.mults + self.slts + self.srts + (1+double_add)*self.dsrts + self.ands + self.ors + self.xors + self.divs
    
    def format(self, number, text):
        numberSize = 6
        textSize = 8
        
        if number == 0:
            return "".rjust(numberSize + textSize + 1)
        
        return f'{str(number).rjust(numberSize)} {text.ljust(textSize)}'