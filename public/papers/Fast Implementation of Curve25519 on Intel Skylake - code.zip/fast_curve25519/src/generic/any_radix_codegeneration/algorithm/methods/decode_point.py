from algorithm.methods.representation import FieldRepresentation
from algorithm.methods.representation import InputRepresentation
from algorithm.methods.evaluation import OperationCount
import cog

def naive(field: FieldRepresentation, input: InputRepresentation, dst, src):
    operationCount = OperationCount()

    cog.outl(f'field_entry_t {dst}[{field.limb_count}] = ' + "{0};\n")

    limb = 0
    current_offset = 0
    for i in range(0, input.limb_count):
        offset = field.limb_bit_count[limb] - current_offset
        if offset < input.limb_bit_count:
            if offset > 0:
                keep_mask = (1 << offset) - 1
                cog.outl(f'{dst}[{limb}] += ((field_entry_t){src}[{i}] & {keep_mask}) << {current_offset};')
                
                operationCount.add("+")
                operationCount.add("&")
                operationCount.add("<<")
            
            limb += 1
            if limb == field.limb_count:
                break
            
            out = f'{dst}[{limb}] = (field_entry_t){src}[{i}]'
            if offset > 0:
                out += f' >> {offset}'
                operationCount.add(">>")

            cog.outl(f'{out};')

            current_offset = -offset
        else:
            cog.outl(f'{dst}[{limb}] += (field_entry_t){src}[{i}] << {current_offset};')
            operationCount.add("+")
            operationCount.add("<<")
        
        current_offset += input.limb_bit_count
    
    return operationCount