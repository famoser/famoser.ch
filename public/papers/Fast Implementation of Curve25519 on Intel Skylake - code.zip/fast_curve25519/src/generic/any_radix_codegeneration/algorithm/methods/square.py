from algorithm.methods.representation import FieldRepresentation
from algorithm.methods.evaluation import OperationCount
import cog

def naive(field: FieldRepresentation, dst, src):
    operationCount = OperationCount()

    cog.outl(f'field_entry_mul_t {dst}[{2*field.limb_count-1}] = ' + "{0};\n")

    mul_set = set()
    for i in range(0, field.limb_count):
        multiplicator = field.limb_mul_collection[i*field.limb_count+i]
        if multiplicator != 1.0:
            mul_set_key = f'src_{i}_{multiplicator}'.replace(".", "_")
            if not mul_set_key in mul_set:
                cog.outl(f'field_entry_mul_t {mul_set_key} = (field_entry_mul_t){src}[{i}] * {multiplicator};')
                mul_set.add(mul_set_key)

                operationCount.add("*")
                
        for j in range(i+1, field.limb_count):
            multiplicator = field.limb_mul_collection[i*field.limb_count+j] * 2
            mul_set_key = f'src_{j}_{multiplicator}'.replace(".", "_")
            if not mul_set_key in mul_set:
                cog.outl(f'field_entry_mul_t {mul_set_key} = (field_entry_mul_t){src}[{j}] * {multiplicator};')
                mul_set.add(mul_set_key)

                operationCount.add("*")

    if len(mul_set) > 0:
        cog.outl('')

    usedIndexes = set()
    for i in range(0, field.limb_count):
        operationCount.add("*")
        out = f'(field_entry_mul_t){src}[{i}] * '
        multiplicator = field.limb_mul_collection[i*field.limb_count+i]
        if multiplicator == 1.0:
            out += f'{src}[{i}]'
        else:
            mul_set_key = f'src_{i}_{multiplicator}'.replace(".", "_")
            out += f'{mul_set_key}'
        
        index = i+i
        if index in usedIndexes:
            operationCount.add("++")
            cog.outl(f'{dst}[{index}] += {out};')
        else:
            usedIndexes.add(index)
            cog.outl(f'{dst}[{index}] = {out};')
        
        for j in range(i+1, field.limb_count):        
            operationCount.add("*")    
            out = f'(field_entry_mul_t){src}[{i}] * '
            multiplicator = field.limb_mul_collection[i*field.limb_count+j]*2
            mul_set_key = f'src_{j}_{multiplicator}'.replace(".", "_")
            out += f'{mul_set_key}'

            index = i+j
            if index in usedIndexes:
                operationCount.add("++")
                cog.outl(f'{dst}[{index}] += {out};')
            else:
                usedIndexes.add(index)
                cog.outl(f'{dst}[{index}] = {out};')

    cog.outl('')
    
    for i in range(field.limb_count, 2*field.limb_count-1):
        cog.outl(f'{dst}[{i-field.limb_count}] += {dst}[{i}] * 19;')

        operationCount.add("*")
        operationCount.add("++")
    
    return operationCount

def schoolbook(field: FieldRepresentation, dst, src):
    operationCount = OperationCount()

    cog.outl(f'field_entry_mul_t {dst}[{field.limb_count}] = ' + "{0};\n")

    mul_set = set()
    for i in range(0, field.limb_count):
        multiplicator = field.limb_mul_collection[i*field.limb_count+i]
        if i+i >= field.limb_count:
            multiplicator *= 19
            
        if multiplicator != 1.0:
            mul_set_key = f'src_{i}_{multiplicator}'.replace(".", "_")
            if not mul_set_key in mul_set:
                cog.outl(f'field_entry_mul_t {mul_set_key} = (field_entry_mul_t){src}[{i}] * {multiplicator};')
                mul_set.add(mul_set_key)

                operationCount.add("*")
                
        for j in range(i+1, field.limb_count):
            multiplicator = field.limb_mul_collection[i*field.limb_count+j] * 2
            if i+j >= field.limb_count:
                multiplicator *= 19

            mul_set_key = f'src_{j}_{multiplicator}'.replace(".", "_")
            if not mul_set_key in mul_set:
                cog.outl(f'field_entry_mul_t {mul_set_key} = (field_entry_mul_t){src}[{j}] * {multiplicator};')
                mul_set.add(mul_set_key)

                operationCount.add("*")

    if len(mul_set) > 0:
        cog.outl('')

    usedIndexes = set()
    for i in range(0, field.limb_count):
        operationCount.add("*")
        out = f'(field_entry_mul_t){src}[{i}] * '
        multiplicator = field.limb_mul_collection[i*field.limb_count+i]
        if i+i >= field.limb_count:
            multiplicator *= 19

        if multiplicator == 1.0:
            out += f'{src}[{i}]'
        else:
            mul_set_key = f'src_{i}_{multiplicator}'.replace(".", "_")
            out += f'{mul_set_key}'

        index = (i+i) % field.limb_count
        if index in usedIndexes:
            operationCount.add("++")
            cog.outl(f'{dst}[{index}] += {out};')
        else:
            usedIndexes.add(index)
            cog.outl(f'{dst}[{index}] = {out};')

        for j in range(i+1, field.limb_count):    
            operationCount.add("*")        
            out = f'(field_entry_mul_t){src}[{i}] * '
            multiplicator = field.limb_mul_collection[i*field.limb_count+j]*2
            if i+j >= field.limb_count:
                multiplicator *= 19

            mul_set_key = f'src_{j}_{multiplicator}'.replace(".", "_")
            out += f'{mul_set_key}'

            index = (i+j) % field.limb_count
            if index in usedIndexes:
                operationCount.add("++")
                cog.outl(f'{dst}[{index}] += {out};')
            else:
                usedIndexes.add(index)
                cog.outl(f'{dst}[{index}] = {out};')
    
    return operationCount
