from algorithm.methods.representation import FieldRepresentation
from algorithm.methods.representation import InputRepresentation
from algorithm.methods.evaluation import OperationCount
import cog

def naive(field: FieldRepresentation, input: InputRepresentation, dst, src):
    operationCount = OperationCount()

    limb = 0
    current_offset = 0
    for i in range(0, input.limb_count):
        out = f'{src}[{limb}]'
        if current_offset > 0:
            out += f' >> {current_offset}'
            operationCount.add(">>")
        cog.outl(f'{dst}[{i}] = (input_t)({out});')

        offset = field.limb_bit_count[limb] - current_offset
        if offset < input.limb_bit_count:
            limb += 1
            if limb == field.limb_count:
                break
            
            out = f'{src}[{limb}]'
            if offset > 0:
                out += f' << {offset}'
                operationCount.add("<<")
            
            cog.outl(f'{dst}[{i}] |= (input_t)({out});')
            operationCount.add("|")

            current_offset = -offset
        
        current_offset += input.limb_bit_count
    
    return operationCount