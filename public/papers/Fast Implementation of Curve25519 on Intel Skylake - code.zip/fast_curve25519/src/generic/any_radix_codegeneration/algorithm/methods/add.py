from algorithm.methods.representation import FieldRepresentation
import algorithm.methods.binary_op as binary_op
import cog

def naive(field: FieldRepresentation, dst, a, b):
    return binary_op.naive("+", field.limb_count, dst, a, b)

def partial_naive(dst, dst_offset, a, b, ab_offset, ab_count):
    return binary_op.partial_naive("+", dst, dst_offset, a, b, ab_offset, ab_count)

def full_partial_naive(dst, dst_offset, a, a_offset, a_count, b, b_offset, b_count):
    return binary_op.full_partial_naive("+", dst, dst_offset, a, a_offset, a_count, b, b_offset, b_count)

def self_naive(dst, dst_offset, a, a_offset, count):
    return binary_op.self_naive("+", dst, dst_offset, a, a_offset, count)