from algorithm.methods.representation import FieldRepresentation
from algorithm.methods.evaluation import OperationCount
import cog

def naive(field: FieldRepresentation, src):
    operationCount = OperationCount()

    cog.outl(f'field_entry_mul_t carry[{field.limb_count}];\n')

    operationCount.add("*")
    operationCount.add(">>")
    cog.outl(f'field_entry_t q = (19*{src}[{field.last_limb_index}] + ((field_entry_t){1 << field.limb_bit_count[field.last_limb_index]-1})) >> {field.limb_bit_count[field.last_limb_index]};')
    
    cog.outl('')

    operationCount.add("+", field.limb_count)
    operationCount.add(">>", field.limb_count)
    for i in range(0, field.limb_count):
        cog.outl(f'q = ({src}[{i}] + q) >> {field.limb_bit_count[i]};')
    
    operationCount.add("+", field.limb_count)
    operationCount.add("*", field.limb_count)
    cog.outl(f'{src}[0] += 19 * q;')

    cog.outl('')

    operationCount.add(">>", field.last_limb_index)
    operationCount.add("<<", field.last_limb_index)
    operationCount.add("-", field.last_limb_index)
    operationCount.add("+", field.last_limb_index)
    for i in range(0, field.last_limb_index):
        cog.outl(f'carry[{i}] = {src}[{i}] >> {field.limb_bit_count[i]};')
        cog.outl(f'{src}[{i}] -= carry[{i}] << {field.limb_bit_count[i]};')
        cog.outl(f'{src}[{i+1}] += carry[{i}];')

    operationCount.add(">>", field.last_limb_index)
    operationCount.add("<<", field.last_limb_index)
    operationCount.add("-", field.last_limb_index)
    cog.outl(f'carry[{field.last_limb_index}] = {src}[{field.last_limb_index}] >> {field.limb_bit_count[field.last_limb_index]};')
    cog.outl(f'{src}[{field.last_limb_index}] -= carry[{field.last_limb_index}] << {field.limb_bit_count[field.last_limb_index]};')

    return operationCount