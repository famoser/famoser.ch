from algorithm.methods.representation import FieldRepresentation
from algorithm.methods.evaluation import OperationCount
import cog

def naive(field: FieldRepresentation, swap, a, b):
    operationCount = OperationCount()

    operationCount.add("-")
    cog.outl(f'{swap} = -{swap};')

    operationCount.add("&", field.limb_count)
    operationCount.add("^", 3 * field.limb_count)
    cog.outl(f'field_entry_t t;')
    for i in range(0, field.limb_count):
        cog.outl(f't = {swap} & ({a}[{i}] ^ {b}[{i}]);')
        cog.outl(f'{a}[{i}] ^= t;')
        cog.outl(f'{b}[{i}] ^= t;')
    
    return operationCount;