from algorithm.methods.representation import FieldRepresentation
from algorithm.methods.evaluation import OperationCount
import algorithm.methods.add as add
import algorithm.methods.sub as sub 
import cog
import math

def naive(field: FieldRepresentation, dst, a, b):
    operationCount = OperationCount()

    cog.outl(f'field_entry_mul_t {dst}[{2*field.limb_count-1}] = ' + "{0};\n")

    mul_set = set()
    for i in range(0, field.limb_count):
        for j in range(0, field.limb_count):
            multiplicator = field.limb_mul_collection[i*field.limb_count+j]
            if multiplicator == 1.0:
                continue
            
            mul_set_key = f'b_{j}_{multiplicator}'.replace(".", "_")
            if not mul_set_key in mul_set:
                cog.outl(f'field_entry_mul_t {mul_set_key} = (field_entry_mul_t){b}[{j}] * {multiplicator};')
                mul_set.add(mul_set_key)

                operationCount.add("*")

    if len(mul_set) > 0:
        cog.outl('')

    usedIndexes = set()
    for i in range(0, field.limb_count):
        for j in range(0, field.limb_count):
            operationCount.add("*")
            out = f'(field_entry_mul_t){a}[{i}] * '
            
            multiplicator = field.limb_mul_collection[i*field.limb_count+j]
            if multiplicator == 1.0:
                out += f'{b}[{j}]'
            else:
                mul_set_key = f'b_{j}_{multiplicator}'.replace(".", "_")
                out += f'{mul_set_key}'

            index = (i+j)
            if index in usedIndexes:
                operationCount.add("++")
                cog.outl(f'{dst}[{index}] += {out};')
            else:
                usedIndexes.add(index)
                cog.outl(f'{dst}[{index}] = {out};')

    cog.outl('')
    
    for i in range(field.limb_count, 2*field.limb_count-1):
        cog.outl(f'{dst}[{i-field.limb_count}] += {dst}[{i}] * 19;')

        operationCount.add("*")
        operationCount.add("++")
    
    return operationCount


def schoolbook(field: FieldRepresentation, dst, a, b):
    operationCount = OperationCount()

    cog.outl(f'field_entry_mul_t {dst}[{field.limb_count}] = ' + "{0};\n")

    mul_set = set()
    for i in range(0, field.limb_count):
        for j in range(0, field.limb_count):            
            multiplicator = field.limb_mul_collection[i*field.limb_count+j]
            if i+j >= field.limb_count:
                multiplicator *= 19
              
            if multiplicator == 1.0:
                continue
            
            mul_set_key = f'b_{j}_{multiplicator}'.replace(".", "_")
            if not mul_set_key in mul_set:
                cog.outl(f'field_entry_mul_t {mul_set_key} = (field_entry_mul_t){b}[{j}] * {multiplicator};')
                mul_set.add(mul_set_key)

                operationCount.add("*")

    if len(mul_set) > 0:
        cog.outl('')

    usedIndexes = set()
    for i in range(0, field.limb_count):
        for j in range(0, field.limb_count):
            operationCount.add("*")
            out = f'(field_entry_mul_t){a}[{i}] * '
            
            multiplicator = field.limb_mul_collection[i*field.limb_count+j]
            if i+j >= field.limb_count:
                multiplicator *= 19

            if multiplicator == 1.0:
                out += f'{b}[{j}]'
            else:
                mul_set_key = f'b_{j}_{multiplicator}'.replace(".", "_")
                out += f'{mul_set_key}'

            index = (i+j) % field.limb_count
            if index in usedIndexes:
                operationCount.add("++")
                cog.outl(f'{dst}[{index}] += {out};')
            else:
                usedIndexes.add(index)
                cog.outl(f'{dst}[{index}] = {out};')
    
    return operationCount


def partial_naive(dst, dst_offset, a, b, ab_offset, ab_count):
    operationCount = OperationCount()

    usedIndexes = set()
    for i in range(0, ab_count):
        for j in range(0, ab_count):
            operationCount.add("*")
            out = f'(field_entry_mul_t){a}[{ab_offset + i}] * {b}[{ab_offset + j}]'

            index = dst_offset+i+j
            if index in usedIndexes:
                operationCount.add("++")
                cog.outl(f'{dst}[{index}] += {out};')
            else:
                usedIndexes.add(index)
                cog.outl(f'{dst}[{index}] = {out};')
    
    return operationCount


def full_partial_naive(dst, dst_offset, a, a_offset, a_count, b, b_offset, b_count):
    operationCount = OperationCount()

    usedIndexes = set()
    for i in range(0, a_count):
        for j in range(0, a_count):
            operationCount.add("*")
            out = f'(field_entry_mul_t){a}[{a_offset + i}] * {b}[{b_offset + j}]'
            
            index = dst_offset+i+j
            if index in usedIndexes:
                operationCount.add("++")
                cog.outl(f'{dst}[{index}] += {out};')
            else:
                usedIndexes.add(index)
                cog.outl(f'{dst}[{index}] = {out};')

                
    return operationCount
    

def partial_katatsuba(dst, dst_offset, a, b, ab_offset, size):
    operationCount = OperationCount()

    left_offset = ab_offset
    left_size = math.ceil(size / 2.0)
    right_offset = ab_offset + left_size
    right_size = size - left_size
    
    prefix = f'mul_karatsuba_{dst_offset}_{ab_offset}_'

    # p1 = a_right * b_right
    p1 = f'{prefix}_p1'
    p1_size = right_size*2 - 1
    cog.outl(f'field_entry_mul_t {p1}[{p1_size}] = ' + "{0};")
    operationCount.sum(partial_naive(p1, 0, a, b, right_offset, right_size))
    
    # p2 = a_left * b_left
    p2 = f'{prefix}_p2'
    p2_size = left_size*2 - 1
    cog.outl(f'field_entry_mul_t {p2}[{p2_size}] = ' + "{0};")
    operationCount.sum(partial_naive(p2, 0, a, b, left_offset, left_size))
    
    # p3_left = a_left + a_right
    p3_left = f'{prefix}_p3_left'
    p3_leftright_size = max(left_size, right_size)
    cog.outl(f'field_entry_mul_t {p3_left}[{p3_leftright_size}] = ' + "{0};")
    operationCount.sum(add.full_partial_naive(p3_left, 0, a, left_offset, left_size, a, right_offset, right_size))
    
    # p3_right = b_left + b_right
    p3_right = f'{prefix}_p3_right'
    cog.outl(f'field_entry_mul_t {p3_right}[{p3_leftright_size}] = ' + "{0};")
    operationCount.sum(add.full_partial_naive(p3_right, 0, b, left_offset, left_size, b, right_offset, right_size))
    
    # p3 = p3_left * p3_right
    p3 = f'{prefix}_p3'
    p3_size = p3_leftright_size*2 - 1
    cog.outl(f'field_entry_mul_t {p3}[{p3_size}] = ' + "{0};")
    operationCount.sum(partial_naive(p3, 0, p3_left, p3_right, 0, p3_leftright_size))

    # sum_p1p2 = p1 + p2
    sum_p1p2 = f'{prefix}_sum_p1p2'
    sum_p1p2_size = max(p1_size, p2_size)
    cog.outl(f'field_entry_mul_t {sum_p1p2}[{sum_p1p2_size}] = ' + "{0};")
    operationCount.sum(add.full_partial_naive(sum_p1p2, 0, p1, 0, p1_size, p2, 0, p2_size))

    # sub_p3subp1p2 = p3 - sum_p1p2
    sub_p3sump1p2 = f'{prefix}_sub_p3sump1p2'
    sub_p3sump1p2_size = max(p3_size, sum_p1p2_size)
    cog.outl(f'field_entry_mul_t {sub_p3sump1p2}[{sub_p3sump1p2_size}] = ' + "{0};")
    operationCount.sum(sub.full_partial_naive(sub_p3sump1p2, 0, p3, 0, p3_size, sum_p1p2, 0, sum_p1p2_size))

    # h = p2 + right_offset * sub_p3sump1p2 + right_offset+left_size * p1
    h = f'{prefix}_h'
    h_size = size*2 - 1
    cog.outl(f'field_entry_mul_t {h}[{h_size}] = ' + "{0};")
    operationCount.sum(add.self_naive(h, 0, p2, 0, p2_size))
    operationCount.sum(add.self_naive(h, right_offset, sub_p3sump1p2, 0, sub_p3sump1p2_size))
    operationCount.sum(add.self_naive(h, right_offset+left_size, p1, 0, p1_size))

    # copy h into destination
    cog.outl(f'field_entry_mul_t {dst}[{size}] = ' + "{0};")
    for i in range(0, size):
        cog.outl(f'{dst}[{i}] = {h}[{i}];')

    operationCount.add("++", h_size - size)
    operationCount.add("*", h_size - size)
    for i in range(size, h_size):
        cog.outl(f'{dst}[{i % size}] += {h}[{i}] * 19;')

    return operationCount

def karatsuba(field: FieldRepresentation, dst, a, b):
    return partial_katatsuba(dst, 0, a, b, 0, field.limb_count)