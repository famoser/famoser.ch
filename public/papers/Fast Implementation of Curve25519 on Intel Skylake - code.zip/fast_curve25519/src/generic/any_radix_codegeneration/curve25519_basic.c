#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <assert.h>
#include <math.h>

// ==== CONFIGURATION ====

/*[[[cog
# radix defines how many bits are used per limb

if 'config' in locals():
    configs = config.split('_')
    RADIX = float(configs[0])

    if RADIX > 28:
        field_entry_t = "int64_t";
        field_entry_mul_t = "__int128_t";
    elif RADIX > 10:
        field_entry_t = "int32_t";
        field_entry_mul_t = "int64_t";
    else:
        field_entry_t = "short";
        field_entry_mul_t = "int32_t";

else:
    # radix defines how many bits are used by limp
    RADIX = 25.5

    # choose a datatype suitably big according to the bits per limp
    field_entry_t = "int32_t";

    # choose a datatype suitable big for multiplying two limps together
    field_entry_mul_t = "int64_t";


cog.outl(f'#define field_entry_t {field_entry_t}')
cog.outl(f'#define field_entry_mul_t {field_entry_mul_t}')
]]]*/
#define field_entry_t int32_t
#define field_entry_mul_t int64_t
//[[[end]]]

// choose the datatype of your input
#define input_t uint8_t

// ==== ENDCONFIGURATION ====

// ==== ALGORITHM =====
/*[[[cog
from algorithm.naive import Naive
from algorithm.schoolbook import Schoolbook
from algorithm.karatsuba import Karatsuba
if 'configs' in locals():
    if configs[1] == 'naive':
        algorithm = Naive(RADIX)
    elif configs[1] == 'schoolbook':
        algorithm = Schoolbook(RADIX)
    elif configs[1] == 'karatsuba':
        algorithm = Karatsuba(RADIX)
    else:
        raise Error(f'unknown algorithm {configs[1]}')
else:
    algorithm = Schoolbook(RADIX)
]]]*/
//[[[end]]]
// ==== ENDALGORITHM ====

/*[[[cog
algorithm.typedefs()
]]]*/
typedef input_t byte32_t[32];
typedef field_entry_t field_t[10];
//[[[end]]]

void field_add(field_t dst, field_t a, field_t b) {
    /*[[[cog
    algorithm.add("dst", "a", "b")
    ]]]*/
    dst[0] = a[0] + b[0];
    dst[1] = a[1] + b[1];
    dst[2] = a[2] + b[2];
    dst[3] = a[3] + b[3];
    dst[4] = a[4] + b[4];
    dst[5] = a[5] + b[5];
    dst[6] = a[6] + b[6];
    dst[7] = a[7] + b[7];
    dst[8] = a[8] + b[8];
    dst[9] = a[9] + b[9];
    //[[[end]]]
}

void field_sub(field_t dst, field_t a, field_t b) {
    /*[[[cog
    algorithm.sub("dst", "a", "b")
    ]]]*/
    dst[0] = a[0] - b[0];
    dst[1] = a[1] - b[1];
    dst[2] = a[2] - b[2];
    dst[3] = a[3] - b[3];
    dst[4] = a[4] - b[4];
    dst[5] = a[5] - b[5];
    dst[6] = a[6] - b[6];
    dst[7] = a[7] - b[7];
    dst[8] = a[8] - b[8];
    dst[9] = a[9] - b[9];
    //[[[end]]]
}

void field_square(field_t dst, field_t src) {
    /*[[[cog
    algorithm.square("mul_results", "src")
    ]]]*/
    field_entry_mul_t mul_results[10] = {0};

    field_entry_mul_t src_1_2 = (field_entry_mul_t)src[1] * 2;
    field_entry_mul_t src_2_2 = (field_entry_mul_t)src[2] * 2;
    field_entry_mul_t src_3_2 = (field_entry_mul_t)src[3] * 2;
    field_entry_mul_t src_4_2 = (field_entry_mul_t)src[4] * 2;
    field_entry_mul_t src_5_2 = (field_entry_mul_t)src[5] * 2;
    field_entry_mul_t src_6_2 = (field_entry_mul_t)src[6] * 2;
    field_entry_mul_t src_7_2 = (field_entry_mul_t)src[7] * 2;
    field_entry_mul_t src_8_2 = (field_entry_mul_t)src[8] * 2;
    field_entry_mul_t src_9_2 = (field_entry_mul_t)src[9] * 2;
    field_entry_mul_t src_3_4 = (field_entry_mul_t)src[3] * 4;
    field_entry_mul_t src_5_4 = (field_entry_mul_t)src[5] * 4;
    field_entry_mul_t src_7_4 = (field_entry_mul_t)src[7] * 4;
    field_entry_mul_t src_9_76 = (field_entry_mul_t)src[9] * 76;
    field_entry_mul_t src_8_38 = (field_entry_mul_t)src[8] * 38;
    field_entry_mul_t src_9_38 = (field_entry_mul_t)src[9] * 38;
    field_entry_mul_t src_7_76 = (field_entry_mul_t)src[7] * 76;
    field_entry_mul_t src_6_38 = (field_entry_mul_t)src[6] * 38;
    field_entry_mul_t src_7_38 = (field_entry_mul_t)src[7] * 38;
    field_entry_mul_t src_5_38 = (field_entry_mul_t)src[5] * 38;
    field_entry_mul_t src_6_19 = (field_entry_mul_t)src[6] * 19;
    field_entry_mul_t src_8_19 = (field_entry_mul_t)src[8] * 19;

    mul_results[0] = (field_entry_mul_t)src[0] * src[0];
    mul_results[1] = (field_entry_mul_t)src[0] * src_1_2;
    mul_results[2] = (field_entry_mul_t)src[0] * src_2_2;
    mul_results[3] = (field_entry_mul_t)src[0] * src_3_2;
    mul_results[4] = (field_entry_mul_t)src[0] * src_4_2;
    mul_results[5] = (field_entry_mul_t)src[0] * src_5_2;
    mul_results[6] = (field_entry_mul_t)src[0] * src_6_2;
    mul_results[7] = (field_entry_mul_t)src[0] * src_7_2;
    mul_results[8] = (field_entry_mul_t)src[0] * src_8_2;
    mul_results[9] = (field_entry_mul_t)src[0] * src_9_2;
    mul_results[2] += (field_entry_mul_t)src[1] * src_1_2;
    mul_results[3] += (field_entry_mul_t)src[1] * src_2_2;
    mul_results[4] += (field_entry_mul_t)src[1] * src_3_4;
    mul_results[5] += (field_entry_mul_t)src[1] * src_4_2;
    mul_results[6] += (field_entry_mul_t)src[1] * src_5_4;
    mul_results[7] += (field_entry_mul_t)src[1] * src_6_2;
    mul_results[8] += (field_entry_mul_t)src[1] * src_7_4;
    mul_results[9] += (field_entry_mul_t)src[1] * src_8_2;
    mul_results[0] += (field_entry_mul_t)src[1] * src_9_76;
    mul_results[4] += (field_entry_mul_t)src[2] * src[2];
    mul_results[5] += (field_entry_mul_t)src[2] * src_3_2;
    mul_results[6] += (field_entry_mul_t)src[2] * src_4_2;
    mul_results[7] += (field_entry_mul_t)src[2] * src_5_2;
    mul_results[8] += (field_entry_mul_t)src[2] * src_6_2;
    mul_results[9] += (field_entry_mul_t)src[2] * src_7_2;
    mul_results[0] += (field_entry_mul_t)src[2] * src_8_38;
    mul_results[1] += (field_entry_mul_t)src[2] * src_9_38;
    mul_results[6] += (field_entry_mul_t)src[3] * src_3_2;
    mul_results[7] += (field_entry_mul_t)src[3] * src_4_2;
    mul_results[8] += (field_entry_mul_t)src[3] * src_5_4;
    mul_results[9] += (field_entry_mul_t)src[3] * src_6_2;
    mul_results[0] += (field_entry_mul_t)src[3] * src_7_76;
    mul_results[1] += (field_entry_mul_t)src[3] * src_8_38;
    mul_results[2] += (field_entry_mul_t)src[3] * src_9_76;
    mul_results[8] += (field_entry_mul_t)src[4] * src[4];
    mul_results[9] += (field_entry_mul_t)src[4] * src_5_2;
    mul_results[0] += (field_entry_mul_t)src[4] * src_6_38;
    mul_results[1] += (field_entry_mul_t)src[4] * src_7_38;
    mul_results[2] += (field_entry_mul_t)src[4] * src_8_38;
    mul_results[3] += (field_entry_mul_t)src[4] * src_9_38;
    mul_results[0] += (field_entry_mul_t)src[5] * src_5_38;
    mul_results[1] += (field_entry_mul_t)src[5] * src_6_38;
    mul_results[2] += (field_entry_mul_t)src[5] * src_7_76;
    mul_results[3] += (field_entry_mul_t)src[5] * src_8_38;
    mul_results[4] += (field_entry_mul_t)src[5] * src_9_76;
    mul_results[2] += (field_entry_mul_t)src[6] * src_6_19;
    mul_results[3] += (field_entry_mul_t)src[6] * src_7_38;
    mul_results[4] += (field_entry_mul_t)src[6] * src_8_38;
    mul_results[5] += (field_entry_mul_t)src[6] * src_9_38;
    mul_results[4] += (field_entry_mul_t)src[7] * src_7_38;
    mul_results[5] += (field_entry_mul_t)src[7] * src_8_38;
    mul_results[6] += (field_entry_mul_t)src[7] * src_9_76;
    mul_results[6] += (field_entry_mul_t)src[8] * src_8_19;
    mul_results[7] += (field_entry_mul_t)src[8] * src_9_38;
    mul_results[8] += (field_entry_mul_t)src[9] * src_9_38;
    //[[[end]]]

    /*[[[cog
    algorithm.propagate_carry("dst", "mul_results", "field_entry_mul_t")
    ]]]*/
    mul_results[1] += mul_results[0] >> 26;
    mul_results[0] &= 67108863;
    mul_results[2] += mul_results[1] >> 25;
    mul_results[1] &= 33554431;
    mul_results[3] += mul_results[2] >> 26;
    mul_results[2] &= 67108863;
    mul_results[4] += mul_results[3] >> 25;
    mul_results[3] &= 33554431;
    mul_results[5] += mul_results[4] >> 26;
    mul_results[4] &= 67108863;
    mul_results[6] += mul_results[5] >> 25;
    mul_results[5] &= 33554431;
    mul_results[7] += mul_results[6] >> 26;
    mul_results[6] &= 67108863;
    mul_results[8] += mul_results[7] >> 25;
    mul_results[7] &= 33554431;
    mul_results[9] += mul_results[8] >> 26;
    mul_results[8] &= 67108863;
    mul_results[0] += (mul_results[9] >> 25) * 19;
    mul_results[9] &= 33554431;
    mul_results[1] += mul_results[0] >> 26;
    mul_results[0] &= 67108863;

    dst[0] = (field_entry_t)mul_results[0];
    dst[1] = (field_entry_t)mul_results[1];
    dst[2] = (field_entry_t)mul_results[2];
    dst[3] = (field_entry_t)mul_results[3];
    dst[4] = (field_entry_t)mul_results[4];
    dst[5] = (field_entry_t)mul_results[5];
    dst[6] = (field_entry_t)mul_results[6];
    dst[7] = (field_entry_t)mul_results[7];
    dst[8] = (field_entry_t)mul_results[8];
    dst[9] = (field_entry_t)mul_results[9];
    //[[[end]]]
}

void field_mul(field_t dst, field_t a, field_t b) {
    /*[[[cog
    algorithm.mul("mul_results", "a", "b")
    ]]]*/
    field_entry_mul_t mul_results[10] = {0};

    field_entry_mul_t b_1_2 = (field_entry_mul_t)b[1] * 2;
    field_entry_mul_t b_3_2 = (field_entry_mul_t)b[3] * 2;
    field_entry_mul_t b_5_2 = (field_entry_mul_t)b[5] * 2;
    field_entry_mul_t b_7_2 = (field_entry_mul_t)b[7] * 2;
    field_entry_mul_t b_9_38 = (field_entry_mul_t)b[9] * 38;
    field_entry_mul_t b_8_19 = (field_entry_mul_t)b[8] * 19;
    field_entry_mul_t b_9_19 = (field_entry_mul_t)b[9] * 19;
    field_entry_mul_t b_7_38 = (field_entry_mul_t)b[7] * 38;
    field_entry_mul_t b_6_19 = (field_entry_mul_t)b[6] * 19;
    field_entry_mul_t b_7_19 = (field_entry_mul_t)b[7] * 19;
    field_entry_mul_t b_5_38 = (field_entry_mul_t)b[5] * 38;
    field_entry_mul_t b_4_19 = (field_entry_mul_t)b[4] * 19;
    field_entry_mul_t b_5_19 = (field_entry_mul_t)b[5] * 19;
    field_entry_mul_t b_3_38 = (field_entry_mul_t)b[3] * 38;
    field_entry_mul_t b_2_19 = (field_entry_mul_t)b[2] * 19;
    field_entry_mul_t b_3_19 = (field_entry_mul_t)b[3] * 19;
    field_entry_mul_t b_1_38 = (field_entry_mul_t)b[1] * 38;

    mul_results[0] = (field_entry_mul_t)a[0] * b[0];
    mul_results[1] = (field_entry_mul_t)a[0] * b[1];
    mul_results[2] = (field_entry_mul_t)a[0] * b[2];
    mul_results[3] = (field_entry_mul_t)a[0] * b[3];
    mul_results[4] = (field_entry_mul_t)a[0] * b[4];
    mul_results[5] = (field_entry_mul_t)a[0] * b[5];
    mul_results[6] = (field_entry_mul_t)a[0] * b[6];
    mul_results[7] = (field_entry_mul_t)a[0] * b[7];
    mul_results[8] = (field_entry_mul_t)a[0] * b[8];
    mul_results[9] = (field_entry_mul_t)a[0] * b[9];
    mul_results[1] += (field_entry_mul_t)a[1] * b[0];
    mul_results[2] += (field_entry_mul_t)a[1] * b_1_2;
    mul_results[3] += (field_entry_mul_t)a[1] * b[2];
    mul_results[4] += (field_entry_mul_t)a[1] * b_3_2;
    mul_results[5] += (field_entry_mul_t)a[1] * b[4];
    mul_results[6] += (field_entry_mul_t)a[1] * b_5_2;
    mul_results[7] += (field_entry_mul_t)a[1] * b[6];
    mul_results[8] += (field_entry_mul_t)a[1] * b_7_2;
    mul_results[9] += (field_entry_mul_t)a[1] * b[8];
    mul_results[0] += (field_entry_mul_t)a[1] * b_9_38;
    mul_results[2] += (field_entry_mul_t)a[2] * b[0];
    mul_results[3] += (field_entry_mul_t)a[2] * b[1];
    mul_results[4] += (field_entry_mul_t)a[2] * b[2];
    mul_results[5] += (field_entry_mul_t)a[2] * b[3];
    mul_results[6] += (field_entry_mul_t)a[2] * b[4];
    mul_results[7] += (field_entry_mul_t)a[2] * b[5];
    mul_results[8] += (field_entry_mul_t)a[2] * b[6];
    mul_results[9] += (field_entry_mul_t)a[2] * b[7];
    mul_results[0] += (field_entry_mul_t)a[2] * b_8_19;
    mul_results[1] += (field_entry_mul_t)a[2] * b_9_19;
    mul_results[3] += (field_entry_mul_t)a[3] * b[0];
    mul_results[4] += (field_entry_mul_t)a[3] * b_1_2;
    mul_results[5] += (field_entry_mul_t)a[3] * b[2];
    mul_results[6] += (field_entry_mul_t)a[3] * b_3_2;
    mul_results[7] += (field_entry_mul_t)a[3] * b[4];
    mul_results[8] += (field_entry_mul_t)a[3] * b_5_2;
    mul_results[9] += (field_entry_mul_t)a[3] * b[6];
    mul_results[0] += (field_entry_mul_t)a[3] * b_7_38;
    mul_results[1] += (field_entry_mul_t)a[3] * b_8_19;
    mul_results[2] += (field_entry_mul_t)a[3] * b_9_38;
    mul_results[4] += (field_entry_mul_t)a[4] * b[0];
    mul_results[5] += (field_entry_mul_t)a[4] * b[1];
    mul_results[6] += (field_entry_mul_t)a[4] * b[2];
    mul_results[7] += (field_entry_mul_t)a[4] * b[3];
    mul_results[8] += (field_entry_mul_t)a[4] * b[4];
    mul_results[9] += (field_entry_mul_t)a[4] * b[5];
    mul_results[0] += (field_entry_mul_t)a[4] * b_6_19;
    mul_results[1] += (field_entry_mul_t)a[4] * b_7_19;
    mul_results[2] += (field_entry_mul_t)a[4] * b_8_19;
    mul_results[3] += (field_entry_mul_t)a[4] * b_9_19;
    mul_results[5] += (field_entry_mul_t)a[5] * b[0];
    mul_results[6] += (field_entry_mul_t)a[5] * b_1_2;
    mul_results[7] += (field_entry_mul_t)a[5] * b[2];
    mul_results[8] += (field_entry_mul_t)a[5] * b_3_2;
    mul_results[9] += (field_entry_mul_t)a[5] * b[4];
    mul_results[0] += (field_entry_mul_t)a[5] * b_5_38;
    mul_results[1] += (field_entry_mul_t)a[5] * b_6_19;
    mul_results[2] += (field_entry_mul_t)a[5] * b_7_38;
    mul_results[3] += (field_entry_mul_t)a[5] * b_8_19;
    mul_results[4] += (field_entry_mul_t)a[5] * b_9_38;
    mul_results[6] += (field_entry_mul_t)a[6] * b[0];
    mul_results[7] += (field_entry_mul_t)a[6] * b[1];
    mul_results[8] += (field_entry_mul_t)a[6] * b[2];
    mul_results[9] += (field_entry_mul_t)a[6] * b[3];
    mul_results[0] += (field_entry_mul_t)a[6] * b_4_19;
    mul_results[1] += (field_entry_mul_t)a[6] * b_5_19;
    mul_results[2] += (field_entry_mul_t)a[6] * b_6_19;
    mul_results[3] += (field_entry_mul_t)a[6] * b_7_19;
    mul_results[4] += (field_entry_mul_t)a[6] * b_8_19;
    mul_results[5] += (field_entry_mul_t)a[6] * b_9_19;
    mul_results[7] += (field_entry_mul_t)a[7] * b[0];
    mul_results[8] += (field_entry_mul_t)a[7] * b_1_2;
    mul_results[9] += (field_entry_mul_t)a[7] * b[2];
    mul_results[0] += (field_entry_mul_t)a[7] * b_3_38;
    mul_results[1] += (field_entry_mul_t)a[7] * b_4_19;
    mul_results[2] += (field_entry_mul_t)a[7] * b_5_38;
    mul_results[3] += (field_entry_mul_t)a[7] * b_6_19;
    mul_results[4] += (field_entry_mul_t)a[7] * b_7_38;
    mul_results[5] += (field_entry_mul_t)a[7] * b_8_19;
    mul_results[6] += (field_entry_mul_t)a[7] * b_9_38;
    mul_results[8] += (field_entry_mul_t)a[8] * b[0];
    mul_results[9] += (field_entry_mul_t)a[8] * b[1];
    mul_results[0] += (field_entry_mul_t)a[8] * b_2_19;
    mul_results[1] += (field_entry_mul_t)a[8] * b_3_19;
    mul_results[2] += (field_entry_mul_t)a[8] * b_4_19;
    mul_results[3] += (field_entry_mul_t)a[8] * b_5_19;
    mul_results[4] += (field_entry_mul_t)a[8] * b_6_19;
    mul_results[5] += (field_entry_mul_t)a[8] * b_7_19;
    mul_results[6] += (field_entry_mul_t)a[8] * b_8_19;
    mul_results[7] += (field_entry_mul_t)a[8] * b_9_19;
    mul_results[9] += (field_entry_mul_t)a[9] * b[0];
    mul_results[0] += (field_entry_mul_t)a[9] * b_1_38;
    mul_results[1] += (field_entry_mul_t)a[9] * b_2_19;
    mul_results[2] += (field_entry_mul_t)a[9] * b_3_38;
    mul_results[3] += (field_entry_mul_t)a[9] * b_4_19;
    mul_results[4] += (field_entry_mul_t)a[9] * b_5_38;
    mul_results[5] += (field_entry_mul_t)a[9] * b_6_19;
    mul_results[6] += (field_entry_mul_t)a[9] * b_7_38;
    mul_results[7] += (field_entry_mul_t)a[9] * b_8_19;
    mul_results[8] += (field_entry_mul_t)a[9] * b_9_38;
    //[[[end]]]

    /*[[[cog
    algorithm.propagate_carry("dst", "mul_results", "field_entry_mul_t")
    ]]]*/
    mul_results[1] += mul_results[0] >> 26;
    mul_results[0] &= 67108863;
    mul_results[2] += mul_results[1] >> 25;
    mul_results[1] &= 33554431;
    mul_results[3] += mul_results[2] >> 26;
    mul_results[2] &= 67108863;
    mul_results[4] += mul_results[3] >> 25;
    mul_results[3] &= 33554431;
    mul_results[5] += mul_results[4] >> 26;
    mul_results[4] &= 67108863;
    mul_results[6] += mul_results[5] >> 25;
    mul_results[5] &= 33554431;
    mul_results[7] += mul_results[6] >> 26;
    mul_results[6] &= 67108863;
    mul_results[8] += mul_results[7] >> 25;
    mul_results[7] &= 33554431;
    mul_results[9] += mul_results[8] >> 26;
    mul_results[8] &= 67108863;
    mul_results[0] += (mul_results[9] >> 25) * 19;
    mul_results[9] &= 33554431;
    mul_results[1] += mul_results[0] >> 26;
    mul_results[0] &= 67108863;

    dst[0] = (field_entry_t)mul_results[0];
    dst[1] = (field_entry_t)mul_results[1];
    dst[2] = (field_entry_t)mul_results[2];
    dst[3] = (field_entry_t)mul_results[3];
    dst[4] = (field_entry_t)mul_results[4];
    dst[5] = (field_entry_t)mul_results[5];
    dst[6] = (field_entry_t)mul_results[6];
    dst[7] = (field_entry_t)mul_results[7];
    dst[8] = (field_entry_t)mul_results[8];
    dst[9] = (field_entry_t)mul_results[9];
    //[[[end]]]
}

void field_mul_a24(field_t dst, field_t src) {
    const int a24 = 121665;
    
    /*[[[cog
    algorithm.mul_a24("mul_results", "src")
    ]]]*/
    field_entry_mul_t mul_results[10] = {0};

    mul_results[0] = (field_entry_mul_t)src[0] * a24;
    mul_results[1] = (field_entry_mul_t)src[1] * a24;
    mul_results[2] = (field_entry_mul_t)src[2] * a24;
    mul_results[3] = (field_entry_mul_t)src[3] * a24;
    mul_results[4] = (field_entry_mul_t)src[4] * a24;
    mul_results[5] = (field_entry_mul_t)src[5] * a24;
    mul_results[6] = (field_entry_mul_t)src[6] * a24;
    mul_results[7] = (field_entry_mul_t)src[7] * a24;
    mul_results[8] = (field_entry_mul_t)src[8] * a24;
    mul_results[9] = (field_entry_mul_t)src[9] * a24;
    //[[[end]]]

    /*[[[cog
    algorithm.propagate_carry("dst", "mul_results", "field_entry_mul_t")
    ]]]*/
    mul_results[1] += mul_results[0] >> 26;
    mul_results[0] &= 67108863;
    mul_results[2] += mul_results[1] >> 25;
    mul_results[1] &= 33554431;
    mul_results[3] += mul_results[2] >> 26;
    mul_results[2] &= 67108863;
    mul_results[4] += mul_results[3] >> 25;
    mul_results[3] &= 33554431;
    mul_results[5] += mul_results[4] >> 26;
    mul_results[4] &= 67108863;
    mul_results[6] += mul_results[5] >> 25;
    mul_results[5] &= 33554431;
    mul_results[7] += mul_results[6] >> 26;
    mul_results[6] &= 67108863;
    mul_results[8] += mul_results[7] >> 25;
    mul_results[7] &= 33554431;
    mul_results[9] += mul_results[8] >> 26;
    mul_results[8] &= 67108863;
    mul_results[0] += (mul_results[9] >> 25) * 19;
    mul_results[9] &= 33554431;
    mul_results[1] += mul_results[0] >> 26;
    mul_results[0] &= 67108863;

    dst[0] = (field_entry_t)mul_results[0];
    dst[1] = (field_entry_t)mul_results[1];
    dst[2] = (field_entry_t)mul_results[2];
    dst[3] = (field_entry_t)mul_results[3];
    dst[4] = (field_entry_t)mul_results[4];
    dst[5] = (field_entry_t)mul_results[5];
    dst[6] = (field_entry_t)mul_results[6];
    dst[7] = (field_entry_t)mul_results[7];
    dst[8] = (field_entry_t)mul_results[8];
    dst[9] = (field_entry_t)mul_results[9];
    //[[[end]]]
}

// source: supercop amd64-51
void decode_point(field_t dst, byte32_t src) {
    /*[[[cog
    algorithm.decode_point("decode_results", "src")
    ]]]*/
    field_entry_t decode_results[10] = {0};

    decode_results[0] += (field_entry_t)src[0] << 0;
    decode_results[0] += (field_entry_t)src[1] << 8;
    decode_results[0] += (field_entry_t)src[2] << 16;
    decode_results[0] += ((field_entry_t)src[3] & 3) << 24;
    decode_results[1] = (field_entry_t)src[3] >> 2;
    decode_results[1] += (field_entry_t)src[4] << 6;
    decode_results[1] += (field_entry_t)src[5] << 14;
    decode_results[1] += ((field_entry_t)src[6] & 7) << 22;
    decode_results[2] = (field_entry_t)src[6] >> 3;
    decode_results[2] += (field_entry_t)src[7] << 5;
    decode_results[2] += (field_entry_t)src[8] << 13;
    decode_results[2] += ((field_entry_t)src[9] & 31) << 21;
    decode_results[3] = (field_entry_t)src[9] >> 5;
    decode_results[3] += (field_entry_t)src[10] << 3;
    decode_results[3] += (field_entry_t)src[11] << 11;
    decode_results[3] += ((field_entry_t)src[12] & 63) << 19;
    decode_results[4] = (field_entry_t)src[12] >> 6;
    decode_results[4] += (field_entry_t)src[13] << 2;
    decode_results[4] += (field_entry_t)src[14] << 10;
    decode_results[4] += (field_entry_t)src[15] << 18;
    decode_results[5] = (field_entry_t)src[16];
    decode_results[5] += (field_entry_t)src[17] << 8;
    decode_results[5] += (field_entry_t)src[18] << 16;
    decode_results[5] += ((field_entry_t)src[19] & 1) << 24;
    decode_results[6] = (field_entry_t)src[19] >> 1;
    decode_results[6] += (field_entry_t)src[20] << 7;
    decode_results[6] += (field_entry_t)src[21] << 15;
    decode_results[6] += ((field_entry_t)src[22] & 7) << 23;
    decode_results[7] = (field_entry_t)src[22] >> 3;
    decode_results[7] += (field_entry_t)src[23] << 5;
    decode_results[7] += (field_entry_t)src[24] << 13;
    decode_results[7] += ((field_entry_t)src[25] & 15) << 21;
    decode_results[8] = (field_entry_t)src[25] >> 4;
    decode_results[8] += (field_entry_t)src[26] << 4;
    decode_results[8] += (field_entry_t)src[27] << 12;
    decode_results[8] += ((field_entry_t)src[28] & 63) << 20;
    decode_results[9] = (field_entry_t)src[28] >> 6;
    decode_results[9] += (field_entry_t)src[29] << 2;
    decode_results[9] += (field_entry_t)src[30] << 10;
    decode_results[9] += ((field_entry_t)src[31] & 127) << 18;
    //[[[end]]]

    /*[[[cog
    algorithm.propagate_carry("dst", "decode_results", "field_entry_t")
    ]]]*/
    decode_results[1] += decode_results[0] >> 26;
    decode_results[0] &= 67108863;
    decode_results[2] += decode_results[1] >> 25;
    decode_results[1] &= 33554431;
    decode_results[3] += decode_results[2] >> 26;
    decode_results[2] &= 67108863;
    decode_results[4] += decode_results[3] >> 25;
    decode_results[3] &= 33554431;
    decode_results[5] += decode_results[4] >> 26;
    decode_results[4] &= 67108863;
    decode_results[6] += decode_results[5] >> 25;
    decode_results[5] &= 33554431;
    decode_results[7] += decode_results[6] >> 26;
    decode_results[6] &= 67108863;
    decode_results[8] += decode_results[7] >> 25;
    decode_results[7] &= 33554431;
    decode_results[9] += decode_results[8] >> 26;
    decode_results[8] &= 67108863;
    decode_results[0] += (decode_results[9] >> 25) * 19;
    decode_results[9] &= 33554431;
    decode_results[1] += decode_results[0] >> 26;
    decode_results[0] &= 67108863;

    dst[0] = (field_entry_t)decode_results[0];
    dst[1] = (field_entry_t)decode_results[1];
    dst[2] = (field_entry_t)decode_results[2];
    dst[3] = (field_entry_t)decode_results[3];
    dst[4] = (field_entry_t)decode_results[4];
    dst[5] = (field_entry_t)decode_results[5];
    dst[6] = (field_entry_t)decode_results[6];
    dst[7] = (field_entry_t)decode_results[7];
    dst[8] = (field_entry_t)decode_results[8];
    dst[9] = (field_entry_t)decode_results[9];
    //[[[end]]]
}

// source: supercop amd64-51
void encode_point(byte32_t dst, field_t src) {
    /*[[[cog
    algorithm.propagate_carry_pre_encode_point("src")
    ]]]*/
    field_entry_mul_t carry[10];

    field_entry_t q = (19*src[9] + ((field_entry_t)16777216)) >> 25;

    q = (src[0] + q) >> 26;
    q = (src[1] + q) >> 25;
    q = (src[2] + q) >> 26;
    q = (src[3] + q) >> 25;
    q = (src[4] + q) >> 26;
    q = (src[5] + q) >> 25;
    q = (src[6] + q) >> 26;
    q = (src[7] + q) >> 25;
    q = (src[8] + q) >> 26;
    q = (src[9] + q) >> 25;
    src[0] += 19 * q;

    carry[0] = src[0] >> 26;
    src[0] -= carry[0] << 26;
    src[1] += carry[0];
    carry[1] = src[1] >> 25;
    src[1] -= carry[1] << 25;
    src[2] += carry[1];
    carry[2] = src[2] >> 26;
    src[2] -= carry[2] << 26;
    src[3] += carry[2];
    carry[3] = src[3] >> 25;
    src[3] -= carry[3] << 25;
    src[4] += carry[3];
    carry[4] = src[4] >> 26;
    src[4] -= carry[4] << 26;
    src[5] += carry[4];
    carry[5] = src[5] >> 25;
    src[5] -= carry[5] << 25;
    src[6] += carry[5];
    carry[6] = src[6] >> 26;
    src[6] -= carry[6] << 26;
    src[7] += carry[6];
    carry[7] = src[7] >> 25;
    src[7] -= carry[7] << 25;
    src[8] += carry[7];
    carry[8] = src[8] >> 26;
    src[8] -= carry[8] << 26;
    src[9] += carry[8];
    carry[9] = src[9] >> 25;
    src[9] -= carry[9] << 25;
    //[[[end]]]

    /*[[[cog
    algorithm.encode_point("dst", "src")
    ]]]*/
    dst[0] = (input_t)(src[0]);
    dst[1] = (input_t)(src[0] >> 8);
    dst[2] = (input_t)(src[0] >> 16);
    dst[3] = (input_t)(src[0] >> 24);
    dst[3] |= (input_t)(src[1] << 2);
    dst[4] = (input_t)(src[1] >> 6);
    dst[5] = (input_t)(src[1] >> 14);
    dst[6] = (input_t)(src[1] >> 22);
    dst[6] |= (input_t)(src[2] << 3);
    dst[7] = (input_t)(src[2] >> 5);
    dst[8] = (input_t)(src[2] >> 13);
    dst[9] = (input_t)(src[2] >> 21);
    dst[9] |= (input_t)(src[3] << 5);
    dst[10] = (input_t)(src[3] >> 3);
    dst[11] = (input_t)(src[3] >> 11);
    dst[12] = (input_t)(src[3] >> 19);
    dst[12] |= (input_t)(src[4] << 6);
    dst[13] = (input_t)(src[4] >> 2);
    dst[14] = (input_t)(src[4] >> 10);
    dst[15] = (input_t)(src[4] >> 18);
    dst[16] = (input_t)(src[4] >> 26);
    dst[16] |= (input_t)(src[5]);
    dst[17] = (input_t)(src[5] >> 8);
    dst[18] = (input_t)(src[5] >> 16);
    dst[19] = (input_t)(src[5] >> 24);
    dst[19] |= (input_t)(src[6] << 1);
    dst[20] = (input_t)(src[6] >> 7);
    dst[21] = (input_t)(src[6] >> 15);
    dst[22] = (input_t)(src[6] >> 23);
    dst[22] |= (input_t)(src[7] << 3);
    dst[23] = (input_t)(src[7] >> 5);
    dst[24] = (input_t)(src[7] >> 13);
    dst[25] = (input_t)(src[7] >> 21);
    dst[25] |= (input_t)(src[8] << 4);
    dst[26] = (input_t)(src[8] >> 4);
    dst[27] = (input_t)(src[8] >> 12);
    dst[28] = (input_t)(src[8] >> 20);
    dst[28] |= (input_t)(src[9] << 6);
    dst[29] = (input_t)(src[9] >> 2);
    dst[30] = (input_t)(src[9] >> 10);
    dst[31] = (input_t)(src[9] >> 18);
    //[[[end]]]
}

// swap (a, b) with (b, a) iff swap == 1.
void cswap(field_entry_t swap, field_t a, field_t b) {
    /*[[[cog
    algorithm.swap("swap", "a", "b")
    ]]]*/
    swap = -swap;
    field_entry_t t;
    t = swap & (a[0] ^ b[0]);
    a[0] ^= t;
    b[0] ^= t;
    t = swap & (a[1] ^ b[1]);
    a[1] ^= t;
    b[1] ^= t;
    t = swap & (a[2] ^ b[2]);
    a[2] ^= t;
    b[2] ^= t;
    t = swap & (a[3] ^ b[3]);
    a[3] ^= t;
    b[3] ^= t;
    t = swap & (a[4] ^ b[4]);
    a[4] ^= t;
    b[4] ^= t;
    t = swap & (a[5] ^ b[5]);
    a[5] ^= t;
    b[5] ^= t;
    t = swap & (a[6] ^ b[6]);
    a[6] ^= t;
    b[6] ^= t;
    t = swap & (a[7] ^ b[7]);
    a[7] ^= t;
    b[7] ^= t;
    t = swap & (a[8] ^ b[8]);
    a[8] ^= t;
    b[8] ^= t;
    t = swap & (a[9] ^ b[9]);
    a[9] ^= t;
    b[9] ^= t;
    //[[[end]]]
}

// taken from djb's original implementation
void field_invert(field_t dst, field_t src) {
    field_t z2, z9, z11, z2_5_0, z2_10_0, z2_20_0, z2_50_0, z2_100_0, t0, t1;
    int i;

    field_square(z2,src);           // 2
    field_square(t1,z2);            // 4
    field_square(t0,t1);            // 8
    field_mul(z9,t0,src);           // 9
    field_mul(z11,z9,z2);           // 11
    field_square(t0,z11);           // 22
    field_mul(z2_5_0,t0,z9);        // 2^5 - 2^0 = 31

    field_square(t0,z2_5_0);        // 2^6 - 2^1
    field_square(t1,t0);            // 2^7 - 2^2
    field_square(t0,t1);            // 2^8 - 2^3
    field_square(t1,t0);            // 2^9 - 2^4
    field_square(t0,t1);            // 2^10 - 2^5
    field_mul(z2_10_0,t0,z2_5_0);   // 2^10 - 2^0

    field_square(t0,z2_10_0);       // 2^11 - 2^1
    field_square(t1,t0);            // 2^12 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^20 - 2^10
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_20_0,t1,z2_10_0);  // 2^20 - 2^0

    field_square(t0,z2_20_0);       // 2^21 - 2^1
    field_square(t1,t0);            // 2^22 - 2^2
    for (i = 2;i < 20;i += 2) {     // 2^40 - 2^20
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_20_0);       // 2^40 - 2^0

    field_square(t1,t0);            // 2^41 - 2^1
    field_square(t0,t1);            // 2^42 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^50 - 2^10
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(z2_50_0,t0,z2_10_0);  // 2^50 - 2^0

    field_square(t0,z2_50_0);       // 2^51 - 2^1
    field_square(t1,t0);            // 2^52 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^100 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_100_0,t1,z2_50_0); // 2^100 - 2^0

    field_square(t1,z2_100_0);      // 2^101 - 2^1
    field_square(t0,t1);            // 2^102 - 2^2
    for (i = 2;i < 100;i += 2) {    // 2^200 - 2^100
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(t1,t0,z2_100_0);      // 2^200 - 2^0

    field_square(t0,t1);            // 2^201 - 2^1
    field_square(t1,t0);            // 2^202 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^250 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_50_0);       // 2^250 - 2^0

    field_square(t1,t0);            // 2^251 - 2^1
    field_square(t0,t1);            // 2^252 - 2^2
    field_square(t1,t0);            // 2^253 - 2^3
    field_square(t0,t1);            // 2^254 - 2^4
    field_square(t1,t0);            // 2^255 - 2^5
    field_mul(dst,t1,z11);          // 2^255 - 21
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
// see bernstein page 5, upper paragrpah for secret key definition
void decode_scalar(byte32_t dst, byte32_t src) {
    memcpy(dst, src, sizeof(byte32_t));
    dst[0] &= 248; // ensure multiple of 8 (248 = 1111 1000)
    dst[31] &= 127; // ensure biggest secret key <= 8*(2^251 - 1) = 2^254 - 1 (127 = 0111 1111)
    dst[31] |= 64; // ensure secret key offset of + 2^254 (64 = 0100 0000) 
}

// As per RFC 7748, Chapter 5
void curve_scalar_mult(field_t dst, byte32_t n, field_t P) {
    field_t x_1; memcpy(x_1, P, sizeof(field_t));
    field_t x_2 = { 1 };
    field_t z_2 = { 0 };
    field_t x_3; memcpy(x_3, P, sizeof(field_t));
    field_t z_3 = { 1 };
    field_entry_t swap = 0;

    for (int32_t i = 254; i >= 0; i--) {
        int32_t bit = (n[i / 8] >> (i & 7)) & 1;
        swap ^= bit;
        cswap(swap, x_2, x_3);
        cswap(swap, z_2, z_3);
        swap = bit;

        field_t A, AA, B, BB, E, C, D, DA, CB;
        field_t t0;

        field_add(A, x_2, z_2);     // A = x_2 + z_2
        field_square(AA, A);        // AA = A^2
        field_sub(B, x_2, z_2);     // B = x_2 - z_2
        field_square(BB, B);        // BB = B^2
        field_sub(E, AA, BB);       // E = AA - BB
        field_add(C, x_3, z_3);     // C = x_3 + z_3
        field_sub(D, x_3, z_3);     // D = x_3 - z_3
        field_mul(DA, D, A);        // DA = D * A
        field_mul(CB, C, B);        // CB = C * B
        field_add(t0, DA, CB);      // x_3 = (DA + CB)^2
        field_square(x_3, t0);
        field_sub(t0, DA, CB);      // z_3 = x_1 * (DA - CB)^2
        field_square(t0, t0);
        field_mul(z_3, t0, x_1);
        field_mul(x_2, AA, BB);     // x_2 = AA * BB
        field_mul_a24(t0, E);       // z_2 = E * (AA + a24 * E)
        field_add(t0, AA, t0);
        field_mul(z_2, E, t0);
    }

    cswap(swap, x_2, x_3);
    cswap(swap, z_2, z_3);
    field_invert(z_2, z_2);         // z_2 = z_2 ^-1
    field_mul(dst, x_2, z_2);       // dst = x_2 * z_2
}

void curve25519(byte32_t dst, byte32_t n, byte32_t P) {
    byte32_t scalar;
    decode_scalar(scalar, n);

    field_t base, result;
    decode_point(base, P);
    curve_scalar_mult(result, scalar, base);

    encode_point(dst, result);
}

int crypto_scalarmult(unsigned char * dst,
                      const unsigned char *n,
                      const unsigned char *P) {
    curve25519((uint8_t *) dst, (uint8_t *) n, (uint8_t *) P);
    return 0;
}

/*[[[cog
algorithm.evaluate(field_entry_mul_t == "__int128_t")
]]]*/
// #####                      #####
// ##### operations by method #####
// #####                      #####
// 
//     10 adds                                                                                                                                     | add
//                     10 subs                                                                                                                     | sub
//     78 adds                         76 mults                        33 srts         33 ands                                                     | square
//    123 adds                        117 mults                        33 srts         33 ands                                                     | mul
//     33 adds                         10 mults                        33 srts         33 ands                                                     | mul a24
//     42 adds                                         31 slts         19 srts         20 ands                                                     | decode point
//     29 adds         18 subs         11 mults        26 slts         60 srts                          9 ors                                      | encode point
//                      1 subs                                                         10 ands                         30 xors                     | swap
//  12420 adds                      20591 mults                                                                                                    | invert
//      3 adds                                                                                                                                     | decode scalar
// 267543 adds      10712 subs     249953 mults       255 slts      84183 srts      89813 ands                      15615 xors                     | curve mul
// ==========================================================
// 267617 adds      10730 subs     249964 mults       312 slts      84262 srts      89833 ands          9 ors       15615 xors                     | curve25519


// #####                      #####
// ##### method * call_count) #####
// #####                      #####
// 
//  10200 adds                                                                                                                                     | add
//                  10200 subs                                                                                                                     | sub
//  79560 adds                      77520 mults                     33660 srts      33660 ands                                                     | square
// 156948 adds                     149292 mults                     42108 srts      42108 ands                                                     | mul
//   8415 adds                       2550 mults                      8415 srts       8415 ands                                                     | mul a24
//     42 adds                                         31 slts         19 srts         20 ands                                                     | decode point
//     29 adds         18 subs         11 mults        26 slts         60 srts                          9 ors                                      | encode point
//                    512 subs                                                       5120 ands                      15360 xors                     | swap
//  12420 adds                      20591 mults                                                                                                    | invert
//      3 adds                                                                                                                                     | decode scalar
// 267543 adds      10712 subs     249953 mults       255 slts      84183 srts      89813 ands                      15615 xors                     | curve mul
// 267617 adds      10730 subs     249964 mults       312 slts      84262 srts      89833 ands          9 ors       15615 xors                     | total
// ==========================================================
// 267617 adds      10730 subs     249964 mults       312 slts      84262 srts      89833 ands          9 ors       15615 xors                     | curve25519
//[[[end]]]