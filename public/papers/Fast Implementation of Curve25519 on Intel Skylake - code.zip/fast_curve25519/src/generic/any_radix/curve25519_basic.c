#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <assert.h>
#include <math.h>
#define static_assert _Static_assert

// ==== CONFIGURATION ====

// radix defines how many bits are used per limb
#define RADIX 51
static_assert(((int)(255.0/RADIX))*RADIX == 255.0, "RADIX must be an exact multiple of 255");

// the limb count is a direct consequence of the chosen radix
#define LIMB_COUNT 5
static_assert(((int)(255.0/RADIX)) == LIMB_COUNT, "LIMB_COUNT must be exactly 255/RADIX");

// choose a datatypes suitably big according to the bits per limp
#define LIMB_T int64_t

// choose a datatype suitable big for multiplying two limps together
#define LIMB_MUL_T __int128_t

// ==== ENDCONFIGURATION ====

typedef LIMB_T field_entry_t;
typedef field_entry_t field_t[LIMB_COUNT];
typedef LIMB_MUL_T field_entry_mul_t;


int limb_bit_count[LIMB_COUNT];
LIMB_MUL_T limb_mul_collection[LIMB_COUNT*LIMB_COUNT];

void field_add(field_t dst, field_t a, field_t b) {
    for (unsigned i = 0; i < LIMB_COUNT; i++) {
        dst[i] = a[i] + b[i];
    }
}

void field_sub(field_t dst, field_t a, field_t b) {
    for (unsigned i = 0; i < LIMB_COUNT; i++) {
        dst[i] = a[i] - b[i];
    }
}

// include field_propagate_carry_field_entry_mul_t
#define LIMB_SOURCE_MUL_TYPE field_entry_mul_t
    #include "field_propagate_carry.h"
#undef LIMB_SOURCE_MUL_TYPE

void field_square(field_t dst, field_t src) {
    field_entry_mul_t mul_results[2*LIMB_COUNT-1] = {0};
    for (int i = 0; i < LIMB_COUNT; i++) {
        mul_results[i+i] += (field_entry_mul_t)src[i] * src[i] * limb_mul_collection[i*LIMB_COUNT+i];
        for (int j = i+1; j < LIMB_COUNT; j++) {
            mul_results[i+j] += 2 * (field_entry_mul_t)src[i] * src[j] * limb_mul_collection[i*LIMB_COUNT+j]; 
        }
    }

    for (int i = LIMB_COUNT; i < 2*LIMB_COUNT-1; i++) {
        mul_results[i-LIMB_COUNT] += mul_results[i] * 19;
    }
    
    field_propagate_carry_field_entry_mul_t(dst, mul_results);
}

void field_mul(field_t dst, field_t a, field_t b) {
    field_entry_mul_t mul_results[2*LIMB_COUNT-1] = {0};
    
    for (int i = 0; i < LIMB_COUNT; i++) {
        for (int j = 0; j < LIMB_COUNT; j++) {
            mul_results[i+j] += (field_entry_mul_t)a[i] * b[j] * limb_mul_collection[i*LIMB_COUNT+j];
        }
    }

    for (int i = LIMB_COUNT; i < 2*LIMB_COUNT-1; i++) {
        mul_results[i-LIMB_COUNT] += mul_results[i] * 19;
    }

    field_propagate_carry_field_entry_mul_t(dst, mul_results);
}

void field_mul_a24(field_t dst, field_t src) {
    const int a24 = 121665;
    
    field_entry_mul_t mul_results[LIMB_COUNT] = {0};

    for (int i = 0; i < LIMB_COUNT; i++) {
        mul_results[i] = (field_entry_mul_t) src[i] * a24;
    }

    field_propagate_carry_field_entry_mul_t(dst, mul_results);
}


#define INPUT_COUNT 32
#define INPUT_BIT_COUNT 8
#define INPUT_TOTAL_BITS 255
#define INPUT_T uint8_t

typedef INPUT_T byte32_t[INPUT_COUNT];

// include field_propagate_carry_field_entry_mul_t
#define LIMB_SOURCE_MUL_TYPE field_entry_t
    #include "field_propagate_carry.h"
#undef LIMB_SOURCE_MUL_TYPE

// source: supercop amd64-51
void decode_point(field_t dst, byte32_t src) {
    field_entry_t decode_results[LIMB_COUNT] = {0};

    int limb = 0;
    int current_offset = 0;
    for (int i = 0; i < INPUT_COUNT; i++) {
        int offset = limb_bit_count[limb] - current_offset;
        if (offset < INPUT_BIT_COUNT) {
            int keep_mask = (1 << offset) - 1;
            decode_results[limb] += ((field_entry_t)src[i] & keep_mask) << current_offset;
            
            limb++;
            if (limb == LIMB_COUNT) {
                break;
            }
            
            decode_results[limb] = (field_entry_t)src[i] >> offset;
            current_offset = -offset;
        } else {
            decode_results[limb] += (field_entry_t)src[i] << current_offset;
        }
        
        current_offset += INPUT_BIT_COUNT;
    }

    field_propagate_carry_field_entry_t(dst, decode_results);
}

// source: supercop amd64-51
void encode_point(byte32_t dst, field_t src) {
    
    field_entry_mul_t carry[LIMB_COUNT];

    field_entry_t q = (19*src[LIMB_COUNT-1] + ((field_entry_t)1 << (limb_bit_count[LIMB_COUNT-1]-1))) >> limb_bit_count[LIMB_COUNT-1];
    
    for (int i = 0; i < LIMB_COUNT; i++) {
        q = (src[i] + q) >> limb_bit_count[i];
    }

    // Goal: Output h-(2^255-19)q, which is between 0 and 2^255-20.
    src[0] += 19 * q;
    // Goal: Output h-2^255 q, which is between 0 and 2^255-20.
    
    int i = 0;
    for (; i < LIMB_COUNT-1; i++) {
        carry[i] = src[i] >> limb_bit_count[i];
        src[i] -= carry[i] << limb_bit_count[i];
        src[i+1] += carry[i];
    }
    carry[i] = src[i] >> limb_bit_count[i];
    src[i] -= carry[i] << limb_bit_count[i];
    

    int limb = 0;
    int current_offset = 0;
    for (int i = 0; i < INPUT_COUNT; i++) {
        dst[i] = (INPUT_T)(src[limb] >> current_offset);

        int offset = limb_bit_count[limb] - current_offset;
        if (offset < INPUT_BIT_COUNT) {
            limb++;
            if (limb == LIMB_COUNT) {
                break;
            }

            dst[i] |= (INPUT_T)(src[limb] << offset);
            current_offset = -offset;
        }
        
        current_offset += INPUT_BIT_COUNT;
    }
}

int initialized = 0;
void initialize()
{
    if (initialized) {
        return;
    }

    int mul_limb_bit_count[2*LIMB_COUNT-1];
    int previous_bit_count = 0;
    for (int i = 0; i < LIMB_COUNT; i++) {
        int target_bit_count = ceil(RADIX*(i+1));
        mul_limb_bit_count[i] = target_bit_count - previous_bit_count;
        previous_bit_count = target_bit_count;    
    }

    memcpy(mul_limb_bit_count+LIMB_COUNT, mul_limb_bit_count, sizeof(int)*(LIMB_COUNT-1));

    int source_limp_1_bit = 0;
    for (int i = 0; i < LIMB_COUNT; i++) {
        int source_limp_2_bit = 0;
        int target_limp_bit = source_limp_1_bit;
        for (int j = 0; j < LIMB_COUNT; j++) {
            int shift = (source_limp_1_bit + source_limp_2_bit - target_limp_bit) % 255;
            limb_mul_collection[i*LIMB_COUNT+j] = pow(2, shift);

            target_limp_bit += mul_limb_bit_count[i+j];
            source_limp_2_bit += mul_limb_bit_count[j];
        }

        source_limp_1_bit += mul_limb_bit_count[i];
    }

    memcpy(limb_bit_count, mul_limb_bit_count, sizeof(int)*LIMB_COUNT);
    initialized = 1;
}

// swap (a, b) with (b, a) iff swap == 1.
void cswap(field_entry_t swap, field_t a, field_t b) {
    swap = -swap;
    for (unsigned i = 0; i < LIMB_COUNT; i++) {
        field_entry_t t = swap & (a[i] ^ b[i]);
        a[i] ^= t;
        b[i] ^= t;
    }
}

// taken from djb's original implementation
void field_invert(field_t dst, field_t src) {
    field_t z2, z9, z11, z2_5_0, z2_10_0, z2_20_0, z2_50_0, z2_100_0, t0, t1;
    int i;

    field_square(z2,src);           // 2
    field_square(t1,z2);            // 4
    field_square(t0,t1);            // 8
    field_mul(z9,t0,src);           // 9
    field_mul(z11,z9,z2);           // 11
    field_square(t0,z11);           // 22
    field_mul(z2_5_0,t0,z9);        // 2^5 - 2^0 = 31

    field_square(t0,z2_5_0);        // 2^6 - 2^1
    field_square(t1,t0);            // 2^7 - 2^2
    field_square(t0,t1);            // 2^8 - 2^3
    field_square(t1,t0);            // 2^9 - 2^4
    field_square(t0,t1);            // 2^10 - 2^5
    field_mul(z2_10_0,t0,z2_5_0);   // 2^10 - 2^0

    field_square(t0,z2_10_0);       // 2^11 - 2^1
    field_square(t1,t0);            // 2^12 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^20 - 2^10
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_20_0,t1,z2_10_0);  // 2^20 - 2^0

    field_square(t0,z2_20_0);       // 2^21 - 2^1
    field_square(t1,t0);            // 2^22 - 2^2
    for (i = 2;i < 20;i += 2) {     // 2^40 - 2^20
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_20_0);       // 2^40 - 2^0

    field_square(t1,t0);            // 2^41 - 2^1
    field_square(t0,t1);            // 2^42 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^50 - 2^10
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(z2_50_0,t0,z2_10_0);  // 2^50 - 2^0

    field_square(t0,z2_50_0);       // 2^51 - 2^1
    field_square(t1,t0);            // 2^52 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^100 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_100_0,t1,z2_50_0); // 2^100 - 2^0

    field_square(t1,z2_100_0);      // 2^101 - 2^1
    field_square(t0,t1);            // 2^102 - 2^2
    for (i = 2;i < 100;i += 2) {    // 2^200 - 2^100
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(t1,t0,z2_100_0);      // 2^200 - 2^0

    field_square(t0,t1);            // 2^201 - 2^1
    field_square(t1,t0);            // 2^202 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^250 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_50_0);       // 2^250 - 2^0

    field_square(t1,t0);            // 2^251 - 2^1
    field_square(t0,t1);            // 2^252 - 2^2
    field_square(t1,t0);            // 2^253 - 2^3
    field_square(t0,t1);            // 2^254 - 2^4
    field_square(t1,t0);            // 2^255 - 2^5
    field_mul(dst,t1,z11);          // 2^255 - 21
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
// see bernstein page 5, upper paragrpah for secret key definition
void decode_scalar(byte32_t dst, byte32_t src) {
    memcpy(dst, src, sizeof(byte32_t));
    dst[0] &= 248; // ensure multiple of 8 (248 = 1111 1000)
    dst[31] &= 127; // ensure biggest secret key <= 8*(2^251 - 1) = 2^254 - 1 (127 = 0111 1111)
    dst[31] |= 64; // ensure secret key offset of + 2^254 (64 = 0100 0000) 
}

// As per RFC 7748, Chapter 5
void curve_scalar_mult(field_t dst, byte32_t n, field_t P) {
    field_t x_1; memcpy(x_1, P, sizeof(field_t));
    field_t x_2 = { 1 };
    field_t z_2 = { 0 };
    field_t x_3; memcpy(x_3, P, sizeof(field_t));
    field_t z_3 = { 1 };
    field_entry_t swap = 0;

    for (int32_t i = 254; i >= 0; i--) {
        int32_t bit = (n[i / 8] >> (i & 7)) & 1;
        swap ^= bit;
        cswap(swap, x_2, x_3);
        cswap(swap, z_2, z_3);
        swap = bit;

        field_t A, AA, B, BB, E, C, D, DA, CB;
        field_t t0;

        field_add(A, x_2, z_2);     // A = x_2 + z_2
        field_square(AA, A);        // AA = A^2
        field_sub(B, x_2, z_2);     // B = x_2 - z_2
        field_square(BB, B);        // BB = B^2
        field_sub(E, AA, BB);       // E = AA - BB
        field_add(C, x_3, z_3);     // C = x_3 + z_3
        field_sub(D, x_3, z_3);     // D = x_3 - z_3
        field_mul(DA, D, A);        // DA = D * A
        field_mul(CB, C, B);        // CB = C * B
        field_add(t0, DA, CB);      // x_3 = (DA + CB)^2
        field_square(x_3, t0);
        field_sub(t0, DA, CB);      // z_3 = x_1 * (DA - CB)^2
        field_square(t0, t0);
        field_mul(z_3, t0, x_1);
        field_mul(x_2, AA, BB);     // x_2 = AA * BB
        field_mul_a24(t0, E);       // z_2 = E * (AA + a24 * E)
        field_add(t0, AA, t0);
        field_mul(z_2, E, t0);
    }

    cswap(swap, x_2, x_3);
    cswap(swap, z_2, z_3);
    field_invert(z_2, z_2);         // z_2 = z_2 ^-1
    field_mul(dst, x_2, z_2);       // dst = x_2 * z_2
}

void curve25519(byte32_t dst, byte32_t n, byte32_t P) {
    byte32_t scalar;
    decode_scalar(scalar, n);

    field_t base, result;
    decode_point(base, P);
    curve_scalar_mult(result, scalar, base);

    encode_point(dst, result);
}

int crypto_scalarmult(unsigned char * dst,
                      const unsigned char *n,
                      const unsigned char *P) {
    initialize();

    curve25519((uint8_t *) dst, (uint8_t *) n, (uint8_t *) P);
    return 0;
}

