#ifndef CRYPTO_SCALARMULT_H
#define CRYPTO_SCALARMULT_H

int crypto_scalarmult(unsigned char *, const unsigned char *, const unsigned char *);
// int crypto_scalarmult_base(unsigned char *, const unsigned char *);

#endif // CRYPTO_SCALARMULT_H
