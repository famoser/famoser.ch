#ifndef CRYPTO_INT32_H
#define CRYPTO_INT32_H

#include <inttypes.h>

typedef int32_t crypto_int32;

#endif // CRYPTO_INT32_H
