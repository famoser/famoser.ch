#ifndef CRYPTO_UINT64_H
#define CRYPTO_UINT64_H

#include <inttypes.h>

typedef uint64_t crypto_uint64;

#endif // CRYPTO_UINT64_H
