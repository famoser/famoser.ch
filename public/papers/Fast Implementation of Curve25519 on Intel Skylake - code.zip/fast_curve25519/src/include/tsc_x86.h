#include <stdint.h>

/*
 * Benchmarking functions to measure execution times in cycles.
 * Implemented according to Intel's "How to Benchmark Code Execution Times on
 * Intel®IA-32 and IA-64 Instruction Set Architectures".
 */

typedef union {
    uint64_t uint64;
    struct {
        uint32_t lo, hi;
    } uint32;
} tsc_counter;

static inline uint64_t start_tsc(void) {
    tsc_counter start;
    __asm__  __volatile__ ("CPUID\n\t"
                   "RDTSC\n\t"
                   "mov %%edx, %0\n\t"
                   "mov %%eax, %1\n\t"
                   : "=r" (start.uint32.hi), "=r" (start.uint32.lo)
                   :: "%rax", "%rbx", "%rcx", "%rdx");
    return start.uint64;
}

static inline uint64_t stop_tsc(uint64_t start) {
    tsc_counter end;
    __asm__ __volatile__ ("RDTSCP\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                  "CPUID\n\t"
                  : "=r" (end.uint32.hi), "=r" (end.uint32.lo)
                  :: "%rax", "%rbx", "%rcx", "%rdx");
    return end.uint64 - start;
}

static inline uint64_t tsc_overhead(int32_t n) {
    uint64_t overhead = 0;
    for (int i = 0; i < n; i++) {
        uint64_t start = start_tsc();
        uint64_t end = stop_tsc(start);
        if (end > start) {
            overhead += end - start;
        }
    }
    return overhead / n;
}
