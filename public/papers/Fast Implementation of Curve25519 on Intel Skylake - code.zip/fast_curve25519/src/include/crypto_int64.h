#ifndef CRYPTO_INT64_H
#define CRYPTO_INT64_H

#include <inttypes.h>

typedef int64_t crypto_int64;

#endif // CRYPTO_INT64_H
