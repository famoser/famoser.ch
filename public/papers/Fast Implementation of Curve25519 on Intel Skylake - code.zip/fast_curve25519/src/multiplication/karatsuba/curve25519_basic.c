#include <stdio.h>
#include <string.h>

#include "curve25519_basic.h"

#define a24 121665


void field_add(field_t dst, field_t a, field_t b) {
    for (unsigned i = 0; i < 5; i++) {
        dst[i] = a[i] + b[i];
    }
}

void field_sub(field_t dst, field_t a, field_t b) {
    for (unsigned i = 0; i < 5; i++) {
        dst[i] = a[i] - b[i];
    }
}

void field_square(field_t dst, field_t src) {
    int64_t f0 = src[0];
    int64_t f1 = src[1];
    int64_t f2 = src[2];
    int64_t f3 = src[3];
    int64_t f4 = src[4];
    
    int128_t f0f0 = (int128_t) f0 * f0;
    int128_t f0f1 =(int128_t) f0 * f1;
    int128_t f0f2 =(int128_t) f0 * f2;
    int128_t f0f3 =(int128_t) f0 * f3;
    int128_t f0f4 =(int128_t) f0 * f4;

    int128_t f1f0 = f0f1;
    int128_t f1f1 = (int128_t) f1 * f1;
    int128_t f1f2 = (int128_t) f1 * f2;
    int128_t f1f3 = (int128_t) f1 * f3;
    int128_t f1f4 = (int128_t) f1 * f4;

    int128_t f2f0 = f0f2;
    int128_t f2f1 = f1f2;
    int128_t f2f2 = (int128_t) f2 * f2;
    int128_t f2f3 = (int128_t) f2 * f3;
    int128_t f2f4 = (int128_t) f2 * f4;
    
    int128_t f3f0 = f0f3;
    int128_t f3f1 = f1f3;
    int128_t f3f2 = f2f3;
    int128_t f3f3 = (int128_t) f3 * f3;
    int128_t f3f4 = (int128_t) f3 * f4;

    int128_t f4f0 = f0f4;
    int128_t f4f1 = f1f4;
    int128_t f4f2 = f2f4;
    int128_t f4f3 = f3f4;
    int128_t f4f4 = (int128_t) f4 * f4;

    int128_t h0 = f0f0;
    int128_t h1 = f0f1 + f1f0;
    int128_t h2 = f0f2 + f1f1 + f2f0;
    int128_t h3 = f0f3 + f1f2 + f2f1 + f3f0;
    int128_t h4 = f0f4 + f1f3 + f2f2 + f3f1 + f4f0;

    int128_t h5 = f1f4 + f2f3 + f3f2 + f4f1;
    int128_t h6 = f2f4 + f3f3 + f4f2;
    int128_t h7 = f3f4 + f4f3;
    int128_t h8 = f4f4;

    h0 += 19*h5;
    h1 += 19*h6;
    h2 += 19*h7;
    h3 += 19*h8;

    int128_t carry[5];

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    carry[1] = (h1 + ((int64_t)1 << 50)) >> 51;
    h2 += carry[1];
    h1 -= carry[1] << 51;

    carry[2] = (h2 + ((int64_t)1 << 50)) >> 51;
    h3 += carry[2];
    h2 -= carry[2] << 51;

    carry[3] = (h3 + ((int64_t)1 << 50)) >> 51;
    h4 += carry[3];
    h3 -= carry[3] << 51;

    carry[4] = (h4 + ((int64_t)1 << 50)) >> 51;
    h0 += carry[4] * 19; // TODO
    h4 -= carry[4] << 51;

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    dst[0] = (int64_t) h0;
    dst[1] = (int64_t) h1;
    dst[2] = (int64_t) h2;
    dst[3] = (int64_t) h3;
    dst[4] = (int64_t) h4;
}

typedef int64_t karatsuba_entry[3];
typedef int64_t karatsuba_entry_small[2];
typedef int128_t karatsuba_result[5];
typedef int128_t karatsuba_result_small[3];

void karatsuba_mul(karatsuba_result dst, karatsuba_entry one, karatsuba_entry two)
{
    dst[0] = (int128_t)one[0] * two[0];
    dst[1] = (int128_t)one[0] * two[1] + (int128_t)one[1] * two[0];
    dst[2] = (int128_t)one[0] * two[2] + (int128_t)one[1] * two[1] + (int128_t)one[2] * two[0];
    dst[3] = (int128_t)one[1] * two[2] + (int128_t)one[2] * two[1];
    dst[4] = (int128_t)one[2] * two[2];
}

void karatsuba_mul_small(karatsuba_result_small dst, karatsuba_entry_small one, karatsuba_entry_small two)
{
    dst[0] = (int128_t)one[0] * two[0];
    dst[1] = (int128_t)one[0] * two[1] + (int128_t)one[1] * two[0];
    dst[2] = (int128_t)one[1] * two[1];
}

void karatsuba_add_small(karatsuba_entry dst, karatsuba_entry one, karatsuba_entry_small two)
{
    dst[0] = one[0] + two[0];
    dst[1] = one[1] + two[1];
    dst[2] = one[2];
}

void karatsuba_add_result_small(karatsuba_result dst, karatsuba_result one, karatsuba_result_small two)
{
    dst[0] = one[0] + two[0];
    dst[1] = one[1] + two[1];
    dst[2] = one[2] + two[2];
    dst[3] = one[3];
    dst[4] = one[4];
}

void karatsuba_sub(karatsuba_entry dst, karatsuba_entry one, karatsuba_entry two)
{
    dst[0] = one[0] - two[0];
    dst[1] = one[1] - two[1];
    dst[2] = one[2] - two[2];
}

void karatsuba_sub_result(karatsuba_result dst, karatsuba_result one, karatsuba_result two)
{
    dst[0] = one[0] - two[0];
    dst[1] = one[1] - two[1];
    dst[2] = one[2] - two[2];
    dst[3] = one[3] - two[3];
    dst[4] = one[4] - two[4];
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_mul(field_t dst, field_t a, field_t b) {
    karatsuba_entry f0 = {a[0], a[1], a[2]};
    karatsuba_entry_small f1 = {a[3], a[4]};

    karatsuba_entry g0 = {b[0], b[1], b[2]};
    karatsuba_entry_small g1 = {b[3], b[4]};
    
    karatsuba_result_small p1;
    karatsuba_mul_small(p1, f1, g1);

    karatsuba_result p2;
    karatsuba_mul(p2, f0, g0);

    karatsuba_entry p3_left;
    karatsuba_add_small(p3_left, f0, f1);
    karatsuba_entry p3_right;
    karatsuba_add_small(p3_right, g0, g1);
    karatsuba_result p3;
    karatsuba_mul(p3, p3_left, p3_right);

    karatsuba_result sum_p1p2;
    karatsuba_add_result_small(sum_p1p2, p2, p1);
    karatsuba_result sub_p3sump1p2;
    karatsuba_sub_result(sub_p3sump1p2, p3, sum_p1p2);

    int128_t h0 = p2[0];
    int128_t h1 = p2[1];
    int128_t h2 = p2[2];
    int128_t h3 = p2[3] + sub_p3sump1p2[0];
    int128_t h4 = p2[4] + sub_p3sump1p2[1];

    int128_t h5 = sub_p3sump1p2[2];
    int128_t h6 = sub_p3sump1p2[3] + p1[0];
    int128_t h7 = sub_p3sump1p2[4] + p1[1];
    int128_t h8 = p1[2];
    
    // p1[3] and p1[4] must be 0, because they result from multiplication with at least one third limb of f1,g1 => those are 0 

    h0 += 19*h5;
    h1 += 19*h6;
    h2 += 19*h7;
    h3 += 19*h8;

    int128_t carry[5];

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    carry[1] = (h1 + ((int64_t)1 << 50)) >> 51;
    h2 += carry[1];
    h1 -= carry[1] << 51;

    carry[2] = (h2 + ((int64_t)1 << 50)) >> 51;
    h3 += carry[2];
    h2 -= carry[2] << 51;

    carry[3] = (h3 + ((int64_t)1 << 50)) >> 51;
    h4 += carry[3];
    h3 -= carry[3] << 51;

    carry[4] = (h4 + ((int64_t)1 << 50)) >> 51;
    h0 += carry[4] * 19;
    h4 -= carry[4] << 51;

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    dst[0] = (int64_t) h0;
    dst[1] = (int64_t) h1;
    dst[2] = (int64_t) h2;
    dst[3] = (int64_t) h3;
    dst[4] = (int64_t) h4;
}

// taken from djb's original implementation
void field_invert(field_t dst, field_t src) {
    field_t z2, z9, z11, z2_5_0, z2_10_0, z2_20_0, z2_50_0, z2_100_0, t0, t1;
    int i;

    field_square(z2,src);           // 2
    field_square(t1,z2);            // 4
    field_square(t0,t1);            // 8
    field_mul(z9,t0,src);           // 9
    field_mul(z11,z9,z2);           // 11
    field_square(t0,z11);           // 22
    field_mul(z2_5_0,t0,z9);        // 2^5 - 2^0 = 31

    field_square(t0,z2_5_0);        // 2^6 - 2^1
    field_square(t1,t0);            // 2^7 - 2^2
    field_square(t0,t1);            // 2^8 - 2^3
    field_square(t1,t0);            // 2^9 - 2^4
    field_square(t0,t1);            // 2^10 - 2^5
    field_mul(z2_10_0,t0,z2_5_0);   // 2^10 - 2^0

    field_square(t0,z2_10_0);       // 2^11 - 2^1
    field_square(t1,t0);            // 2^12 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^20 - 2^10
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_20_0,t1,z2_10_0);  // 2^20 - 2^0

    field_square(t0,z2_20_0);       // 2^21 - 2^1
    field_square(t1,t0);            // 2^22 - 2^2
    for (i = 2;i < 20;i += 2) {     // 2^40 - 2^20
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_20_0);       // 2^40 - 2^0

    field_square(t1,t0);            // 2^41 - 2^1
    field_square(t0,t1);            // 2^42 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^50 - 2^10
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(z2_50_0,t0,z2_10_0);  // 2^50 - 2^0

    field_square(t0,z2_50_0);       // 2^51 - 2^1
    field_square(t1,t0);            // 2^52 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^100 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_100_0,t1,z2_50_0); // 2^100 - 2^0

    field_square(t1,z2_100_0);      // 2^101 - 2^1
    field_square(t0,t1);            // 2^102 - 2^2
    for (i = 2;i < 100;i += 2) {    // 2^200 - 2^100
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(t1,t0,z2_100_0);      // 2^200 - 2^0

    field_square(t0,t1);            // 2^201 - 2^1
    field_square(t1,t0);            // 2^202 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^250 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_50_0);       // 2^250 - 2^0

    field_square(t1,t0);            // 2^251 - 2^1
    field_square(t0,t1);            // 2^252 - 2^2
    field_square(t1,t0);            // 2^253 - 2^3
    field_square(t0,t1);            // 2^254 - 2^4
    field_square(t1,t0);            // 2^255 - 2^5
    field_mul(dst,t1,z11);          // 2^255 - 21
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_mul_a24(field_t dst, field_t src) {
    int128_t h0 = (int128_t) src[0] * a24;
    int128_t h1 = (int128_t) src[1] * a24;
    int128_t h2 = (int128_t) src[2] * a24;
    int128_t h3 = (int128_t) src[3] * a24;
    int128_t h4 = (int128_t) src[4] * a24;
    int128_t carry[5];

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    carry[1] = (h1 + ((int64_t)1 << 50)) >> 51;
    h2 += carry[1];
    h1 -= carry[1] << 51;

    carry[2] = (h2 + ((int64_t)1 << 50)) >> 51;
    h3 += carry[2];
    h2 -= carry[2] << 51;

    carry[3] = (h3 + ((int64_t)1 << 50)) >> 51;
    h4 += carry[3];
    h3 -= carry[3] << 51;

    carry[4] = (h4 + ((int64_t)1 << 50)) >> 51;
    h0 += carry[4] * 19; // TODO
    h4 -= carry[4] << 51;

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    dst[0] = (int64_t) h0;
    dst[1] = (int64_t) h1;
    dst[2] = (int64_t) h2;
    dst[3] = (int64_t) h3;
    dst[4] = (int64_t) h4;
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
// see bernstein page 5, upper paragrpah for secret key definition
void decode_scalar(byte32_t dst, byte32_t src) {
    memcpy(dst, src, sizeof(byte32_t));
    dst[0] &= 248; // ensure multiple of 8 (248 = 1111 1000)
    dst[31] &= 127; // ensure biggest secret key <= 8*(2^251 - 1) = 2^254 - 1 (127 = 0111 1111)
    dst[31] |= 64; // ensure secret key offset of + 2^254 (64 = 0100 0000) 
}


// source: supercop amd64-51
void decode_point(field_t dst, byte32_t src) {
    int64_t h0;
    int64_t h1;
    int64_t h2;
    int64_t h3;
    int64_t h4;

    h0 = (int64_t) src[0];
    h0 += (int64_t) src[1] << 8;
    h0 += (int64_t) src[2] << 16;
    h0 += (int64_t) src[3] << 24;
    h0 += (int64_t) src[4] << 32;
    h0 += (int64_t) src[5] << 40;
    h0 += ((int64_t) src[6] & 7) << 48; // take the first 3 bits

    h1 = (int64_t) src[6] >> 3;         //skip the first 3 bits (take 5 bits)
    h1 += (int64_t) src[7] << 5;
    h1 += (int64_t) src[8] << 13;
    h1 += (int64_t) src[9] << 21;
    h1 += (int64_t) src[10] << 29;
    h1 += (int64_t) src[11] << 37;
    h1 += ((int64_t) src[12] & 63) << 45;

    h2 = (int64_t) src[12] >> 6;
    h2 += (int64_t) src[13] << 2;
    h2 += (int64_t) src[14] << 10;
    h2 += (int64_t) src[15] << 18;
    h2 += (int64_t) src[16] << 26;
    h2 += (int64_t) src[17] << 34;
    h2 += (int64_t) src[18] << 42;
    h2 += ((int64_t) src[19] & 1) << 50;

    h3 = (int64_t) src[19] >> 1;
    h3 += (int64_t) src[20] << 7;
    h3 += (int64_t) src[21] << 15;
    h3 += (int64_t) src[22] << 23;
    h3 += (int64_t) src[23] << 31;
    h3 += (int64_t) src[24] << 39;
    h3 += ((int64_t) src[25] & 15) << 47;

    h4 = (int64_t) src[25] >> 4;
    h4 += (int64_t) src[26] << 4;
    h4 += (int64_t) src[27] << 12;
    h4 += (int64_t) src[28] << 20;
    h4 += (int64_t) src[29] << 28;
    h4 += (int64_t) src[30] << 36;
    h4 += ((int64_t) src[31] & 127) << 44;

    int128_t carry[5];

    // this part is only needed if the input is too large
    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    carry[1] = (h1 + ((int64_t)1 << 50)) >> 51;
    h2 += carry[1];
    h1 -= carry[1] << 51;

    carry[2] = (h2 + ((int64_t)1 << 50)) >> 51;
    h3 += carry[2];
    h2 -= carry[2] << 51;

    carry[3] = (h3 + ((int64_t)1 << 50)) >> 51;
    h4 += carry[3];
    h3 -= carry[3] << 51;

    carry[4] = (h4 + ((int64_t)1 << 50)) >> 51;
    h0 += carry[4] * 19; // TODO
    h4 -= carry[4] << 51;

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    dst[0] = (int64_t) h0;
    dst[1] = (int64_t) h1;
    dst[2] = (int64_t) h2;
    dst[3] = (int64_t) h3;
    dst[4] = (int64_t) h4;
}


// source: supercop amd64-51
void encode_point(byte32_t dst, field_t src) {
    int128_t carry[5];

    int64_t q = (19*src[4] + ((int64_t)1 << 50)) >> 51;
    q = (src[0] + q) >> 51;
    q = (src[1] + q) >> 51;
    q = (src[2] + q) >> 51;
    q = (src[3] + q) >> 51;
    q = (src[4] + q) >> 51;

    // Goal: Output h-(2^255-19)q, which is between 0 and 2^255-20.
    src[0] += 19 * q;
    // Goal: Output h-2^255 q, which is between 0 and 2^255-20.

    carry[0] = src[0] >> 51;
    src[1] += carry[0];
    src[0] -= carry[0] << 51;
    carry[1] = src[1] >> 51;
    src[2] += carry[1];
    src[1] -= carry[1] << 51;
    carry[2] = src[2] >> 51;
    src[3] += carry[2];
    src[2] -= carry[2] << 51;
    carry[3] = src[3] >> 51;
    src[4] += carry[3];
    src[3] -= carry[3] << 51;
    carry[4] = src[4] >> 51;
    //src[5] += carry[4];
    src[4] -= carry[4] << 51;



    dst[0] = (uint8_t) (src[0] >> 0);
    dst[1] = (uint8_t) (src[0] >> 8);
    dst[2] = (uint8_t) (src[0] >> 16);
    dst[3] = (uint8_t) (src[0] >> 24);
    dst[4] = (uint8_t) (src[0] >> 32);
    dst[5] = (uint8_t) (src[0] >> 40);

    dst[6] = (uint8_t) (src[0] >> 48) | (src[1] << 3);

    dst[7] = (uint8_t) (src[1] >> 5);
    dst[8] = (uint8_t) (src[1] >> 13);
    dst[9] = (uint8_t) (src[1] >> 21);
    dst[10] = (uint8_t) (src[1] >> 29);
    dst[11] = (uint8_t) (src[1] >> 37);

    dst[12] = (uint8_t) (src[1] >> 45) | (src[2] << 6);

    dst[13] = (uint8_t) (src[2] >> 2);
    dst[14] = (uint8_t) (src[2] >> 10);
    dst[15] = (uint8_t) (src[2] >> 18);
    dst[16] = (uint8_t) (src[2] >> 26);
    dst[17] = (uint8_t) (src[2] >> 34);
    dst[18] = (uint8_t) (src[2] >> 42);

    dst[19] = (uint8_t) (src[2] >> 50) | (src[3] << 1);

    dst[20] = (uint8_t) (src[3] >> 7);
    dst[21] = (uint8_t) (src[3] >> 15);
    dst[22] = (uint8_t) (src[3] >> 23);
    dst[23] = (uint8_t) (src[3] >> 31);
    dst[24] = (uint8_t) (src[3] >> 39);

    dst[25] = (uint8_t) (src[3] >> 47) | (src[4] << 4);

    dst[26] = (uint8_t) (src[4] >> 4);
    dst[27] = (uint8_t) (src[4] >> 12);
    dst[28] = (uint8_t) (src[4] >> 20);
    dst[29] = (uint8_t) (src[4] >> 28);
    dst[30] = (uint8_t) (src[4] >> 36);
    dst[31] = (uint8_t) (src[4] >> 44);
}

// swap (a, b) with (b, a) iff swap == 1.
void cswap(int64_t swap, field_t a, field_t b) {
    swap = -swap;
    for (unsigned i = 0; i < 5; i++) {
        int64_t t = swap & (a[i] ^ b[i]);
        a[i] ^= t;
        b[i] ^= t;
    }
}

// As per RFC 7748, Chapter 5
void curve_scalar_mult(field_t dst, byte32_t n, field_t P) {
    field_t x_1; memcpy(x_1, P, sizeof(field_t));
    field_t x_2 = { 1 };
    field_t z_2 = { 0 };
    field_t x_3; memcpy(x_3, P, sizeof(field_t));
    field_t z_3 = { 1 };
    int64_t swap = 0;

    for (int32_t i = 254; i >= 0; i--) {
        int32_t bit = (n[i / 8] >> (i & 7)) & 1;
        swap ^= bit;
        cswap(swap, x_2, x_3);
        cswap(swap, z_2, z_3);
        swap = bit;

        field_t A, AA, B, BB, E, C, D, DA, CB;
        field_t t0;

        field_add(A, x_2, z_2);     // A = x_2 + z_2
        field_square(AA, A);        // AA = A^2
        field_sub(B, x_2, z_2);     // B = x_2 - z_2
        field_square(BB, B);        // BB = B^2
        field_sub(E, AA, BB);       // E = AA - BB
        field_add(C, x_3, z_3);     // C = x_3 + z_3
        field_sub(D, x_3, z_3);     // D = x_3 - z_3
        field_mul(DA, D, A);        // DA = D * A
        field_mul(CB, C, B);        // CB = C * B
        field_add(t0, DA, CB);      // x_3 = (DA + CB)^2
        field_square(x_3, t0);
        field_sub(t0, DA, CB);      // z_3 = x_1 * (DA - CB)^2
        field_square(t0, t0);
        field_mul(z_3, t0, x_1);
        field_mul(x_2, AA, BB);     // x_2 = AA * BB
        field_mul_a24(t0, E);       // z_2 = E * (AA + a24 * E)
        field_add(t0, AA, t0);
        field_mul(z_2, E, t0);
    }

    cswap(swap, x_2, x_3);
    cswap(swap, z_2, z_3);
    field_invert(z_2, z_2);         // z_2 = z_2 ^-1
    field_mul(dst, x_2, z_2);       // dst = x_2 * z_2
}

void curve25519(byte32_t dst, byte32_t n, byte32_t P) {
    byte32_t scalar;
    decode_scalar(scalar, n);

    field_t base, result;
    decode_point(base, P);
    curve_scalar_mult(result, scalar, base);

    encode_point(dst, result);
}

int crypto_scalarmult(unsigned char * dst,
                      const unsigned char *n,
                      const unsigned char *P) {
    curve25519((uint8_t *) dst, (uint8_t *) n, (uint8_t *) P);
    return 0;
}

