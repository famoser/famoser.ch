#include <stdio.h>
#include <string.h>

#include "curve25519_basic.h"
#include "crypto_scalarmult.h"

#define a24 121665


void field_add(field_t dst, field_t a, field_t b) {
    for (unsigned i = 0; i < 5; i++) {
        dst[i] = a[i] + b[i];
    }
}

void field_sub(field_t dst, field_t a, field_t b) {
    for (unsigned i = 0; i < 5; i++) {
        dst[i] = a[i] - b[i];
    }
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_square(field_t dst, field_t src) {
    int64_t f0 = src[0];
    int64_t f1 = src[1];
    int64_t f2 = src[2];
    int64_t f3 = src[3];
    int64_t f4 = src[4];
    

    //int128_t f1_19 = 19 * f1; // f < 2^51 & 19 < 2^6 => 19*f < 2^57
    //int128_t f2_19 = 19 * f2;
    int128_t f3_19 = 19 * f3;
    int128_t f4_19 = 19 * f4;
    
    int128_t f0f0 = (int128_t) f0 * f0;
    int128_t f0f1 =(int128_t) f0 * f1;
    int128_t f0f2 =(int128_t) f0 * f2;
    int128_t f0f3 =(int128_t) f0 * f3;
    int128_t f0f4 =(int128_t) f0 * f4;

    int128_t f1f0 = f0f1;
    int128_t f1f1 = (int128_t) f1 * f1;
    int128_t f1f2 = (int128_t) f1 * f2;
    int128_t f1f3 = (int128_t) f1 * f3;
    int128_t f1f4_19 = f1 * f4_19;

    int128_t f2f0 = f0f2;
    int128_t f2f1 = f1f2;
    int128_t f2f2 = (int128_t) f2 * f2;
    int128_t f2f3_19 = (int128_t) f2 * f3_19;
    int128_t f2f4_19 = (int128_t) f2 * f4_19;
    
    int128_t f3f0 = f0f3;
    int128_t f3f1 = f1f3;
    int128_t f3f2_19 = f2f3_19;
    int128_t f3f3_19 = (int128_t) f3 * f3_19;
    int128_t f3f4_19 = (int128_t) f3 * f4_19;

    int128_t f4f0 = f0f4;
    int128_t f4f1_19 = f1f4_19;
    int128_t f4f2_19 = f2f4_19;
    int128_t f4f3_19 = f3f4_19;
    int128_t f4f4_19 = (int128_t) f4 * f4_19;
    

    int128_t h0 = f0f0 + f1f4_19 + f2f3_19 + f3f2_19 + f4f1_19;
    int128_t h1 = f0f1 + f1f0    + f2f4_19 + f3f3_19 + f4f2_19;
    int128_t h2 = f0f2 + f1f1    + f2f0    + f3f4_19 + f4f3_19;
    int128_t h3 = f0f3 + f1f2    + f2f1    + f3f0    + f4f4_19;
    int128_t h4 = f0f4 + f1f3    + f2f2    + f3f1    + f4f0;

    int128_t carry[5];

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    carry[1] = (h1 + ((int64_t)1 << 50)) >> 51;
    h2 += carry[1];
    h1 -= carry[1] << 51;

    carry[2] = (h2 + ((int64_t)1 << 50)) >> 51;
    h3 += carry[2];
    h2 -= carry[2] << 51;

    carry[3] = (h3 + ((int64_t)1 << 50)) >> 51;
    h4 += carry[3];
    h3 -= carry[3] << 51;

    carry[4] = (h4 + ((int64_t)1 << 50)) >> 51;
    h0 += carry[4] * 19; // TODO
    h4 -= carry[4] << 51;

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    dst[0] = (int64_t) h0;
    dst[1] = (int64_t) h1;
    dst[2] = (int64_t) h2;
    dst[3] = (int64_t) h3;
    dst[4] = (int64_t) h4;
}

typedef int64_t toom_cook_entry[2];
typedef int128_t toom_cook_result[3];

void toom_cook_mul(toom_cook_result dst, toom_cook_entry one, toom_cook_entry two)
{
    dst[0] = (int128_t)one[0] * two[0];
    dst[1] = (int128_t)one[0] * two[1] + (int128_t)two[0] * one[1];
    dst[2] = (int128_t)two[1] * one[1];
}

void toom_cook_add(toom_cook_entry dst, toom_cook_entry one, toom_cook_entry two)
{
    dst[0] = one[0] + two[0];
    dst[1] = one[1] + two[1];
}

void toom_cook_shift(toom_cook_entry dst, toom_cook_entry one, int amount)
{
    dst[0] = one[0] << amount;
    dst[1] = one[1] << amount;
}

void toom_cook_sub(toom_cook_entry dst, toom_cook_entry one, toom_cook_entry two)
{
    dst[0] = one[0] - two[0];
    dst[1] = one[1] - two[1];
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_mul(field_t dst, field_t a, field_t b) {
    toom_cook_entry f0 = {a[0], a[1]};
    toom_cook_entry f1 = {a[2], a[3]};
    toom_cook_entry f2 = {a[4], 0};

    toom_cook_entry g0 = {b[0], b[1]};
    toom_cook_entry g1 = {b[2], b[3]};
    toom_cook_entry g2 = {b[4], 0};
    
    /**
     * x = 0
     * e0 = f0 * g0
     */
    toom_cook_result e0;
    toom_cook_mul(e0, f0, g0);

    /**
     * x = 1
     * e1 = (f0 + f1 + f2) * (g0 + g1 + g2)
     */
    toom_cook_entry f_sum02;
    toom_cook_add(f_sum02, f0, f2);
    
    toom_cook_entry f_sum012;
    toom_cook_add(f_sum012, f_sum02, f1);
    
    toom_cook_entry g_sum02;
    toom_cook_add(g_sum02, g0, g2);
    
    toom_cook_entry g_sum012;
    toom_cook_add(g_sum012, g_sum02, g1);
    
    toom_cook_result e1;
    toom_cook_mul(e1, f_sum012, g_sum012);


    /**
     * x = -1
     * e2 = (f0 - f1 + f2) * (g0 - g1 + g2)
     */
    toom_cook_entry f_sum02_sub_g1;
    toom_cook_add(f_sum02_sub_g1, f_sum02, f1);
    
    toom_cook_entry g_sum02_sub_g1;
    toom_cook_add(g_sum02_sub_g1, g_sum02, g1);

    toom_cook_result e2;
    toom_cook_mul(e2, f_sum02_sub_g1, g_sum02_sub_g1);



    /**
     * x = 2
     * e3 = (f0 + f1*2 + f2*4) * (g0 + g1*2 + g2*4)
     */
    toom_cook_entry f_double1;
    toom_cook_shift(f_double1, f1, 1);

    toom_cook_entry f_quadruple2;
    toom_cook_shift(f_quadruple2, f2, 2);

    toom_cook_entry g_double1;
    toom_cook_shift(g_double1, g1, 1);

    toom_cook_entry g_quadruple2;
    toom_cook_shift(g_quadruple2, g2, 2);


    toom_cook_entry f_sum0quadruple2;
    toom_cook_add(f_sum0quadruple2, f0, f_quadruple2);
    
    toom_cook_entry f_sum0double1quadruple2;
    toom_cook_add(f_sum0double1quadruple2, f_sum0quadruple2, f_double1);
    
    toom_cook_entry g_sum0quadruple2;
    toom_cook_add(g_sum0quadruple2, g0, g_quadruple2);
    
    toom_cook_entry g_sum0double1quadruple2;
    toom_cook_add(g_sum0double1quadruple2, g_sum0quadruple2, g_double1);
    
    toom_cook_result e3;
    toom_cook_mul(e3, f_sum0double1quadruple2, g_sum0double1quadruple2);


    /**
     * x = -2
     * e4 = (f0 - f1*2 + f2*4) * (g0 - g1*2 + g2*4)
     */
    
    toom_cook_entry f_sum0quadruple2_subdouble1;
    toom_cook_sub(f_sum0quadruple2_subdouble1, f_sum0quadruple2, f_double1);
    
    toom_cook_entry g_sum0quadruple2_subdouble1;
    toom_cook_sub(g_sum0quadruple2_subdouble1, g_sum0quadruple2, g_double1);
    
    toom_cook_result e4;
    toom_cook_mul(e4, f_sum0quadruple2_subdouble1, g_sum0quadruple2_subdouble1);

    
    /**
     * e0 = a
     * e1 = a + b + c + d + e
     * e2 = a - b + c - d + e
     * e3 = a + 2b + 4c + 8d + 16e
     * e4 = a - 2b + 4c - 8d + 16e
     * 
     * h0 = e0
     * 
     * e12_with_a = e1 + e2 = 2a + 2c + 2e
     * e34_with_a = e3 + e4 = 2a + 8c + 32e
     * 
     * a_double = a+a
     * e12 = e12_with_a - a_double = 2c + 2e
     * e34 = e34_with_a - a_double = 8c + 32e
     * 
     * wolfram alpha input: a = 2c + 2e, b = 8c + 32e, solve c
     * h2 = e21/8 - 4*e34
     * h4 = e21/4 - 6*e34
     * 
     * e21 = e1 - e2 = 2b + 2d
     * e43 = e3 - e4 = 4b + 16d
     * 
     * wolfram alpha input: e = 2b + 2d, f = 4b + 16d, solve b
     * h1 = 2*e21/3 - e43/12
     * h3 = e43/12 - e21/6
     */ 




    /**
    we could use the points proposed by Gnu precision library 
    t=0 => x0*y0, which gives w0 immediately
    t=2	=> (4*x2+2*x1+x0)*(4*y2+2*y1+y0)
    t=1	=> (x2+x1+x0)*(y2+y1+y0)
    t=1/2 => (x2+2*x1+4*x0)*(y2+2*y1+4*y0)
    t=inf => x2*y2, which gives w4 immediately

    giving us the euqation system
    W(0)  =                                 w0
    16*W(1/2) =    w4 + 2*w3 + 4*w2 + 8*w1 + 16*w0
    W(1)   =    w4 +   w3 +   w2 +   w1 +    w0
    W(2)   = 16*w4 + 8*w3 + 4*w2 + 2*w1 +    w0
    W(inf) =    w4
   */

    int128_t h0 = e0[0];
    int128_t h1 = e1[0];
    int128_t h2 = e2[0];
    int128_t h3 = e3[0];
    int128_t h4 = e4[0];

    int128_t carry[5];

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    carry[1] = (h1 + ((int64_t)1 << 50)) >> 51;
    h2 += carry[1];
    h1 -= carry[1] << 51;

    carry[2] = (h2 + ((int64_t)1 << 50)) >> 51;
    h3 += carry[2];
    h2 -= carry[2] << 51;

    carry[3] = (h3 + ((int64_t)1 << 50)) >> 51;
    h4 += carry[3];
    h3 -= carry[3] << 51;

    carry[4] = (h4 + ((int64_t)1 << 50)) >> 51;
    h0 += carry[4] * 19; // TODO
    h4 -= carry[4] << 51;

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    dst[0] = (int64_t) h0;
    dst[1] = (int64_t) h1;
    dst[2] = (int64_t) h2;
    dst[3] = (int64_t) h3;
    dst[4] = (int64_t) h4;
}

// taken from djb's original implementation
void field_invert(field_t dst, field_t src) {
    field_t z2, z9, z11, z2_5_0, z2_10_0, z2_20_0, z2_50_0, z2_100_0, t0, t1;
    int i;

    field_square(z2,src);           // 2
    field_square(t1,z2);            // 4
    field_square(t0,t1);            // 8
    field_mul(z9,t0,src);           // 9
    field_mul(z11,z9,z2);           // 11
    field_square(t0,z11);           // 22
    field_mul(z2_5_0,t0,z9);        // 2^5 - 2^0 = 31

    field_square(t0,z2_5_0);        // 2^6 - 2^1
    field_square(t1,t0);            // 2^7 - 2^2
    field_square(t0,t1);            // 2^8 - 2^3
    field_square(t1,t0);            // 2^9 - 2^4
    field_square(t0,t1);            // 2^10 - 2^5
    field_mul(z2_10_0,t0,z2_5_0);   // 2^10 - 2^0

    field_square(t0,z2_10_0);       // 2^11 - 2^1
    field_square(t1,t0);            // 2^12 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^20 - 2^10
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_20_0,t1,z2_10_0);  // 2^20 - 2^0

    field_square(t0,z2_20_0);       // 2^21 - 2^1
    field_square(t1,t0);            // 2^22 - 2^2
    for (i = 2;i < 20;i += 2) {     // 2^40 - 2^20
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_20_0);       // 2^40 - 2^0

    field_square(t1,t0);            // 2^41 - 2^1
    field_square(t0,t1);            // 2^42 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^50 - 2^10
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(z2_50_0,t0,z2_10_0);  // 2^50 - 2^0

    field_square(t0,z2_50_0);       // 2^51 - 2^1
    field_square(t1,t0);            // 2^52 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^100 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_100_0,t1,z2_50_0); // 2^100 - 2^0

    field_square(t1,z2_100_0);      // 2^101 - 2^1
    field_square(t0,t1);            // 2^102 - 2^2
    for (i = 2;i < 100;i += 2) {    // 2^200 - 2^100
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(t1,t0,z2_100_0);      // 2^200 - 2^0

    field_square(t0,t1);            // 2^201 - 2^1
    field_square(t1,t0);            // 2^202 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^250 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_50_0);       // 2^250 - 2^0

    field_square(t1,t0);            // 2^251 - 2^1
    field_square(t0,t1);            // 2^252 - 2^2
    field_square(t1,t0);            // 2^253 - 2^3
    field_square(t0,t1);            // 2^254 - 2^4
    field_square(t1,t0);            // 2^255 - 2^5
    field_mul(dst,t1,z11);          // 2^255 - 21
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_mul_a24(field_t dst, field_t src) {
    int128_t h0 = (int128_t) src[0] * a24;
    int128_t h1 = (int128_t) src[1] * a24;
    int128_t h2 = (int128_t) src[2] * a24;
    int128_t h3 = (int128_t) src[3] * a24;
    int128_t h4 = (int128_t) src[4] * a24;
    int128_t carry[5];

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    carry[1] = (h1 + ((int64_t)1 << 50)) >> 51;
    h2 += carry[1];
    h1 -= carry[1] << 51;

    carry[2] = (h2 + ((int64_t)1 << 50)) >> 51;
    h3 += carry[2];
    h2 -= carry[2] << 51;

    carry[3] = (h3 + ((int64_t)1 << 50)) >> 51;
    h4 += carry[3];
    h3 -= carry[3] << 51;

    carry[4] = (h4 + ((int64_t)1 << 50)) >> 51;
    h0 += carry[4] * 19; // TODO
    h4 -= carry[4] << 51;

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    dst[0] = (int64_t) h0;
    dst[1] = (int64_t) h1;
    dst[2] = (int64_t) h2;
    dst[3] = (int64_t) h3;
    dst[4] = (int64_t) h4;
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
// see bernstein page 5, upper paragrpah for secret key definition
void decode_scalar(byte32_t dst, byte32_t src) {
    memcpy(dst, src, sizeof(byte32_t));
    dst[0] &= 248; // ensure multiple of 8 (248 = 1111 1000)
    dst[31] &= 127; // ensure biggest secret key <= 8*(2^251 - 1) = 2^254 - 1 (127 = 0111 1111)
    dst[31] |= 64; // ensure secret key offset of + 2^254 (64 = 0100 0000) 
}


// source: supercop amd64-51
void decode_point(field_t dst, byte32_t src) {
    int64_t h0;
    int64_t h1;
    int64_t h2;
    int64_t h3;
    int64_t h4;

    h0 = (int64_t) src[0];
    h0 += (int64_t) src[1] << 8;
    h0 += (int64_t) src[2] << 16;
    h0 += (int64_t) src[3] << 24;
    h0 += (int64_t) src[4] << 32;
    h0 += (int64_t) src[5] << 40;
    h0 += ((int64_t) src[6] & 7) << 48; // take the first 3 bits

    h1 = (int64_t) src[6] >> 3;         //skip the first 3 bits (take 5 bits)
    h1 += (int64_t) src[7] << 5;
    h1 += (int64_t) src[8] << 13;
    h1 += (int64_t) src[9] << 21;
    h1 += (int64_t) src[10] << 29;
    h1 += (int64_t) src[11] << 37;
    h1 += ((int64_t) src[12] & 63) << 45;

    h2 = (int64_t) src[12] >> 6;
    h2 += (int64_t) src[13] << 2;
    h2 += (int64_t) src[14] << 10;
    h2 += (int64_t) src[15] << 18;
    h2 += (int64_t) src[16] << 26;
    h2 += (int64_t) src[17] << 34;
    h2 += (int64_t) src[18] << 42;
    h2 += ((int64_t) src[19] & 1) << 50;

    h3 = (int64_t) src[19] >> 1;
    h3 += (int64_t) src[20] << 7;
    h3 += (int64_t) src[21] << 15;
    h3 += (int64_t) src[22] << 23;
    h3 += (int64_t) src[23] << 31;
    h3 += (int64_t) src[24] << 39;
    h3 += ((int64_t) src[25] & 15) << 47;

    h4 = (int64_t) src[25] >> 4;
    h4 += (int64_t) src[26] << 4;
    h4 += (int64_t) src[27] << 12;
    h4 += (int64_t) src[28] << 20;
    h4 += (int64_t) src[29] << 28;
    h4 += (int64_t) src[30] << 36;
    h4 += ((int64_t) src[31] & 127) << 44;

    int128_t carry[5];

    // this part is only needed if the input is too large
    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    carry[1] = (h1 + ((int64_t)1 << 50)) >> 51;
    h2 += carry[1];
    h1 -= carry[1] << 51;

    carry[2] = (h2 + ((int64_t)1 << 50)) >> 51;
    h3 += carry[2];
    h2 -= carry[2] << 51;

    carry[3] = (h3 + ((int64_t)1 << 50)) >> 51;
    h4 += carry[3];
    h3 -= carry[3] << 51;

    carry[4] = (h4 + ((int64_t)1 << 50)) >> 51;
    h0 += carry[4] * 19; // TODO
    h4 -= carry[4] << 51;

    carry[0] = (h0 + ((int64_t)1 << 50)) >> 51;
    h1 += carry[0];
    h0 -= carry[0] << 51;

    dst[0] = (int64_t) h0;
    dst[1] = (int64_t) h1;
    dst[2] = (int64_t) h2;
    dst[3] = (int64_t) h3;
    dst[4] = (int64_t) h4;
}


// source: supercop amd64-51
void encode_point(byte32_t dst, field_t src) {
    int128_t carry[5];

    int64_t q = (19*src[4] + ((int64_t)1 << 50)) >> 51;
    q = (src[0] + q) >> 51;
    q = (src[1] + q) >> 51;
    q = (src[2] + q) >> 51;
    q = (src[3] + q) >> 51;
    q = (src[4] + q) >> 51;

    // Goal: Output h-(2^255-19)q, which is between 0 and 2^255-20.
    src[0] += 19 * q;
    // Goal: Output h-2^255 q, which is between 0 and 2^255-20.

    carry[0] = src[0] >> 51;
    src[1] += carry[0];
    src[0] -= carry[0] << 51;
    carry[1] = src[1] >> 51;
    src[2] += carry[1];
    src[1] -= carry[1] << 51;
    carry[2] = src[2] >> 51;
    src[3] += carry[2];
    src[2] -= carry[2] << 51;
    carry[3] = src[3] >> 51;
    src[4] += carry[3];
    src[3] -= carry[3] << 51;
    carry[4] = src[4] >> 51;
    //src[5] += carry[4];
    src[4] -= carry[4] << 51;



    dst[0] = (uint8_t) (src[0] >> 0);
    dst[1] = (uint8_t) (src[0] >> 8);
    dst[2] = (uint8_t) (src[0] >> 16);
    dst[3] = (uint8_t) (src[0] >> 24);
    dst[4] = (uint8_t) (src[0] >> 32);
    dst[5] = (uint8_t) (src[0] >> 40);

    dst[6] = (uint8_t) (src[0] >> 48) | (src[1] << 3);

    dst[7] = (uint8_t) (src[1] >> 5);
    dst[8] = (uint8_t) (src[1] >> 13);
    dst[9] = (uint8_t) (src[1] >> 21);
    dst[10] = (uint8_t) (src[1] >> 29);
    dst[11] = (uint8_t) (src[1] >> 37);

    dst[12] = (uint8_t) (src[1] >> 45) | (src[2] << 6);

    dst[13] = (uint8_t) (src[2] >> 2);
    dst[14] = (uint8_t) (src[2] >> 10);
    dst[15] = (uint8_t) (src[2] >> 18);
    dst[16] = (uint8_t) (src[2] >> 26);
    dst[17] = (uint8_t) (src[2] >> 34);
    dst[18] = (uint8_t) (src[2] >> 42);

    dst[19] = (uint8_t) (src[2] >> 50) | (src[3] << 1);

    dst[20] = (uint8_t) (src[3] >> 7);
    dst[21] = (uint8_t) (src[3] >> 15);
    dst[22] = (uint8_t) (src[3] >> 23);
    dst[23] = (uint8_t) (src[3] >> 31);
    dst[24] = (uint8_t) (src[3] >> 39);

    dst[25] = (uint8_t) (src[3] >> 47) | (src[4] << 4);

    dst[26] = (uint8_t) (src[4] >> 4);
    dst[27] = (uint8_t) (src[4] >> 12);
    dst[28] = (uint8_t) (src[4] >> 20);
    dst[29] = (uint8_t) (src[4] >> 28);
    dst[30] = (uint8_t) (src[4] >> 36);
    dst[31] = (uint8_t) (src[4] >> 44);
}

// swap (a, b) with (b, a) iff swap == 1.
void cswap(int64_t swap, field_t a, field_t b) {
    swap = -swap;
    for (unsigned i = 0; i < 5; i++) {
        int64_t t = swap & (a[i] ^ b[i]);
        a[i] ^= t;
        b[i] ^= t;
    }
}

// As per RFC 7748, Chapter 5
void curve_scalar_mult(field_t dst, byte32_t n, field_t P) {
    field_t x_1; memcpy(x_1, P, sizeof(field_t));
    field_t x_2 = { 1 };
    field_t z_2 = { 0 };
    field_t x_3; memcpy(x_3, P, sizeof(field_t));
    field_t z_3 = { 1 };
    int64_t swap = 0;

    for (int32_t i = 254; i >= 0; i--) {
        int32_t bit = (n[i / 8] >> (i & 7)) & 1;
        swap ^= bit;
        cswap(swap, x_2, x_3);
        cswap(swap, z_2, z_3);
        swap = bit;

        field_t A, AA, B, BB, E, C, D, DA, CB;
        field_t t0;

        field_add(A, x_2, z_2);     // A = x_2 + z_2
        field_square(AA, A);        // AA = A^2
        field_sub(B, x_2, z_2);     // B = x_2 - z_2
        field_square(BB, B);        // BB = B^2
        field_sub(E, AA, BB);       // E = AA - BB
        field_add(C, x_3, z_3);     // C = x_3 + z_3
        field_sub(D, x_3, z_3);     // D = x_3 - z_3
        field_mul(DA, D, A);        // DA = D * A
        field_mul(CB, C, B);        // CB = C * B
        field_add(t0, DA, CB);      // x_3 = (DA + CB)^2
        field_square(x_3, t0);
        field_sub(t0, DA, CB);      // z_3 = x_1 * (DA - CB)^2
        field_square(t0, t0);
        field_mul(z_3, t0, x_1);
        field_mul(x_2, AA, BB);     // x_2 = AA * BB
        field_mul_a24(t0, E);       // z_2 = E * (AA + a24 * E)
        field_add(t0, AA, t0);
        field_mul(z_2, E, t0);
    }

    cswap(swap, x_2, x_3);
    cswap(swap, z_2, z_3);
    field_invert(z_2, z_2);         // z_2 = z_2 ^-1
    field_mul(dst, x_2, z_2);       // dst = x_2 * z_2
}

void curve25519(byte32_t dst, byte32_t n, byte32_t P) {
    byte32_t scalar;
    decode_scalar(scalar, n);

    field_t base, result;
    decode_point(base, P);
    curve_scalar_mult(result, scalar, base);

    encode_point(dst, result);
}

int crypto_scalarmult(unsigned char * dst,
                      const unsigned char *n,
                      const unsigned char *P) {
    curve25519((uint8_t *) dst, (uint8_t *) n, (uint8_t *) P);
    return 0;
}

