# Toom Cook

method for multiplication; generalization of karatsuba

## for 10 libs

interpret the limbs as polynomials like for f(x) = f0 + f1x¹ + f2x² + ... and g(x) = g0 + g1x¹ + g2x² + ...
multiply these polynomials to get h(x) = f(x) * g(x) = h0 + h1x¹ + h2x² + ...

h(x) has 19 unknowns h0, h1, ....
hence evaluate h(x) at 19 points to get 19 equations which allow to find out these unknowns.
need to choose 19 points; choose 0, -1, 1, ..., 10

each of these 19 evaluations need up to:
- (1) 19 multiplications of the point (x, x², x³, ...)
- (2) 9 mults + 10 adds to evaluaute f(x); same for g(x)
- (3) 1 mults to do g(x) * f(x) 
- (4) gauss eleminiation on the resulting system of equations:
    - (18 + 17 + 16 + ...) rows which need to be cleaned up with another  
    - (19 + 18 + 17 + ...) elements on rows which need to be multiplied & subtracted from another 

## bring down operation count

there are some simplifications to bring down the operation count:
- (a) use 0 as a point x; saves (1), (2)
- (b) use the same x positive and negative:
    (1) needs only to be calculated once for both points resulting in y, y'
    (4) is simplified by evaluating z = y - y' and z' = y + y'. both z and z' now have many zero terms
- (c) reduce the number of limbs; saves at all parts of the algorithm

to fulfil (c), we need to restructure the algorithm to use the biggest possible limb size. 

out bottleneck for the size is the p(x) * g(x) multiplication. it must not exceed __int128_t; hence p(x) and g(x) must fit into 64 bits.

## for 5 limbs

we have 2^255 bits to store. lower than 4 limbs would simply not fit into 64 bits (because 64*3 < 255). 

exactly 4 limbs would not work yet. at one time in p(x) we need to multiply a limb by x³. because we need to choose 6 points, the lowest highest x we can choose is 3, resulting in a multiplication by 27.
5 limbs would however already work. in p(x) we now need to multiply a limb by x⁴, the lowest highest x we can choose is still 3, resulting in a multiplication by 81 (bit lenght = 7). Each limb 51 bits long, hence it fits.

## three-way toom cook

... seems to be the sweet spot, also used by GNU precision library

## ten-way toom cook

when choosing too high limb size, toom cook gets ridiculously large.

```
    int32_t f0 = a[0];
    int32_t f1 = a[1];
    int64_t f2 = a[2];
    int64_t f3 = a[3];
    int64_t f4 = a[4];
    int64_t f5 = a[5];
    int64_t f6 = a[6];
    int64_t f7 = a[7];
    int64_t f8 = a[8];
    int64_t f9 = a[9];
    int32_t g0 = b[0];
    int32_t g1 = b[1];
    int64_t g2 = b[2];
    int64_t g3 = b[3];
    int64_t g4 = b[4];
    int64_t g5 = b[5];
    int64_t g6 = b[6];
    int64_t g7 = b[7];
    int64_t g8 = b[8];
    int64_t g9 = b[9];
   /*

    pick 10 points on the polynomials, then solve the equations for h1, h2, ...

    we pick the points 0,1,-1,2,-2,3,-3,4,-4,5 with intermediate results e0, e1, ...
    */

    // x = 0; e0 = h0
    int64_t e0 = f0 * g0;

    __int128_t sum_f02468 = f0 + f2 + f4 + f6 + f8;
    __int128_t sum_f13579 = f1 + f3 + f5 + f7 + f9;
    __int128_t sum_g02468 = g0 + g2 + g4 + g6 + g8;
    __int128_t sum_g13579 = g1 + g3 + g5 + g7 + g9;
    
    // x = 1; e1 = h0 + h1 + h2 + ...
    __int128_t e1 = (sum_f02468 + sum_f13579) * (sum_g02468 + sum_g13579);
    // x = -1; e2 = h0 - h1 + h2 - ...
    __int128_t e2 = (sum_f02468 - sum_f13579) * (sum_g02468 - sum_g13579);



    __int128_t pow2_f02468 = f0 + 4*f2 + 16*f4 + 64*f6 + 256*f8;
    __int128_t pow2_f13579 = 2*f1 + 8*f3 + 32*f5 + 128*f7 + 512*f9;
    __int128_t pow2_g02468 = g0 + 4*g2 + 16*g4 + 64*g6 + 256*g8;
    __int128_t pow2_g13579 = 2*g1 + 8*g3 + 32*g5 + 128*g7 + 512*g9;

    // x = 2; e3 = h0 + 2h1 + 4h2 + ...
    __int128_t e3 = (pow2_f02468 + pow2_f13579) * (pow2_g02468 + pow2_g13579);
    // x = -2; e4 = h0 - 2h1 + 4h2 - ...
    __int128_t e4 = (pow2_f02468 - pow2_f13579) * (pow2_g02468 - pow2_g13579);



    __int128_t pow3_f02468 = f0 + 9*f2 + 81*f4 + 729*f6 + 6561*f8;
    __int128_t pow3_f13579 = 3*f1 + 27*f3 + 234*f5 + 2187*f7 + 19638*f9;
    __int128_t pow3_g02468 = g0 + 9*g2 + 81*g4 + 729*g6 + 6561*g8;
    __int128_t pow3_g13579 = 3*g1 + 27*g3 + 234*g5 + 2187*g7 + 19638*g9;

    // x = 3; e5 = h0 + 3h1 + 9h2 + ...
    __int128_t e5 = (pow3_f02468 + pow3_f13579) * (pow3_g02468 + pow3_g13579);
    // x = -3; e6 = h0 - 3h1 + 9h2 - ...
    __int128_t e6 = (pow3_f02468 - pow3_f13579) * (pow3_g02468 - pow3_g13579);



    __int128_t pow4_f02468 = f0 + 16*f2 + 256*f4 + 4096*f6 + 65536*f8;
    __int128_t pow4_f13579 = 4*f1 + 64*f3 + 1024*f5 + 16384*f7 + 262144*f9;
    __int128_t pow4_g02468 = g0 + 16*g2 + 256*g4 + 4096*g6 + 65536*g8;
    __int128_t pow4_g13579 = 4*g1 + 64*g3 + 1024*g5 + 16384*g7 + 262144*g9;

    // x = 4; e7 = h0 + 4h1 + 16h2 + ...
    __int128_t e7 = (pow4_f02468 + pow4_f13579) * (pow4_g02468 + pow4_g13579);
    // x = -4 e8 = h0 - 4h1 + 16h2 - ...
    __int128_t e8 = (pow4_f02468 - pow4_f13579) * (pow4_g02468 - pow4_g13579);



    __int128_t pow5_f02468 = f0 + 25*f2 + 625*f4 + 15625*f6 + 390625*f8;
    __int128_t pow5_f13579 = 5*f1 + 125*f3 + 3125*f5 + 78125*f7 + 1953125*f9;
    __int128_t pow5_g02468 = g0 + 25*g2 + 625*g4 + 15625*g6 + 390625*g8;
    __int128_t pow5_g13579 = 5*g1 + 125*g3 + 3125*g5 + 78125*g7 + 1953125*g9;

    // x = 5; e9 = h0 + 5h1 + 25h2 + ...
    __int128_t e9 = (pow5_f02468 + pow5_f13579) * (pow5_g02468 + pow5_g13579);

    // h0 = e0
    __int128_t h0 = e0;

    __int128_t h0_2 = 2*h0;

    __int128_t e12 = (e1 + e2 - h0_2) / 2; // h2 + h4 + h6 + h8
    __int128_t e34 = (e3 + e4 - h0_2) / 2; // 4h2 + 16h4 + 64h6 + 256h8
    __int128_t e56 = (e5 + e6 - h0_2) / 2; // 9h2 + 81h4 + 729h6 + 6561h8
    __int128_t e78 = (e7 + e8 - h0_2) / 2; // 16h2 + 256h4 + 4096h6 + 65536h8

    // wolframalpha: a + b + c + d = e, 4a + 16b + 64c + 256d = f, 9a + 81b + 729c + 6561d = g, 16a + 256b + 4096c + 65536d = h, solve a
    __int128_t h2 = 8*e12/5 - e34/5 + 8*e56/315 - e78/520;
    __int128_t h4 = (-1952*e12 + 576*e34 - 96*e56 + 7*e78) / 2880;
    __int128_t h6 = (116*e12 - 52*e34 + 12*e56 - e78)/1440;
    __int128_t h8 = (-56*e12 + 28*e34 - 8*e56 + e78)/20160;

    __int128_t e21 = e1 - e2; // 2h1 + 2h3 + 2h5 + 2h7 + 2h9
    __int128_t e43 = e3 - e4; // 4h1 + 16h3 + 64h5 + 256h7 + 1024h9
    __int128_t e65 = e5 - e6; // 6h1 + 54h3 + 468h5 + 1458h7 + 39276h9
    __int128_t e87 = e7 - e8; // 8h1 + 128h3 + 2048h5 + 32768h7 + 524288h9
    __int128_t e9p = e9 - (h0 + 25*h2 + 625*h4 + 15625*h6 + 390625*h8); // 5h1 + 125h3 + 3125h5 + 78125h7 + 1953125h9

    // wolframalpha: 2a + 2b + 2c + 2d + 2e = f, 4a + 16b + 64c + 256d + 1024e = g, 6a + 54b + 468c + 1458d + 39276e = j, 8a + 128b + 2048c + 32768d + 524288e = k, 5a + 125b + 3125c + 78125d + 1953125e = l, solve f
    __int128_t h1 = e21 + e43 + e65 + e87 + e9p;
```