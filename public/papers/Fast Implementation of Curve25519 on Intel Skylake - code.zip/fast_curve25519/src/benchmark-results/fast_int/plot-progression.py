#!/usr/bin/env python3

import csv
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import numpy as np
import math

csv_file = './benchmark-progression-i7-7500U.csv'
ops = 539754
inversion_offset = 0

font = {
        'family':       'sans-serif',
        'sans-serif':   'Helvetica',
        'weight':       'normal',
        'size':         14
        }
matplotlib.rc('font', **font)

label_map = {
        'fast_int_Stages_basic_unsigned_inv64': 'Scalar',
        'fast_int_Stages_avx2_all':  'Stage 1',
        }


def get_data_from_csv(fname):
    cycles = []
    impls = []
    with open(fname) as csvf:
        csv_reader = csv.reader(csvf, delimiter=',', quotechar='|')
        for row in csv_reader:
            i = str(row[0])
            c = int(row[2])
            cycles.append(c)
            impls.append(i)
    return (impls, cycles)


impls, flops = get_data_from_csv(csv_file)
impls = list(map(lambda x: label_map[x], impls))
flops = list(map(lambda x: ops / (x - inversion_offset), flops))

fig, ax = plt.subplots()
x = np.arange(len(impls))

ax.yaxis.set_label_coords(+0.1, 1.005)
ax.set_ylabel('iops/cycle', rotation=0,)
# ax.set_yscale('log', basey=2)
# ax.set_ylim(0, 17)
ax.yaxis.set_major_formatter(FuncFormatter(lambda x, pos: f'{x}'))

ax.set_xticks(x)
# ax.set_xticklabels(impls, fontsize=12, rotation=45)
ax.set_xticklabels(impls, fontsize=14, rotation=0)

ax.axhline(y=12.0, xmin=0, xmax=len(impls), linewidth=2.5, color='tab:red')
ax.text((len(impls) - 1) / 2,
        11.5,
        'peak integer performance (64 bit)\n[12 iops/cycle]',
        horizontalalignment='center',
        verticalalignment='top',
        fontsize=14,
        color='tab:red')
ax.bar(impls, flops, width=0.75, color='steelblue')

# value at top of bar
for i, v in enumerate(flops):
    ax.text(i,
            v + 0.3,
            f'{v:.3}',
            horizontalalignment='center',
            color='midnightblue',
            fontweight='bold',
            fontsize=14)

fig.autofmt_xdate()
fig.savefig("benchmark-progression-integer-i7-7500U.pdf", bbox_inches='tight')
