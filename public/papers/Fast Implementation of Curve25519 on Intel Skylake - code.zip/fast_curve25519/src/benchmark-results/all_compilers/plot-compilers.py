#!/usr/bin/env python3

import csv
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import numpy as np

cpus = [
        # 'i7-8665U',
        'i7-7500U',
        'i7-4770K'
        ]

files = [
        './benchmark-icc.csv',
        './benchmark-gcc.csv',
        './benchmark-clang.csv',
        ]

# XXX: make sure the benchmark results are exactly in this order!
labels = [ 'fast-double', 'fast-int', 'sandy2x', 'amd64-51', ]

font = {
        'family' : 'sans-serif',
        'sans-serif': 'Helvetica',
        'weight' : 'normal',
        'size' : 14
        }
matplotlib.rc('font', **font)

def get_data_from_csv(fname):
    bench = []
    with open(fname) as csvf:
        csv_reader = csv.reader(csvf, delimiter=',', quotechar='|')
        for row in csv_reader:
            impl = str(row[0])
            cycles = int(row[2])
            bench.append(cycles)
    return bench

def find_ylimits(data):
    min_ = float("inf")
    max_ = float("-inf")
    for x in data:
        for y in x:
            min_ = min(y, min_)
            max_ = max(y, max_)
    return min_ - 25000, max_ + 10000

def plot_compiler_bench(cpu):
    data = []
    for fname in files:
        b = get_data_from_csv(f"{cpu}/{fname}")
        data.append(b)

    fig, ax = plt.subplots()
    x = np.arange(len(labels))
    ax.bar(x - 0.25, data[0], width=0.23, color='steelblue', label='icc')
    ax.bar(x + 0.00, data[1], width=0.23, color='darkorange', label='gcc')
    ax.bar(x + 0.25, data[2], width=0.23, color='green', label='clang')

    # ymin, ymax = find_ylimits(data)
    # ax.set_ylim(ymin, ymax)
    ax.set_ylim(110000, 175000)

    ax.yaxis.set_label_coords(+0.16, 1.005)
    ax.set_ylabel('cycles', rotation=0,)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=14)
    ax.ticklabel_format(axis='y', style='sci', scilimits=(0,0), useMathText=True)
    ax.legend(loc="upper left")

    # fig.tight_layout()
    # plt.show()
    fig.savefig(f"benchmark-compilers-{cpu}.pdf", bbox_inches='tight')

for cpu in cpus:
    plot_compiler_bench(cpu)
