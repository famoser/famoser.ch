#!/usr/bin/env python3

import csv
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import numpy as np
from pathlib import Path

cflag = "generic_any_radix_codegeneration_cflags_0"
current_dir = str(Path(__file__).resolve().parent)
file = "./benchmark-generic.csv"

radixes = []
cycleCounts = []
instructionCounts = []

addsubCounts = []
mulCounts = []
logicalCounts = []
with open(file) as csvf:
    csv_reader = csv.reader(csvf, delimiter=',')
    for row in csv_reader:
        if row[2] != cflag or float(row[0]) < 13:
            continue

        radix = row[0]
        cycleCount = int(row[3])
        addsubCount = int(row[4]) + int(row[5])
        mulCount = int(row[6])
        logicalCount = int(row[7]) + int(row[8]) + int(row[9]) + int(row[10]) + int(row[11])

        radixes.append(round(float(radix), 2))
        cycleCounts.append(cycleCount)
        instructionCounts.append(addsubCount + mulCount + logicalCount)

        addsubCounts.append(addsubCount)
        mulCounts.append(mulCount)
        logicalCounts.append(logicalCount)


fig, ax1 = plt.subplots()
x = np.arange(len(radixes))

width = 0.4
offset = width / 2 + 0.02

color = "tab:red"
ax1.bar(x-offset, cycleCounts, width=(width/4)*3, color=color, label='cycles')

ax1.yaxis.set_label_coords(0.11, 1.005)
ax1.set_ylabel('cycles', color=color, rotation=0)

ax1.ticklabel_format(axis='y', style='sci', scilimits=(0,0), useMathText=True)
ax1.tick_params(axis='y', labelcolor=color)

ax1.set_xlabel('r', fontsize=9)
ax1.xaxis.set_label_coords(0.005, -0.04)
ax1.set_xticks(x)
ax1.set_xticklabels(radixes, fontsize=9, rotation=33)

ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis

# blue: rgb(31, 119, 180) red: rgb(214, 39, 40), green rgb(44, 160, 44)
color="tab:blue"
colors = [(0.1216, 0.4667, 0.7059, 0.4), (0.1216, 0.4667, 0.7059, 0.7), (0.1216, 0.4667, 0.7059, 1)]
# redcolors = [(0.8392, 0.1529, 0.1569, 0.4), (0.8392, 0.1529, 0.1569, 0.7), (0.8392, 0.1529, 0.1569, 1)]
# greencolors = [(0.1725, 0.6275, 0.1725, 0.4), (0.1725, 0.6275, 0.1725, 0.7), (0.1725, 0.6275, 0.1725, 1)]
ax2.bar(x+offset, logicalCounts, width=width, color=colors[0], label='bit operations')
ax2.bar(x+offset, mulCounts, width=width, color=colors[1], bottom=logicalCounts, label='mul')
bottom_offset = [sum(x) for x in zip(logicalCounts,mulCounts)]
ax2.bar(x+offset, addsubCounts, width=width, color=colors[2], bottom=bottom_offset, label='add/sub')

ax2.yaxis.set_label_coords(0.855, 1.040)
ax2.set_ylabel('instructions', color=color, rotation=0)

ax2.ticklabel_format(axis='y', style='sci', scilimits=(0,0), useMathText=True)
ax2.tick_params(axis='y', labelcolor=color)

fig.legend(loc=(0.08, 0.743))

fig.tight_layout()  # otherwise the right y-label is slightly clipped

# fig.tight_layout()
# plt.show()
fig.savefig(f"{current_dir}/benchmark-generic.pdf", bbox_inches='tight')
