#!/usr/bin/env python3

from pathlib import Path
import csv
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import numpy as np
import copy

cflag = "generic_any_radix_codegeneration_cflags_0"
current_dir = str(Path(__file__).resolve().parent)
file = current_dir + "/benchmark-multiplications.csv"


excelContent = {}
with open(file) as csvf:
    csv_reader = csv.reader(csvf, delimiter=',')
    for row in csv_reader:
        if row[3] != cflag:
            continue

        radix = row[0]
        multiplication = row[1]
        cycles = int(row[4])

        # cycles,adds,subs,mults,slts,srts,ands,ors,xors,divs
        addsubCount = int(row[5]) + int(row[6])
        mulCount = int(row[7])
        logicalCount = int(row[8]) + int(row[9]) + int(row[10]) + int(row[11]) + int(row[12])

        if not radix in excelContent:
            excelContent[radix] = {}

        excelContent[radix][multiplication] = {
            "cycles": cycles,
            "addsub": addsubCount,
            "mul": mulCount,
            "logical": logicalCount
        }


radixes = []
schoolbookCount = {"cycles": list(), "addsub": list(), "mul": list(), "logical": list()}
karatsubaCount = copy.deepcopy(schoolbookCount)
for radix in sorted(excelContent.keys(), reverse=True):
    radixes.append(radix)

    for key in schoolbookCount.keys():
        schoolbookCount[key].append(excelContent[radix]["schoolbook"][key])
        karatsubaCount[key].append(excelContent[radix]["karatsuba"][key])

def plot_instructions(axis, offset, counts, width, colors):
    l1 = axis.bar(offset, counts["logical"], width=width, color=colors[0])
    l2 = axis.bar(offset, counts["mul"], width=width, color=colors[1], bottom=counts["logical"])
    bottom_offset = [sum(x) for x in zip(counts["logical"],counts["mul"])]
    l3 = axis.bar(offset, counts["addsub"], width=width, color=colors[2], bottom=bottom_offset)
    return [l1, l2, l3]


fig, ax1 = plt.subplots()
x = np.arange(len(radixes))

width = 0.2
offset1 = width / 2 + 0.02
offset2 = width / 2 + width + 0.04

color = "tab:red"
ax1_l = ax1.bar(x-offset2, schoolbookCount["cycles"], width=width, color=color, label='cycles')
ax1.bar(x+offset1, karatsubaCount["cycles"], width=width, color=color, label='cycles')

ax1.yaxis.set_label_coords(0.11, 1.005)
ax1.set_ylabel('cycles', color=color, rotation=0)

ax1.ticklabel_format(axis='y', style='sci', scilimits=(0,0), useMathText=True)
ax1.tick_params(axis='y', labelcolor=color)

ax1.set_xlabel('r', fontsize=9)
ax1.xaxis.set_label_coords(0.005, -0.03)
ax1.set_xticks(x)
ax1.set_xticklabels(radixes, fontsize=9, rotation=33)

ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis

color="tab:blue"
colors = [(0.1216, 0.4667, 0.7059, 0.4), (0.1216, 0.4667, 0.7059, 0.7), (0.1216, 0.4667, 0.7059, 1)]
ax2_ls = plot_instructions(ax2, x-offset1, schoolbookCount, width, colors)
plot_instructions(ax2, x+offset2, karatsubaCount, width, colors)

ax2.yaxis.set_label_coords(+0.855, 1.042)
ax2.set_ylabel('instructions', color=color, rotation=0)

ax2.ticklabel_format(axis='y', style='sci', scilimits=(0,0), useMathText=True)
ax2.tick_params(axis='y', labelcolor=color)

fig.text(0.13, 0.065, 'naive', fontsize=7)
fig.text(0.24, 0.065, 'karatsuba', fontsize=7)

fig.text(0.4, 0.065, 'naive', fontsize=7)
fig.text(0.515, 0.065, 'karatsuba', fontsize=7)

fig.text(0.68, 0.065, 'naive', fontsize=7)
fig.text(0.79, 0.065, 'karatsuba', fontsize=7)

fig.legend([ax1_l] + ax2_ls, ["cycles", "bit operations", "mul", "add/sub"], loc=(0.06, 0.745))

fig.tight_layout()  # otherwise the right y-label is slightly clipped

# fig.tight_layout()
# plt.show()
fig.savefig(f"{current_dir}/benchmark-all-multiplications.pdf", bbox_inches='tight')
