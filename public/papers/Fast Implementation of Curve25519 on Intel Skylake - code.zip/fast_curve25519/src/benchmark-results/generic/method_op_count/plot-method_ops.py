#!/usr/bin/env python3

import csv
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import numpy as np
from pathlib import Path

current_dir = str(Path(__file__).resolve().parent)
file = "./method_ops.csv"

methods_data = {"other": [], "add": [], "sub": [], "swap": [], "mul a24": [], "invert": [], "square": [],"mul": []}
row_blacklist = ["total", "curve mul", "name"]

with open(file) as csvf:
    csv_reader = csv.reader(csvf, delimiter=',')
    for row in csv_reader:
        method = row[0]

        if method in methods_data.keys():
            methods_data[method] = row
        elif not method in row_blacklist:
            methods_data["other"].append(row)

other_count = [0,0,0,0,0,0,0,0,0,0,0]
for others in methods_data["other"]:
    int_others = map(int, others[1:])
    other_count = [sum(x) for x in zip(other_count, int_others)]

methods_data["other"] = ["other"] + other_count
print(methods_data["other"])
methods = []

addsubCounts = []
mulCounts = []
logicalCounts = []
for method, row in methods_data.items():
    #adds,subs,mults,slts,srts,ands,ors,xors,divs

    addsubCount = int(row[1]) + int(row[2])
    mulCount = int(row[3])
    logicalCount = int(row[4]) + int(row[5]) + int(row[6]) + int(row[7]) + int(row[8])

    methods.append(method)

    addsubCounts.append(addsubCount)
    mulCounts.append(mulCount)
    logicalCounts.append(logicalCount)




fig, ax1 = plt.subplots()
x = np.arange(len(methods))

width = 0.8

ax1.set_xlabel('methods', fontweight='bold')
ax1.set_xticks(x)
ax1.set_xticklabels(methods)

# blue: rgb(31, 119, 180) red: rgb(214, 39, 40), green rgb(44, 160, 44)
color="tab:blue"
colors = [(0.1216, 0.4667, 0.7059, 0.4), (0.1216, 0.4667, 0.7059, 0.7), (0.1216, 0.4667, 0.7059, 1)]
# redcolors = [(0.8392, 0.1529, 0.1569, 0.4), (0.8392, 0.1529, 0.1569, 0.7), (0.8392, 0.1529, 0.1569, 1)]
# greencolors = [(0.1725, 0.6275, 0.1725, 0.4), (0.1725, 0.6275, 0.1725, 0.7), (0.1725, 0.6275, 0.1725, 1)]
ax1.bar(x, logicalCounts, width=width, color=colors[0], label='bit operations')
ax1.bar(x, mulCounts, width=width, color=colors[1], bottom=logicalCounts, label='mul')
bottom_offset = [sum(x) for x in zip(logicalCounts,mulCounts)]
ax1.bar(x, addsubCounts, width=width, color=colors[2], bottom=bottom_offset, label='add/sub')

ax1.yaxis.set_label_coords(0.140, 1.000)
ax1.set_ylabel('instructions', color=color, rotation=0)

ax1.ticklabel_format(axis='y', style='sci', scilimits=(0,0), useMathText=True)
ax1.tick_params(axis='y', labelcolor=color)

fig.legend(loc=(0.08, 0.79))

fig.tight_layout()  # otherwise the right y-label is slightly clipped

# fig.tight_layout()
# plt.show()
fig.savefig(f"{current_dir}/method_ops.pdf", bbox_inches='tight')
