#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "crypto_scalarmult.h"
#include "tsc_x86.h"

#define N_RUNS_OVERHEAD 100000

void bench_latency_curve25519(int n_runs) {
    uint8_t n[32] = {
        0x4b, 0x66, 0xe9, 0xd4, 0xd1, 0xb4, 0x67, 0x3c,
        0x5a, 0xd2, 0x26, 0x91, 0x95, 0x7d, 0x6a, 0xf5,
        0xc1, 0x1b, 0x64, 0x21, 0xe0, 0xea, 0x01, 0xd4,
        0x2c, 0xa4, 0x16, 0x9e, 0x79, 0x18, 0xba, 0x0d
    };
    uint8_t base[32] = { 0x09 };

    uint64_t overhead = tsc_overhead(N_RUNS_OVERHEAD);
    assert(overhead == 0 && "The TSC overhead should be 0!");

    // warm-up run
    for (int i = 0; i < n_runs; i++) {
        crypto_scalarmult(n, n, base);
    }

    // bechmark
    uint64_t cycles = UINT64_MAX;
    uint64_t start, c;
    for (int i = 0; i < n_runs; i++) {
        start = start_tsc();
        crypto_scalarmult(n, n, base);
        c = stop_tsc(start);
        if (c < cycles) {
            cycles = c;
        }
    }

    printf("%ld\n", cycles);
}

int main(int argc, char **argv) {
    (void) argc;
    int n_runs = 10000;
    if (argv[1]) {
        n_runs = atoi(argv[1]);
    }
    bench_latency_curve25519(n_runs);
    return 0;
}
