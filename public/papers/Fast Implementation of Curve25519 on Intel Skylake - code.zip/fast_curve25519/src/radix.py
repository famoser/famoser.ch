#!/usr/bin/env python3

# build field multiplication operation for a given redundant representation.

import math

c       = 19    # prime field constant (2^m - 19)
m       = 255   # prime field constant (2^m - 19)

# n       = 32    # register size
# radix   = 25.5  # representation size (n')
# s       = 10    # no. of words

# n       = 64    # register size
# radix   = 51  # representation size (n')
# s       = 5    # no. of words

n       = 53    # register size
radix   = 21.25  # representation size (n')
s       = 12    # no. of words

# n       = 53 # register size
# radix   = 22 # representation size (n')
# s       = 12 # no. of words

double = True  # select to use or not use a double implementation

print(f'n={n}, radix={radix}, s={s}, c={c}, m={m}')
print('representation:\n')
for i in range(0, s):
    exp = math.ceil(i * radix)
    beta = math.ceil(radix * (i+1)) - math.ceil(radix * i)
    if i == 0:
        print(f'  a{i} * 2^{exp} (beta={beta})')
    else:
        print(f'+ a{i} * 2^{exp} (beta={beta})')


print('\nsquaring (R = A*A):\n')
addc = 0
multc = 0
for i in range(0, s):
    r = f'r{i}'
    print(f'{r:3} = ', end='')
    lo = math.ceil(i/2)
    hi = math.floor(0.5 * (s+i))
    # print(f'lo={lo},hi={hi}')
    for j in range(lo, hi+1):
        t = (i - j) % s

        delta = 1
        if j + t >= s:
            delta = c

        eta = 0
        if not double:
            v0 = math.ceil(j * radix)
            v1 = math.ceil(t * radix)
            v2 = math.ceil(((j+t) % s) * radix)
            eta = (v0 + v1 - v2) % m

        V = 1
        if j != t:
            V = 2

        q = delta * 2**eta * V
        if q == 1:
            qstr = ''
        else:
            multc += 1
            qstr = str(q) + '*'

        multc += 1
        ss = f'{qstr:5}a{j}*a{t}'
        if j < hi:
            addc += 1
            print(f'{ss:12} + ', end='')
        else:
            print(f'{ss:12};')

print(f'\n{multc} mults, {addc} additions (no reductions)\n')


print('\nmultiplication (R = A*B):\n')
addc = 0
multc = 0
for i in range(0, s):
    r = f'r{i}'
    print(f'{r:3} = ', end='')
    for j in range(0, s):
        t = (i - j) % s

        delta = 1
        if j + t >= s:
            delta = c

        eta = 0
        if not double:
            v0 = math.ceil(j * radix)
            v1 = math.ceil(t * radix)
            v2 = math.ceil(((j+t) % s) * radix)
            eta = (v0 + v1 - v2) % m

        q = delta * 2**eta
        if q == 1:
            qstr = ''
        else:
            multc += 1
            qstr = str(q) + '*'

        multc += 1
        ss = f'{qstr:5}a{j}*b{t}'
        if j < s-1:
            addc += 1
            print(f'{ss:12} + ', end='')
        else:
            print(f'{ss:12};')

print(f'\n{multc} mults, {addc} additions (no reductions)\n')
