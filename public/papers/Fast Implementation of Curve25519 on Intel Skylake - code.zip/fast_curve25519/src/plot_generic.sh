cp benchmark-generic.csv ./benchmark-results/generic/all_radixes/benchmark-generic.csv
cp benchmark-multiplications.csv ./benchmark-results/generic/all_multiplications/benchmark-multiplications.csv

./benchmark-results/generic/all_multiplications/plot-all-multiplications.py 
./benchmark-results/generic/all_radixes/plot-all-radixes.py