# Montgomery ladder tuned for floating point + AVX2

Packed format:

```
<a,b>

<=>

(a0,  a1,  b0,  b1)
(a2,  a3,  b2,  b3)
(a4,  a5,  b4,  b5)
(a6,  a7,  b6,  b7)
(a8,  a9,  b8,  b9)
(a10, a11, b10, b11)
```

One ladder step:

```
<A,B> := <x_2+z_2,x_2-z_2>
<D,C> := <x_3-z_3,x_3-z_3>
<AA,BB> := packed_square(<A,B>)
<DA,CB> := packed_mul(<A,B>, <D,C>)
<AA,BB>, <DA,CB> := double_packed_carry(<AA,BB>, <DA,CB>)

<t0,t1> := <DA+CB,DA-CB>
<t0^2,t1^2> := packed_square(<t0,t1>)

<0,E> := <0,AA-BB>
<0,t4> := <0,E*24 + AA> // mul a24 fma
<t0^2,t1^2>, <0,t4> := double_packed_carry(<t0^2,t1^2>, <0,t4>)

<AA,t4>, <BB,E> := construct from previous results
<x_2,z_2> := packed_mul(<AA,t4>, <BB,E>)
<0,z_3> := vectorized_mul_x1(<_,t1^2>)
<x_2,z_2>, <0,z_3> := double_packed_carry(<x_2,z_2>, <0,z_3>);
<x_3,z_3> := blend(<t0^2,t1^2>, <0,z_3>)
```
