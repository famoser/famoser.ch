#ifndef __CURVE25519_FMA_H
#define __CURVE25519_FMA_H

#include <stdint.h>

typedef uint8_t byte32_t[32] __attribute__((aligned(32)));
typedef double field_t[12] __attribute__((aligned(32)));
typedef double field_twopack_t[24] __attribute__((aligned(32)));
typedef double field_quadpack_t[48] __attribute__((aligned(32)));

#endif // __CURVE25519_FMA_H
