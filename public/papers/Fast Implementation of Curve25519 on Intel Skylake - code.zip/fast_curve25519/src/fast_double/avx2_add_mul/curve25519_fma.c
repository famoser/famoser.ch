#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>
#include <inttypes.h>
#include <assert.h>
#include <math.h>

#include "crypto_scalarmult.h"
#include "curve25519_fma.h"
#include "radix51.h"

#define force_inline __attribute__((always_inline)) inline
#define a24 121665
#define p20 0x100000L // (int64_t) (1<<20)
#define p21 0x200000L // (int64_t) (1<<21)

const double c2p22      = 4194304.0;              // 2^22
const double c2p43      = 8796093022208.0;        // 2^43
const double c2p64      = 1.8446744073709552e+19; // 2^64
const double c2p85      = 3.8685626227668134e+25; // 2^85
const double c2p107     = 1.6225927682921336e+32; // 2^107
const double c2p128     = 3.402823669209385e+38;  // 2^128
const double c2p149     = 7.1362384635298e+44;    // 2^149
const double c2p170     = 1.4965776766268446e+51; // 2^170
const double c2p192     = 6.277101735386681e+57;  // 2^192
const double c2p213     = 1.3164036458569648e+64; // 2^213
const double c2p234     = 2.7606985387162255e+70; // 2^234
const double top_22_53  = 2.833419889721787e+22;  // 3*2^(22+53-2)
const double top_43_53  = 5.942112188569825e+28;  // 3*2^(43+53-2)
const double top_64_53  = 1.2461512460483586e+35; // 3*2^(64+53-2)
const double top_85_53  = 2.6133685779528074e+41; // 3*2^(85+53-2)
const double top_107_53 = 1.0961262279981772e+48; // 3*2^(107+53-2)
const double top_128_53 = 2.2987433112988333e+54; // 3*2^(128+53-2)
const double top_149_53 = 4.820814132776971e+60;  // 3*2^(149+53-2)
const double top_170_53 = 1.010998000018149e+67;  // 3*2^(170+53-2)
const double top_192_53 = 4.2404329554681224e+73; // 3*2^(192+53-2)
const double top_213_53 = 8.892832453425884e+79;  // 3*2^(213+53-2)
const double top_234_53 = 1.8649621365367e+86;    // 3*2^(234+53-2)
const double top_255_53 = 3.911109074562213e+92;  // 3*2^(255+53-2)
const double c19        = 3.281744050935889e-76;  // 19*2^(-255)
const double c38        = 6.563488101871778e-76;  // 38*2^(-255)

force_inline
void field_sub(field_t dst, field_t a, field_t b) {
    __m256d a0 = _mm256_load_pd(a+0);
    __m256d a4 = _mm256_load_pd(a+4);
    __m256d a8 = _mm256_load_pd(a+8);
    __m256d b0 = _mm256_load_pd(b+0);
    __m256d b4 = _mm256_load_pd(b+4);
    __m256d b8 = _mm256_load_pd(b+8);
    _mm256_store_pd(dst+0, _mm256_sub_pd(a0, b0));
    _mm256_store_pd(dst+4, _mm256_sub_pd(a4, b4));
    _mm256_store_pd(dst+8, _mm256_sub_pd(a8, b8));
}

// dst0 = a + b
// dst1 = a - b
force_inline
void field_add_sub(field_t dst0, field_t dst1, field_t a, field_t b) {
    __m256d a0 = _mm256_load_pd(a+0);
    __m256d a4 = _mm256_load_pd(a+4);
    __m256d a8 = _mm256_load_pd(a+8);
    __m256d b0 = _mm256_load_pd(b+0);
    __m256d b4 = _mm256_load_pd(b+4);
    __m256d b8 = _mm256_load_pd(b+8);
    _mm256_store_pd(dst0+0, _mm256_add_pd(a0, b0));
    _mm256_store_pd(dst0+4, _mm256_add_pd(a4, b4));
    _mm256_store_pd(dst0+8, _mm256_add_pd(a8, b8));
    _mm256_store_pd(dst1+0, _mm256_sub_pd(a0, b0));
    _mm256_store_pd(dst1+4, _mm256_sub_pd(a4, b4));
    _mm256_store_pd(dst1+8, _mm256_sub_pd(a8, b8));
}

force_inline
void field_carry(field_t a) {
    double carry[12];
    carry[0]  = (a[0] + top_22_53)   - top_22_53;  a[0] -= carry[0];   a[1] += carry[0];
    carry[5]  = (a[5] + top_128_53)  - top_128_53; a[5] -= carry[5];   a[6] += carry[5];
    carry[1]  = (a[1] + top_43_53)   - top_43_53;  a[1] -= carry[1];   a[2] += carry[1];
    carry[6]  = (a[6] + top_149_53)  - top_149_53; a[6] -= carry[6];   a[7] += carry[6];
    carry[2]  = (a[2] + top_64_53)   - top_64_53;  a[2] -= carry[2];   a[3] += carry[2];
    carry[7]  = (a[7] + top_170_53)  - top_170_53; a[7] -= carry[7];   a[8] += carry[7];
    carry[3]  = (a[3] + top_85_53)   - top_85_53;  a[3] -= carry[3];   a[4] += carry[3];
    carry[8]  = (a[8] + top_192_53)  - top_192_53; a[8] -= carry[8];   a[9] += carry[8];
    carry[4]  = (a[4] + top_107_53)  - top_107_53; a[4] -= carry[4];   a[5] += carry[4];
    carry[9]  = (a[9] + top_213_53)  - top_213_53; a[9] -= carry[9];   a[10] += carry[9];
    carry[5]  = (a[5] + top_128_53)  - top_128_53; a[5] -= carry[5];   a[6] += carry[5];
    carry[10] = (a[10] + top_234_53) - top_234_53; a[10] -= carry[10]; a[11] += carry[10];
    carry[11] = (a[11] + top_255_53) - top_255_53; a[11] -= carry[11]; a[0] += c19*carry[11];
    carry[0]  = (a[0] + top_22_53)   - top_22_53;  a[0] -= carry[0];   a[1] += carry[0];
}

force_inline
void field_fma_a24(field_t dst, field_t m, field_t a) {
    __m256d a24_v = _mm256_set1_pd(a24);
    __m256d m0 = _mm256_load_pd(m+0);
    __m256d m4 = _mm256_load_pd(m+4);
    __m256d m8 = _mm256_load_pd(m+8);
    __m256d a0 = _mm256_load_pd(a+0);
    __m256d a4 = _mm256_load_pd(a+4);
    __m256d a8 = _mm256_load_pd(a+8);
    m0 = _mm256_fmadd_pd(m0, a24_v, a0);
    m4 = _mm256_fmadd_pd(m4, a24_v, a4);
    m8 = _mm256_fmadd_pd(m8, a24_v, a8);
    _mm256_store_pd(dst+0, m0);
    _mm256_store_pd(dst+4, m4);
    _mm256_store_pd(dst+8, m8);
    field_carry(dst);
}

// <A,C>, <B,D> -> <A*B,C*D> = z
force_inline
void field_packed_mul(field_twopack_t dst, field_twopack_t ac, field_twopack_t bd) {
    __m256d z0 = _mm256_setzero_pd();
    __m256d z1 = _mm256_setzero_pd();
    __m256d z2 = _mm256_setzero_pd();
    __m256d z3 = _mm256_setzero_pd();
    __m256d z4 = _mm256_setzero_pd();
    __m256d z5 = _mm256_setzero_pd();

    __m256d ac0 = _mm256_load_pd(ac+0);
    __m256d ac1 = _mm256_load_pd(ac+4);
    __m256d ac2 = _mm256_load_pd(ac+8);
    __m256d ac3 = _mm256_load_pd(ac+12);
    __m256d ac4 = _mm256_load_pd(ac+16);
    __m256d ac5 = _mm256_load_pd(ac+20);

    // even columns
    __m256d bd0 = _mm256_load_pd(bd+0);
    __m256d bd1 = _mm256_load_pd(bd+4);
    __m256d bd2 = _mm256_load_pd(bd+8);
    __m256d bd3 = _mm256_load_pd(bd+12);
    __m256d bd4 = _mm256_load_pd(bd+16);
    __m256d bd5 = _mm256_load_pd(bd+20);

    __m256d c19_v = _mm256_set1_pd(c19);
    __m256d bd1_19 = _mm256_mul_pd(bd1, c19_v);
    __m256d bd2_19 = _mm256_mul_pd(bd2, c19_v);
    __m256d bd3_19 = _mm256_mul_pd(bd3, c19_v);
    __m256d bd4_19 = _mm256_mul_pd(bd4, c19_v);
    __m256d bd5_19 = _mm256_mul_pd(bd5, c19_v);

    __m256d a_0_0_c_0_0 = _mm256_shuffle_pd(ac0, ac0, 0x0);
    z0 = _mm256_fmadd_pd(a_0_0_c_0_0, bd0, z0);
    z1 = _mm256_fmadd_pd(a_0_0_c_0_0, bd1, z1);
    z2 = _mm256_fmadd_pd(a_0_0_c_0_0, bd2, z2);
    z3 = _mm256_fmadd_pd(a_0_0_c_0_0, bd3, z3);
    z4 = _mm256_fmadd_pd(a_0_0_c_0_0, bd4, z4);
    z5 = _mm256_fmadd_pd(a_0_0_c_0_0, bd5, z5);
    __m256d a_2_2_c_2_2 = _mm256_shuffle_pd(ac1, ac1, 0x0);
    z0 = _mm256_fmadd_pd(a_2_2_c_2_2, bd5_19, z0);
    z1 = _mm256_fmadd_pd(a_2_2_c_2_2, bd0, z1);
    z2 = _mm256_fmadd_pd(a_2_2_c_2_2, bd1, z2);
    z3 = _mm256_fmadd_pd(a_2_2_c_2_2, bd2, z3);
    z4 = _mm256_fmadd_pd(a_2_2_c_2_2, bd3, z4);
    z5 = _mm256_fmadd_pd(a_2_2_c_2_2, bd4, z5);
    __m256d a_4_4_c_4_4 = _mm256_shuffle_pd(ac2, ac2, 0x0);
    z0 = _mm256_fmadd_pd(a_4_4_c_4_4, bd4_19, z0);
    z1 = _mm256_fmadd_pd(a_4_4_c_4_4, bd5_19, z1);
    z2 = _mm256_fmadd_pd(a_4_4_c_4_4, bd0, z2);
    z3 = _mm256_fmadd_pd(a_4_4_c_4_4, bd1, z3);
    z4 = _mm256_fmadd_pd(a_4_4_c_4_4, bd2, z4);
    z5 = _mm256_fmadd_pd(a_4_4_c_4_4, bd3, z5);
    __m256d a_6_6_c_6_6 = _mm256_shuffle_pd(ac3, ac3, 0x0);
    z0 = _mm256_fmadd_pd(a_6_6_c_6_6, bd3_19, z0);
    z1 = _mm256_fmadd_pd(a_6_6_c_6_6, bd4_19, z1);
    z2 = _mm256_fmadd_pd(a_6_6_c_6_6, bd5_19, z2);
    z3 = _mm256_fmadd_pd(a_6_6_c_6_6, bd0, z3);
    z4 = _mm256_fmadd_pd(a_6_6_c_6_6, bd1, z4);
    z5 = _mm256_fmadd_pd(a_6_6_c_6_6, bd2, z5);
    __m256d a_8_8_c_8_8 = _mm256_shuffle_pd(ac4, ac4, 0x0);
    z0 = _mm256_fmadd_pd(a_8_8_c_8_8, bd2_19, z0);
    z1 = _mm256_fmadd_pd(a_8_8_c_8_8, bd3_19, z1);
    z2 = _mm256_fmadd_pd(a_8_8_c_8_8, bd4_19, z2);
    z3 = _mm256_fmadd_pd(a_8_8_c_8_8, bd5_19, z3);
    z4 = _mm256_fmadd_pd(a_8_8_c_8_8, bd0, z4);
    z5 = _mm256_fmadd_pd(a_8_8_c_8_8, bd1, z5);
    __m256d a_10_10_c_10_10 = _mm256_shuffle_pd(ac5, ac5, 0x0);
    z0 = _mm256_fmadd_pd(a_10_10_c_10_10, bd1_19, z0);
    z1 = _mm256_fmadd_pd(a_10_10_c_10_10, bd2_19, z1);
    z2 = _mm256_fmadd_pd(a_10_10_c_10_10, bd3_19, z2);
    z3 = _mm256_fmadd_pd(a_10_10_c_10_10, bd4_19, z3);
    z4 = _mm256_fmadd_pd(a_10_10_c_10_10, bd5_19, z4);
    z5 = _mm256_fmadd_pd(a_10_10_c_10_10, bd0, z5);

    // odd columns
    __m256d b_1_2_d_1_2 = _mm256_shuffle_pd(bd0, bd1, 0x5); // 0x5 = 0b0101
    __m256d b_3_4_d_3_4 = _mm256_shuffle_pd(bd1, bd2, 0x5);
    __m256d b_5_6_d_5_6 = _mm256_shuffle_pd(bd2, bd3, 0x5);
    __m256d b_7_8_d_7_8 = _mm256_shuffle_pd(bd3, bd4, 0x5);
    __m256d b_9_10_d_9_10 = _mm256_shuffle_pd(bd4, bd5, 0x5);

    __m256d bd0_19 = _mm256_mul_pd(bd0, c19_v);
    __m256d b_1_2_d_1_2__19 = _mm256_shuffle_pd(bd0_19, bd1_19, 0x5);
    __m256d b_3_4_d_3_4__19 = _mm256_shuffle_pd(bd1_19, bd2_19, 0x5); 
    __m256d b_5_6_d_5_6__19 = _mm256_shuffle_pd(bd2_19, bd3_19, 0x5); 
    __m256d b_7_8_d_7_8__19 = _mm256_shuffle_pd(bd3_19, bd4_19, 0x5); 
    __m256d b_9_10_d_9_10__19 = _mm256_shuffle_pd(bd4_19, bd5_19, 0x5);
    __m256d b_11_0_d_11_0__19 = _mm256_shuffle_pd(bd5_19, bd0, 0x5);

    __m256d a_1_1_c_1_1 = _mm256_shuffle_pd(ac0, ac0, 0xf); // 0xf = 0b1111
    z0 = _mm256_fmadd_pd(a_1_1_c_1_1, b_11_0_d_11_0__19, z0);
    z1 = _mm256_fmadd_pd(a_1_1_c_1_1, b_1_2_d_1_2, z1);
    z2 = _mm256_fmadd_pd(a_1_1_c_1_1, b_3_4_d_3_4, z2);
    z3 = _mm256_fmadd_pd(a_1_1_c_1_1, b_5_6_d_5_6, z3);
    z4 = _mm256_fmadd_pd(a_1_1_c_1_1, b_7_8_d_7_8, z4);
    z5 = _mm256_fmadd_pd(a_1_1_c_1_1, b_9_10_d_9_10, z5);
    __m256d a_3_3_c_3_3 = _mm256_shuffle_pd(ac1, ac1, 0xf);
    z0 = _mm256_fmadd_pd(a_3_3_c_3_3, b_9_10_d_9_10__19, z0);
    z1 = _mm256_fmadd_pd(a_3_3_c_3_3, b_11_0_d_11_0__19, z1);
    z2 = _mm256_fmadd_pd(a_3_3_c_3_3, b_1_2_d_1_2, z2);
    z3 = _mm256_fmadd_pd(a_3_3_c_3_3, b_3_4_d_3_4, z3);
    z4 = _mm256_fmadd_pd(a_3_3_c_3_3, b_5_6_d_5_6, z4);
    z5 = _mm256_fmadd_pd(a_3_3_c_3_3, b_7_8_d_7_8, z5);
    __m256d a_5_5_c_5_5 = _mm256_shuffle_pd(ac2, ac2, 0xf);
    z0 = _mm256_fmadd_pd(a_5_5_c_5_5, b_7_8_d_7_8__19, z0);
    z1 = _mm256_fmadd_pd(a_5_5_c_5_5, b_9_10_d_9_10__19, z1);
    z2 = _mm256_fmadd_pd(a_5_5_c_5_5, b_11_0_d_11_0__19, z2);
    z3 = _mm256_fmadd_pd(a_5_5_c_5_5, b_1_2_d_1_2, z3);
    z4 = _mm256_fmadd_pd(a_5_5_c_5_5, b_3_4_d_3_4, z4);
    z5 = _mm256_fmadd_pd(a_5_5_c_5_5, b_5_6_d_5_6, z5);
    __m256d a_7_7_c_7_7 = _mm256_shuffle_pd(ac3, ac3, 0xf);
    z0 = _mm256_fmadd_pd(a_7_7_c_7_7, b_5_6_d_5_6__19, z0);
    z1 = _mm256_fmadd_pd(a_7_7_c_7_7, b_7_8_d_7_8__19, z1);
    z2 = _mm256_fmadd_pd(a_7_7_c_7_7, b_9_10_d_9_10__19, z2);
    z3 = _mm256_fmadd_pd(a_7_7_c_7_7, b_11_0_d_11_0__19, z3);
    z4 = _mm256_fmadd_pd(a_7_7_c_7_7, b_1_2_d_1_2, z4);
    z5 = _mm256_fmadd_pd(a_7_7_c_7_7, b_3_4_d_3_4, z5);
    __m256d a_9_9_c_9_9 = _mm256_shuffle_pd(ac4, ac4, 0xf);
    z0 = _mm256_fmadd_pd(a_9_9_c_9_9, b_3_4_d_3_4__19, z0);
    z1 = _mm256_fmadd_pd(a_9_9_c_9_9, b_5_6_d_5_6__19, z1);
    z2 = _mm256_fmadd_pd(a_9_9_c_9_9, b_7_8_d_7_8__19, z2);
    z3 = _mm256_fmadd_pd(a_9_9_c_9_9, b_9_10_d_9_10__19, z3);
    z4 = _mm256_fmadd_pd(a_9_9_c_9_9, b_11_0_d_11_0__19, z4);
    z5 = _mm256_fmadd_pd(a_9_9_c_9_9, b_1_2_d_1_2, z5);
    __m256d a_11_11_c_11_11 = _mm256_shuffle_pd(ac5, ac5, 0xf);
    z0 = _mm256_fmadd_pd(a_11_11_c_11_11, b_1_2_d_1_2__19, z0);
    z1 = _mm256_fmadd_pd(a_11_11_c_11_11, b_3_4_d_3_4__19, z1);
    z2 = _mm256_fmadd_pd(a_11_11_c_11_11, b_5_6_d_5_6__19, z2);
    z3 = _mm256_fmadd_pd(a_11_11_c_11_11, b_7_8_d_7_8__19, z3);
    z4 = _mm256_fmadd_pd(a_11_11_c_11_11, b_9_10_d_9_10__19, z4);
    z5 = _mm256_fmadd_pd(a_11_11_c_11_11, b_11_0_d_11_0__19, z5);

    _mm256_store_pd(dst+0, z0);
    _mm256_store_pd(dst+4, z1);
    _mm256_store_pd(dst+8, z2);
    _mm256_store_pd(dst+12, z3);
    _mm256_store_pd(dst+16, z4);
    _mm256_store_pd(dst+20, z5);
}

void field_mul(field_t dst, field_t a, field_t b) {
    double a0 = a[0];
    double a1 = a[1];
    double a2 = a[2];
    double a3 = a[3];
    double a4 = a[4];
    double a5 = a[5];
    double a6 = a[6];
    double a7 = a[7];
    double a8 = a[8];
    double a9 = a[9];
    double a10 = a[10];
    double a11 = a[11];
    double b0 = b[0];
    double b1 = b[1];
    double b2 = b[2];
    double b3 = b[3];
    double b4 = b[4];
    double b5 = b[5];
    double b6 = b[6];
    double b7 = b[7];
    double b8 = b[8];
    double b9 = b[9];
    double b10 = b[10];
    double b11 = b[11];

    double b1_c19 = c19 * b1;
    double b2_c19 = c19 * b2;
    double b3_c19 = c19 * b3;
    double b4_c19 = c19 * b4;
    double b5_c19 = c19 * b5;
    double b6_c19 = c19 * b6;
    double b7_c19 = c19 * b7;
    double b8_c19 = c19 * b8;
    double b9_c19 = c19 * b9;
    double b10_c19 = c19 * b10;
    double b11_c19 = c19 * b11;

    dst[0]  = a0*b0  + a1*b11_c19 + a2*b10_c19 + a3*b9_c19  + a4*b8_c19  + a5*b7_c19  + a6*b6_c19  + a7*b5_c19  + a8*b4_c19  + a9*b3_c19  + a10*b2_c19  + a11*b1_c19;
    dst[1]  = a0*b1  + a1*b0      + a2*b11_c19 + a3*b10_c19 + a4*b9_c19  + a5*b8_c19  + a6*b7_c19  + a7*b6_c19  + a8*b5_c19  + a9*b4_c19  + a10*b3_c19  + a11*b2_c19;
    dst[2]  = a0*b2  + a1*b1      + a2*b0      + a3*b11_c19 + a4*b10_c19 + a5*b9_c19  + a6*b8_c19  + a7*b7_c19  + a8*b6_c19  + a9*b5_c19  + a10*b4_c19  + a11*b3_c19;
    dst[3]  = a0*b3  + a1*b2      + a2*b1      + a3*b0      + a4*b11_c19 + a5*b10_c19 + a6*b9_c19  + a7*b8_c19  + a8*b7_c19  + a9*b6_c19  + a10*b5_c19  + a11*b4_c19;
    dst[4]  = a0*b4  + a1*b3      + a2*b2      + a3*b1      + a4*b0      + a5*b11_c19 + a6*b10_c19 + a7*b9_c19  + a8*b8_c19  + a9*b7_c19  + a10*b6_c19  + a11*b5_c19;
    dst[5]  = a0*b5  + a1*b4      + a2*b3      + a3*b2      + a4*b1      + a5*b0      + a6*b11_c19 + a7*b10_c19 + a8*b9_c19  + a9*b8_c19  + a10*b7_c19  + a11*b6_c19;
    dst[6]  = a0*b6  + a1*b5      + a2*b4      + a3*b3      + a4*b2      + a5*b1      + a6*b0      + a7*b11_c19 + a8*b10_c19 + a9*b9_c19  + a10*b8_c19  + a11*b7_c19;
    dst[7]  = a0*b7  + a1*b6      + a2*b5      + a3*b4      + a4*b3      + a5*b2      + a6*b1      + a7*b0      + a8*b11_c19 + a9*b10_c19 + a10*b9_c19  + a11*b8_c19;
    dst[8]  = a0*b8  + a1*b7      + a2*b6      + a3*b5      + a4*b4      + a5*b3      + a6*b2      + a7*b1      + a8*b0      + a9*b11_c19 + a10*b10_c19 + a11*b9_c19;
    dst[9]  = a0*b9  + a1*b8      + a2*b7      + a3*b6      + a4*b5      + a5*b4      + a6*b3      + a7*b2      + a8*b1      + a9*b0      + a10*b11_c19 + a11*b10_c19;
    dst[10] = a0*b10 + a1*b9      + a2*b8      + a3*b7      + a4*b6      + a5*b5      + a6*b4      + a7*b3      + a8*b2      + a9*b1      + a10*b0      + a11*b11_c19;
    dst[11] = a0*b11 + a1*b10     + a2*b9      + a3*b8      + a4*b7      + a5*b6      + a6*b5      + a7*b4      + a8*b3      + a9*b2      + a10*b1      + a11*b0;

    field_carry(dst);
}

void field_square(field_t dst, field_t a) {
    double a0 = a[0];
    double a1 = a[1];
    double a2 = a[2];
    double a3 = a[3];
    double a4 = a[4];
    double a5 = a[5];
    double a6 = a[6];
    double a7 = a[7];
    double a8 = a[8];
    double a9 = a[9];
    double a10 = a[10];
    double a11 = a[11];

    double a0_2 = 2 * a0;
    double a1_2 = 2 * a1;
    double a2_2 = 2 * a2;
    double a3_2 = 2 * a3;
    double a4_2 = 2 * a4;
    double a5_2 = 2 * a5;
    double a7_c38 = c38 * a7;
    double a8_c38 = c38 * a8;
    double a9_c38 = c38 * a9;
    double a10_c38 = c38 * a10;
    double a11_c38 = c38 * a11;

    dst[0]  = a0*a0                                                       + a1*a11_c38   + a2*a10_c38   + a3*a9_c38  + a4*a8_c38  + a5*a7_c38  + c19* a6*a6;
    dst[1]  = a1*a0_2                                                     + a2*a11_c38   + a3*a10_c38   + a4*a9_c38  + a5*a8_c38  + a6*a7_c38;
    dst[2]  = a2*a0_2  + a1*a1                                            + a3*a11_c38   + a4*a10_c38   + a5*a9_c38  + a6*a8_c38  + c19* a7*a7;
    dst[3]  = a3*a0_2  + a2*a1_2                                          + a4*a11_c38   + a5*a10_c38   + a6*a9_c38  + a7*a8_c38;
    dst[4]  = a4*a0_2  + a3*a1_2  + a2*a2                                 + a5*a11_c38   + a6*a10_c38   + a7*a9_c38  + c19* a8*a8;
    dst[5]  = a5*a0_2  + a4*a1_2  + a3*a2_2                               + a6*a11_c38   + a7*a10_c38   + a8*a9_c38;
    dst[6]  = a6*a0_2  + a5*a1_2  + a4*a2_2 + a3*a3                       + a7*a11_c38   + a8*a10_c38   + c19* a9*a9;
    dst[7]  = a7*a0_2  + a6*a1_2  + a5*a2_2 + a4*a3_2                     + a8*a11_c38   + a9*a10_c38;
    dst[8]  = a8*a0_2  + a7*a1_2  + a6*a2_2 + a5*a3_2 + a4*a4             + a9*a11_c38   + c19* a10*a10;
    dst[9]  = a9*a0_2  + a8*a1_2  + a7*a2_2 + a6*a3_2 + a5*a4_2           + a10*a11_c38;
    dst[10] = a10*a0_2 + a9*a1_2  + a8*a2_2 + a7*a3_2 + a6*a4_2 + a5*a5   + c19* a11*a11;
    dst[11] = a11*a0_2 + a10*a1_2 + a9*a2_2 + a8*a3_2 + a7*a4_2 + a6*a5_2;

    field_carry(dst);
}

force_inline
void decode_scalar(byte32_t dst, byte32_t src) {
    memcpy(dst, src, sizeof(byte32_t));
    dst[0] &= 248;
    dst[31] &= 127;
    dst[31] |= 64;
}

force_inline
static uint64_t load_3(uint8_t *in) {
    uint64_t r = 0;
    r |= ((int64_t) in[0]);
    r |= ((int64_t) in[1]) << 8;
    r |= ((int64_t) in[2]) << 16;
    return r;
}

force_inline
static uint64_t load_2(uint8_t *in) {
    uint64_t r = 0;
    r |= ((int64_t) in[0]);
    r |= ((int64_t) in[1]) << 8;
    return r;
}

void decode_point(field_t dst, byte32_t src) {
    int32_t a0 = (*(int32_t *) (src+0) >> 0) & 0x3fffff;
    int32_t a1 = (*(int32_t *) (src+2) >> 6) & 0x1fffff;
    int32_t a2 = (*(int32_t *) (src+5) >> 3) & 0x1fffff;
    int32_t a3 = (*(int32_t *) (src+8) >> 0) & 0x1fffff;
    int32_t a4 = (*(int32_t *) (src+10) >> 5) & 0x3fffff;
    int32_t a5 = (*(int32_t *) (src+13) >> 3) & 0x1fffff;
    int32_t a6 = (*(int32_t *) (src+15) >> 8) & 0x1fffff;
    int32_t a7 = (*(int32_t *) (src+18) >> 5) & 0x1fffff;
    int32_t a8 = (*(int32_t *) (src+21) >> 2) & 0x3fffff;
    int32_t a9 = (*(int32_t *) (src+24) >> 0) & 0x1fffff;
    int32_t a10 = (*(int32_t *) (src+26) >> 5) & 0x1fffff;
    int32_t a11 = (*(int32_t *) (src+29) >> 2) & 0x1fffff;

    dst[0] = ((double) a0);
    dst[1] = ((double) a1) * c2p22;
    dst[2] = ((double) a2) * c2p43;
    dst[3] = ((double) a3) * c2p64;
    dst[4] = ((double) a4) * c2p85;
    dst[5] = ((double) a5) * c2p107;
    dst[6] = ((double) a6) * c2p128;
    dst[7] = ((double) a7) * c2p149;
    dst[8] = ((double) a8) * c2p170;
    dst[9] = ((double) a9) * c2p192;
    dst[10] = ((double) a10) * c2p213;
    dst[11] = ((double) a11) * c2p234;
}

void field_two_pack(field_twopack_t dst, field_t a, field_t b) {
    for (int i = 0; i < 6; i++) {
        dst[i*4 + 0] = a[i*2];
        dst[i*4 + 1] = a[i*2 + 1];
        dst[i*4 + 2] = b[i*2];
        dst[i*4 + 3] = b[i*2 + 1];
    }
}

void field_two_unpack(field_t dst0, field_t dst1, field_twopack_t a) {
    for (int i = 0; i < 6; i++) {
        dst0[i*2] = a[i*4 + 0];
        dst0[i*2 + 1] = a[i*4 + 1];
        dst1[i*2] = a[i*4 + 2];
        dst1[i*2 + 1] = a[i*4 + 3];
    }
}

force_inline
void field_quad_pack(field_quadpack_t dst, field_t a, field_t b, field_t c,
        field_t d) {
    for (int i = 0; i < 12; i++) {
        dst[4*i + 0] = a[i];
        dst[4*i + 1] = b[i];
        dst[4*i + 2] = c[i];
        dst[4*i + 3] = d[i];
    }
}

force_inline
void field_quad_unpack(field_t a, field_t b, field_t c, field_t d,
        field_quadpack_t src) {
    for (int i = 0; i < 12; i++) {
        a[i] = src[4*i + 0];
        b[i] = src[4*i + 1];
        c[i] = src[4*i + 2];
        d[i] = src[4*i + 3];
    }
}

// swap (a, b) with (b, a) iff swap == 1.
force_inline
void cswap(int64_t swap, field_t a, field_t b) {
    __m256i swapv = _mm256_set1_epi64x(-swap);

    // elements of *a must be 8 bytes in length!
    __m256i a0 = _mm256_load_si256((__m256i *) (a+0));
    __m256i a4 = _mm256_load_si256((__m256i *) (a+4));
    __m256i a8 = _mm256_load_si256((__m256i *) (a+8));
    __m256i b0 = _mm256_load_si256((__m256i *) (b+0));
    __m256i b4 = _mm256_load_si256((__m256i *) (b+4));
    __m256i b8 = _mm256_load_si256((__m256i *) (b+8));

    __m256i ab0_xor = _mm256_xor_si256(a0, b0);
    __m256i ab4_xor = _mm256_xor_si256(a4, b4);
    __m256i ab8_xor = _mm256_xor_si256(a8, b8);

    __m256i t0 = _mm256_and_si256(swapv, ab0_xor);
    __m256i t4 = _mm256_and_si256(swapv, ab4_xor);
    __m256i t8 = _mm256_and_si256(swapv, ab8_xor);

    a0 = _mm256_xor_si256(a0, t0);
    a4 = _mm256_xor_si256(a4, t4);
    a8 = _mm256_xor_si256(a8, t8);
    b0 = _mm256_xor_si256(b0, t0);
    b4 = _mm256_xor_si256(b4, t4);
    b8 = _mm256_xor_si256(b8, t8);

    _mm256_store_si256((__m256i *) (a+0), a0);
    _mm256_store_si256((__m256i *) (a+4), a4);
    _mm256_store_si256((__m256i *) (a+8), a8);
    _mm256_store_si256((__m256i *) (b+0), b0);
    _mm256_store_si256((__m256i *) (b+4), b4);
    _mm256_store_si256((__m256i *) (b+8), b8);
}

// As per RFC 7748, Chapter 5
void curve_scalar_mult(field_t dst_x_2, field_t dst_z_2, byte32_t n, field_t P) {
    field_t x_1; memcpy(x_1, P, sizeof(field_t));
    field_t x_2 = { 1 };
    field_t z_2 = { 0 };
    field_t x_3; memcpy(x_3, P, sizeof(field_t));
    field_t z_3 = { 1 };
    int64_t swap = 0;

    for (int32_t i = 254; i >= 0; i--) {
        int64_t bit = (n[i / 8] >> (i & 7)) & 1;
        swap ^= bit;
        cswap(swap, x_2, x_3);
        cswap(swap, z_2, z_3);
        swap = bit;

        field_t A, AA, B, BB, E, C, D, DA, CB;
        field_t t0, t1;

        field_add_sub(A, B, x_2, z_2);
        field_add_sub(C, D, x_3, z_3);

        field_square(AA, A);
        field_square(BB, B);

        // field_mul(DA, D, A);
        // field_mul(CB, C, B);
        field_twopack_t p_DC, p_AB, p_DA_CB;
        field_two_pack(p_DC, D, C);
        field_two_pack(p_AB, A, B);
        field_packed_mul(p_DA_CB, p_DC, p_AB);
        field_two_unpack(DA, CB, p_DA_CB);
        field_carry(DA);
        field_carry(CB);

        field_add_sub(t0, t1, DA, CB);

        field_square(x_3, t0);
        field_square(t1, t1);

        // field_mul(z_3, t1, x_1);
        // field_mul(x_2, AA, BB);
        field_twopack_t p_t1AA, p_x_1BB, p_t1x_1__AABB;
        field_two_pack(p_t1AA, t1, AA);
        field_two_pack(p_x_1BB, x_1, BB);
        field_packed_mul(p_t1x_1__AABB, p_t1AA, p_x_1BB);
        field_two_unpack(z_3, x_2, p_t1x_1__AABB);
        field_carry(z_3);
        field_carry(x_2);

        field_sub(E, AA, BB);
        field_fma_a24(t0, E, AA); // t0 = E*a24 + AA

        field_mul(z_2, E, t0);
    }

    cswap(swap, x_2, x_3);
    cswap(swap, z_2, z_3);
    memcpy(dst_x_2, x_2, sizeof(field_t));
    memcpy(dst_z_2, z_2, sizeof(field_t));
}

int crypto_scalarmult(unsigned char * dst,
                      const unsigned char *n,
                      const unsigned char *P) {
    byte32_t scalar;
    decode_scalar(scalar, (uint8_t *) n);

    field_t base, x_2, z_2;
    decode_point(base, (uint8_t *) P);
    curve_scalar_mult(x_2, z_2, scalar, base);

    field51_t x, z;
    field_double_to_51(x, x_2);
    field_double_to_51(z, z_2);
    field_invert_51(z, z);
    field_mul_51(x, x, z);
    encode_point_51((uint8_t *) dst, x);

    return 0;
}

