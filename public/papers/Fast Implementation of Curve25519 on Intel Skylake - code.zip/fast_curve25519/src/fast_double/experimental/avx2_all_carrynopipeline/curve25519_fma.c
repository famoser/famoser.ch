#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>
#include <inttypes.h>
#include <assert.h>
#include <math.h>

#include "crypto_scalarmult.h"
#include "curve25519_fma.h"
#include "radix51.h"

#define force_inline static __attribute__((always_inline)) inline
#define a24 121665
#define p20 0x100000L // (int64_t) (1<<20)
#define p21 0x200000L // (int64_t) (1<<21)

#define V_LOAD_FIELD(VNAME, ADDR) \
    __m256d VNAME##0 = _mm256_load_pd(ADDR+0); \
    __m256d VNAME##4 = _mm256_load_pd(ADDR+4); \
    __m256d VNAME##8 = _mm256_load_pd(ADDR+8); \

#define V_STORE_PACKED(VNAME, DST) \
    _mm256_store_pd(DST+0, VNAME##0); \
    _mm256_store_pd(DST+4, VNAME##1); \
    _mm256_store_pd(DST+8, VNAME##2); \
    _mm256_store_pd(DST+12, VNAME##3); \
    _mm256_store_pd(DST+16, VNAME##4); \
    _mm256_store_pd(DST+20, VNAME##5);

#define V_LOAD_PACKED(VNAME, SRC) \
    __m256d VNAME##0 = _mm256_load_pd(SRC+0); \
    __m256d VNAME##1 = _mm256_load_pd(SRC+4); \
    __m256d VNAME##2 = _mm256_load_pd(SRC+8); \
    __m256d VNAME##3 = _mm256_load_pd(SRC+12); \
    __m256d VNAME##4 = _mm256_load_pd(SRC+16); \
    __m256d VNAME##5 = _mm256_load_pd(SRC+20);

#define SET4(DST, A, B, C, D) \
    *(DST+0) = A; \
    *(DST+1) = B; \
    *(DST+2) = C; \
    *(DST+3) = D;

const double c2p22      = 4194304.0;              // 2^22
const double c2p43      = 8796093022208.0;        // 2^43
const double c2p64      = 1.8446744073709552e+19; // 2^64
const double c2p85      = 3.8685626227668134e+25; // 2^85
const double c2p107     = 1.6225927682921336e+32; // 2^107
const double c2p128     = 3.402823669209385e+38;  // 2^128
const double c2p149     = 7.1362384635298e+44;    // 2^149
const double c2p170     = 1.4965776766268446e+51; // 2^170
const double c2p192     = 6.277101735386681e+57;  // 2^192
const double c2p213     = 1.3164036458569648e+64; // 2^213
const double c2p234     = 2.7606985387162255e+70; // 2^234
const double top_22_53  = 2.833419889721787e+22;  // 3*2^(22+53-2)
const double top_43_53  = 5.942112188569825e+28;  // 3*2^(43+53-2)
const double top_64_53  = 1.2461512460483586e+35; // 3*2^(64+53-2)
const double top_85_53  = 2.6133685779528074e+41; // 3*2^(85+53-2)
const double top_107_53 = 1.0961262279981772e+48; // 3*2^(107+53-2)
const double top_128_53 = 2.2987433112988333e+54; // 3*2^(128+53-2)
const double top_149_53 = 4.820814132776971e+60;  // 3*2^(149+53-2)
const double top_170_53 = 1.010998000018149e+67;  // 3*2^(170+53-2)
const double top_192_53 = 4.2404329554681224e+73; // 3*2^(192+53-2)
const double top_213_53 = 8.892832453425884e+79;  // 3*2^(213+53-2)
const double top_234_53 = 1.8649621365367e+86;    // 3*2^(234+53-2)
const double top_255_53 = 3.911109074562213e+92;  // 3*2^(255+53-2)
const double c19        = 3.281744050935889e-76;  // 19*2^(-255)
const double c38        = 6.563488101871778e-76;  // 38*2^(-255)

typedef double vec4[4] __attribute__((aligned(32)));
vec4 g_x1_col0_0, g_x1_col0_4, g_x1_col0_8;
vec4 g_x1_col1_0, g_x1_col1_4, g_x1_col1_8;
vec4 g_x1_col2_0, g_x1_col2_4, g_x1_col2_8;
vec4 g_x1_col3_0, g_x1_col3_4, g_x1_col3_8;
vec4 g_x1_col4_0;
vec4 g_x1_col5_0;
vec4 g_x1_col6_0;
vec4 g_x1_col7_0;
vec4 g_x1_col8_0;
vec4 g_x1_col9_0;
vec4 g_x1_col10_0;
vec4 g_x1_col11_0;

force_inline
void init_glob_const_x1(field_t x) {
    __m256d c19_v = _mm256_set1_pd(c19);

    __m256d x0 = _mm256_load_pd(x+0); _mm256_store_pd(g_x1_col0_0, x0);
    __m256d x4 = _mm256_load_pd(x+4); _mm256_store_pd(g_x1_col0_4, x4);
    __m256d x8 = _mm256_load_pd(x+8); _mm256_store_pd(g_x1_col0_8, x8);

    SET4(g_x1_col1_0, c19*x[11], x[0], x[1], x[2]);
    __m256d x3 = _mm256_loadu_pd(x+3); _mm256_store_pd(g_x1_col1_4, x3);
    __m256d x7 = _mm256_loadu_pd(x+7); _mm256_store_pd(g_x1_col1_8, x7);

    SET4(g_x1_col2_0, c19*x[10], c19*x[11], x[0], x[1]);
    __m256d x2 = _mm256_loadu_pd(x+2); _mm256_store_pd(g_x1_col2_4, x2);
    __m256d x6 = _mm256_loadu_pd(x+6); _mm256_store_pd(g_x1_col2_8, x6);

    SET4(g_x1_col3_0, c19*x[9], c19*x[10], c19*x[11], x[0]);
    __m256d x1 = _mm256_loadu_pd(x+1); _mm256_store_pd(g_x1_col3_4, x1);
    __m256d x5 = _mm256_loadu_pd(x+5); _mm256_store_pd(g_x1_col3_8, x5);

    _mm256_store_pd(g_x1_col4_0, _mm256_mul_pd(x8, c19_v));
    _mm256_store_pd(g_x1_col5_0, _mm256_mul_pd(x7, c19_v));
    _mm256_store_pd(g_x1_col6_0, _mm256_mul_pd(x6, c19_v));
    _mm256_store_pd(g_x1_col7_0, _mm256_mul_pd(x5, c19_v));
    _mm256_store_pd(g_x1_col8_0, _mm256_mul_pd(x4, c19_v));
    _mm256_store_pd(g_x1_col9_0, _mm256_mul_pd(x3, c19_v));
    _mm256_store_pd(g_x1_col10_0, _mm256_mul_pd(x2, c19_v));
    _mm256_store_pd(g_x1_col11_0, _mm256_mul_pd(x1, c19_v));
}

// carry two interleaved field element tuples at the same time
force_inline
void field_double_packed_carry(field_twopack_t ac, field_twopack_t bd) {
    __m256d top_22_53_v  = _mm256_set1_pd(top_22_53);
    __m256d top_43_53_v  = _mm256_set1_pd(top_43_53);
    __m256d top_64_53_v  = _mm256_set1_pd(top_64_53);
    __m256d top_85_53_v  = _mm256_set1_pd(top_85_53);
    __m256d top_107_53_v = _mm256_set1_pd(top_107_53);
    __m256d top_128_53_v = _mm256_set1_pd(top_128_53);
    __m256d top_149_53_v = _mm256_set1_pd(top_149_53);
    __m256d top_170_53_v = _mm256_set1_pd(top_170_53);
    __m256d top_192_53_v = _mm256_set1_pd(top_192_53);
    __m256d top_213_53_v = _mm256_set1_pd(top_213_53);
    __m256d top_234_53_v = _mm256_set1_pd(top_234_53);
    __m256d top_255_53_v = _mm256_set1_pd(top_255_53);

    __m256d c19_v = _mm256_set1_pd(c19);

    __m256d ac0 = _mm256_load_pd(ac+0);
    __m256d ac1 = _mm256_load_pd(ac+4);
    __m256d ac2 = _mm256_load_pd(ac+8);
    __m256d ac3 = _mm256_load_pd(ac+12);
    __m256d ac4 = _mm256_load_pd(ac+16);
    __m256d ac5 = _mm256_load_pd(ac+20);

    __m256d bd0 = _mm256_load_pd(bd+0);
    __m256d bd1 = _mm256_load_pd(bd+4);
    __m256d bd2 = _mm256_load_pd(bd+8);
    __m256d bd3 = _mm256_load_pd(bd+12);
    __m256d bd4 = _mm256_load_pd(bd+16);
    __m256d bd5 = _mm256_load_pd(bd+20);

    __m256d p0  = _mm256_shuffle_pd(ac0, bd0, 0x0);
    __m256d p1  = _mm256_shuffle_pd(ac0, bd0, 0xf); // 0xf = 0b1111
    __m256d p2  = _mm256_shuffle_pd(ac1, bd1, 0x0);
    __m256d p3  = _mm256_shuffle_pd(ac1, bd1, 0xf);
    __m256d p4  = _mm256_shuffle_pd(ac2, bd2, 0x0);
    __m256d p5  = _mm256_shuffle_pd(ac2, bd2, 0xf);
    __m256d p6  = _mm256_shuffle_pd(ac3, bd3, 0x0);
    __m256d p7  = _mm256_shuffle_pd(ac3, bd3, 0xf);
    __m256d p8  = _mm256_shuffle_pd(ac4, bd4, 0x0);
    __m256d p9  = _mm256_shuffle_pd(ac4, bd4, 0xf);
    __m256d p10 = _mm256_shuffle_pd(ac5, bd5, 0x0);
    __m256d p11 = _mm256_shuffle_pd(ac5, bd5, 0xf);

    __m256d carry0, carry1, carry2, carry3, carry4, carry5,
            carry6, carry7, carry8, carry9, carry10, carry11;

    carry0 = _mm256_sub_pd(_mm256_add_pd(p0, top_22_53_v), top_22_53_v);
    carry3 = _mm256_sub_pd(_mm256_add_pd(p3, top_85_53_v), top_85_53_v);
    carry6 = _mm256_sub_pd(_mm256_add_pd(p6, top_149_53_v), top_149_53_v);
    carry9  = _mm256_sub_pd(_mm256_add_pd(p9, top_213_53_v), top_213_53_v);
    p0 = _mm256_sub_pd(p0, carry0);
    p1 = _mm256_add_pd(p1, carry0);
    p3 = _mm256_sub_pd(p3, carry3);
    p4 = _mm256_add_pd(p4, carry3);
    p6 = _mm256_sub_pd(p6, carry6);
    p7 = _mm256_add_pd(p7, carry6);
    p9 = _mm256_sub_pd(p9, carry9);
    p10 =_mm256_add_pd(p10, carry9);

    carry1 = _mm256_sub_pd(_mm256_add_pd(p1, top_43_53_v), top_43_53_v);
    carry4 = _mm256_sub_pd(_mm256_add_pd(p4, top_107_53_v), top_107_53_v);
    carry7 = _mm256_sub_pd(_mm256_add_pd(p7, top_170_53_v), top_170_53_v);
    carry10 = _mm256_sub_pd(_mm256_add_pd(p10, top_234_53_v), top_234_53_v);
    p1 = _mm256_sub_pd(p1, carry1);
    p2 = _mm256_add_pd(p2, carry1);
    p4 = _mm256_sub_pd(p4, carry4);
    p5 = _mm256_add_pd(p5, carry4);
    p7 = _mm256_sub_pd(p7, carry7);
    p8 = _mm256_add_pd(p8, carry7);
    p10 = _mm256_sub_pd(p10, carry10);
    p11 = _mm256_add_pd(p11, carry10);

    carry2 = _mm256_sub_pd(_mm256_add_pd(p2, top_64_53_v), top_64_53_v);
    carry5 = _mm256_sub_pd(_mm256_add_pd(p5, top_128_53_v), top_128_53_v);
    carry8 = _mm256_sub_pd(_mm256_add_pd(p8, top_192_53_v), top_192_53_v);
    carry11 = _mm256_sub_pd(_mm256_add_pd(p11, top_255_53_v), top_255_53_v);
    p2 = _mm256_sub_pd(p2, carry2);
    p3 = _mm256_add_pd(p3, carry2);
    p5 = _mm256_sub_pd(p5, carry5);
    p6 = _mm256_add_pd(p6, carry5);
    p8 = _mm256_sub_pd(p8, carry8);
    p9 = _mm256_add_pd(p9, carry8);
    p11 = _mm256_sub_pd(p11, carry11);
    p0 = _mm256_fmadd_pd(c19_v, carry11, p0);

    carry0 = _mm256_sub_pd(_mm256_add_pd(p0, top_22_53_v), top_22_53_v);
    carry3 = _mm256_sub_pd(_mm256_add_pd(p3, top_85_53_v), top_85_53_v);
    carry6 = _mm256_sub_pd(_mm256_add_pd(p6, top_149_53_v), top_149_53_v);
    carry9  = _mm256_sub_pd(_mm256_add_pd(p9, top_213_53_v), top_213_53_v);
    p0 = _mm256_sub_pd(p0, carry0);
    p1 = _mm256_add_pd(p1, carry0);
    p3 = _mm256_sub_pd(p3, carry3);
    p4 = _mm256_add_pd(p4, carry3);
    p6 = _mm256_sub_pd(p6, carry6);
    p7 = _mm256_add_pd(p7, carry6);
    p9 = _mm256_sub_pd(p9, carry9);
    p10 =_mm256_add_pd(p10, carry9);

    __m256d ac_z0 = _mm256_shuffle_pd(p0, p1, 0x0);
    __m256d ac_z1 = _mm256_shuffle_pd(p2, p3, 0x0);
    __m256d ac_z2 = _mm256_shuffle_pd(p4, p5, 0x0);
    __m256d ac_z3 = _mm256_shuffle_pd(p6, p7, 0x0);
    __m256d ac_z4 = _mm256_shuffle_pd(p8, p9, 0x0);
    __m256d ac_z5 = _mm256_shuffle_pd(p10, p11, 0x0);

    __m256d bd_z0 = _mm256_shuffle_pd(p0, p1, 0xf);
    __m256d bd_z1 = _mm256_shuffle_pd(p2, p3, 0xf);
    __m256d bd_z2 = _mm256_shuffle_pd(p4, p5, 0xf);
    __m256d bd_z3 = _mm256_shuffle_pd(p6, p7, 0xf);
    __m256d bd_z4 = _mm256_shuffle_pd(p8, p9, 0xf);
    __m256d bd_z5 = _mm256_shuffle_pd(p10, p11, 0xf);

    _mm256_store_pd(ac+0, ac_z0);
    _mm256_store_pd(ac+4, ac_z1);
    _mm256_store_pd(ac+8, ac_z2);
    _mm256_store_pd(ac+12, ac_z3);
    _mm256_store_pd(ac+16, ac_z4);
    _mm256_store_pd(ac+20, ac_z5);

    _mm256_store_pd(bd+0, bd_z0);
    _mm256_store_pd(bd+4, bd_z1);
    _mm256_store_pd(bd+8, bd_z2);
    _mm256_store_pd(bd+12, bd_z3);
    _mm256_store_pd(bd+16, bd_z4);
    _mm256_store_pd(bd+20, bd_z5);
}

// <A,C>, <B,D> -> <A*B,C*D> = z
force_inline
void field_packed_mul(field_twopack_t dst, field_twopack_t ac, field_twopack_t bd) {
    __m256d z0 = _mm256_setzero_pd();
    __m256d z1 = _mm256_setzero_pd();
    __m256d z2 = _mm256_setzero_pd();
    __m256d z3 = _mm256_setzero_pd();
    __m256d z4 = _mm256_setzero_pd();
    __m256d z5 = _mm256_setzero_pd();

    __m256d ac0 = _mm256_load_pd(ac+0);
    __m256d ac1 = _mm256_load_pd(ac+4);
    __m256d ac2 = _mm256_load_pd(ac+8);
    __m256d ac3 = _mm256_load_pd(ac+12);
    __m256d ac4 = _mm256_load_pd(ac+16);
    __m256d ac5 = _mm256_load_pd(ac+20);

    // even columns
    __m256d bd0 = _mm256_load_pd(bd+0);
    __m256d bd1 = _mm256_load_pd(bd+4);
    __m256d bd2 = _mm256_load_pd(bd+8);
    __m256d bd3 = _mm256_load_pd(bd+12);
    __m256d bd4 = _mm256_load_pd(bd+16);
    __m256d bd5 = _mm256_load_pd(bd+20);

    __m256d c19_v = _mm256_set1_pd(c19);
    __m256d bd1_19 = _mm256_mul_pd(bd1, c19_v);
    __m256d bd2_19 = _mm256_mul_pd(bd2, c19_v);
    __m256d bd3_19 = _mm256_mul_pd(bd3, c19_v);
    __m256d bd4_19 = _mm256_mul_pd(bd4, c19_v);
    __m256d bd5_19 = _mm256_mul_pd(bd5, c19_v);

    __m256d a_0_0_c_0_0 = _mm256_shuffle_pd(ac0, ac0, 0x0);
    z0 = _mm256_fmadd_pd(a_0_0_c_0_0, bd0, z0);
    z1 = _mm256_fmadd_pd(a_0_0_c_0_0, bd1, z1);
    z2 = _mm256_fmadd_pd(a_0_0_c_0_0, bd2, z2);
    z3 = _mm256_fmadd_pd(a_0_0_c_0_0, bd3, z3);
    z4 = _mm256_fmadd_pd(a_0_0_c_0_0, bd4, z4);
    z5 = _mm256_fmadd_pd(a_0_0_c_0_0, bd5, z5);
    __m256d a_2_2_c_2_2 = _mm256_shuffle_pd(ac1, ac1, 0x0);
    z0 = _mm256_fmadd_pd(a_2_2_c_2_2, bd5_19, z0);
    z1 = _mm256_fmadd_pd(a_2_2_c_2_2, bd0, z1);
    z2 = _mm256_fmadd_pd(a_2_2_c_2_2, bd1, z2);
    z3 = _mm256_fmadd_pd(a_2_2_c_2_2, bd2, z3);
    z4 = _mm256_fmadd_pd(a_2_2_c_2_2, bd3, z4);
    z5 = _mm256_fmadd_pd(a_2_2_c_2_2, bd4, z5);
    __m256d a_4_4_c_4_4 = _mm256_shuffle_pd(ac2, ac2, 0x0);
    z0 = _mm256_fmadd_pd(a_4_4_c_4_4, bd4_19, z0);
    z1 = _mm256_fmadd_pd(a_4_4_c_4_4, bd5_19, z1);
    z2 = _mm256_fmadd_pd(a_4_4_c_4_4, bd0, z2);
    z3 = _mm256_fmadd_pd(a_4_4_c_4_4, bd1, z3);
    z4 = _mm256_fmadd_pd(a_4_4_c_4_4, bd2, z4);
    z5 = _mm256_fmadd_pd(a_4_4_c_4_4, bd3, z5);
    __m256d a_6_6_c_6_6 = _mm256_shuffle_pd(ac3, ac3, 0x0);
    z0 = _mm256_fmadd_pd(a_6_6_c_6_6, bd3_19, z0);
    z1 = _mm256_fmadd_pd(a_6_6_c_6_6, bd4_19, z1);
    z2 = _mm256_fmadd_pd(a_6_6_c_6_6, bd5_19, z2);
    z3 = _mm256_fmadd_pd(a_6_6_c_6_6, bd0, z3);
    z4 = _mm256_fmadd_pd(a_6_6_c_6_6, bd1, z4);
    z5 = _mm256_fmadd_pd(a_6_6_c_6_6, bd2, z5);
    __m256d a_8_8_c_8_8 = _mm256_shuffle_pd(ac4, ac4, 0x0);
    z0 = _mm256_fmadd_pd(a_8_8_c_8_8, bd2_19, z0);
    z1 = _mm256_fmadd_pd(a_8_8_c_8_8, bd3_19, z1);
    z2 = _mm256_fmadd_pd(a_8_8_c_8_8, bd4_19, z2);
    z3 = _mm256_fmadd_pd(a_8_8_c_8_8, bd5_19, z3);
    z4 = _mm256_fmadd_pd(a_8_8_c_8_8, bd0, z4);
    z5 = _mm256_fmadd_pd(a_8_8_c_8_8, bd1, z5);
    __m256d a_10_10_c_10_10 = _mm256_shuffle_pd(ac5, ac5, 0x0);
    z0 = _mm256_fmadd_pd(a_10_10_c_10_10, bd1_19, z0);
    z1 = _mm256_fmadd_pd(a_10_10_c_10_10, bd2_19, z1);
    z2 = _mm256_fmadd_pd(a_10_10_c_10_10, bd3_19, z2);
    z3 = _mm256_fmadd_pd(a_10_10_c_10_10, bd4_19, z3);
    z4 = _mm256_fmadd_pd(a_10_10_c_10_10, bd5_19, z4);
    z5 = _mm256_fmadd_pd(a_10_10_c_10_10, bd0, z5);

    // odd columns
    __m256d b_1_2_d_1_2 = _mm256_shuffle_pd(bd0, bd1, 0x5); // 0x5 = 0b0101
    __m256d b_3_4_d_3_4 = _mm256_shuffle_pd(bd1, bd2, 0x5);
    __m256d b_5_6_d_5_6 = _mm256_shuffle_pd(bd2, bd3, 0x5);
    __m256d b_7_8_d_7_8 = _mm256_shuffle_pd(bd3, bd4, 0x5);
    __m256d b_9_10_d_9_10 = _mm256_shuffle_pd(bd4, bd5, 0x5);

    __m256d bd0_19 = _mm256_mul_pd(bd0, c19_v);
    __m256d b_1_2_d_1_2__19 = _mm256_shuffle_pd(bd0_19, bd1_19, 0x5);
    __m256d b_3_4_d_3_4__19 = _mm256_shuffle_pd(bd1_19, bd2_19, 0x5);
    __m256d b_5_6_d_5_6__19 = _mm256_shuffle_pd(bd2_19, bd3_19, 0x5);
    __m256d b_7_8_d_7_8__19 = _mm256_shuffle_pd(bd3_19, bd4_19, 0x5);
    __m256d b_9_10_d_9_10__19 = _mm256_shuffle_pd(bd4_19, bd5_19, 0x5);
    __m256d b_11_0_d_11_0__19 = _mm256_shuffle_pd(bd5_19, bd0, 0x5);

    __m256d a_1_1_c_1_1 = _mm256_shuffle_pd(ac0, ac0, 0xf); // 0xf = 0b1111
    z0 = _mm256_fmadd_pd(a_1_1_c_1_1, b_11_0_d_11_0__19, z0);
    z1 = _mm256_fmadd_pd(a_1_1_c_1_1, b_1_2_d_1_2, z1);
    z2 = _mm256_fmadd_pd(a_1_1_c_1_1, b_3_4_d_3_4, z2);
    z3 = _mm256_fmadd_pd(a_1_1_c_1_1, b_5_6_d_5_6, z3);
    z4 = _mm256_fmadd_pd(a_1_1_c_1_1, b_7_8_d_7_8, z4);
    z5 = _mm256_fmadd_pd(a_1_1_c_1_1, b_9_10_d_9_10, z5);
    __m256d a_3_3_c_3_3 = _mm256_shuffle_pd(ac1, ac1, 0xf);
    z0 = _mm256_fmadd_pd(a_3_3_c_3_3, b_9_10_d_9_10__19, z0);
    z1 = _mm256_fmadd_pd(a_3_3_c_3_3, b_11_0_d_11_0__19, z1);
    z2 = _mm256_fmadd_pd(a_3_3_c_3_3, b_1_2_d_1_2, z2);
    z3 = _mm256_fmadd_pd(a_3_3_c_3_3, b_3_4_d_3_4, z3);
    z4 = _mm256_fmadd_pd(a_3_3_c_3_3, b_5_6_d_5_6, z4);
    z5 = _mm256_fmadd_pd(a_3_3_c_3_3, b_7_8_d_7_8, z5);
    __m256d a_5_5_c_5_5 = _mm256_shuffle_pd(ac2, ac2, 0xf);
    z0 = _mm256_fmadd_pd(a_5_5_c_5_5, b_7_8_d_7_8__19, z0);
    z1 = _mm256_fmadd_pd(a_5_5_c_5_5, b_9_10_d_9_10__19, z1);
    z2 = _mm256_fmadd_pd(a_5_5_c_5_5, b_11_0_d_11_0__19, z2);
    z3 = _mm256_fmadd_pd(a_5_5_c_5_5, b_1_2_d_1_2, z3);
    z4 = _mm256_fmadd_pd(a_5_5_c_5_5, b_3_4_d_3_4, z4);
    z5 = _mm256_fmadd_pd(a_5_5_c_5_5, b_5_6_d_5_6, z5);
    __m256d a_7_7_c_7_7 = _mm256_shuffle_pd(ac3, ac3, 0xf);
    z0 = _mm256_fmadd_pd(a_7_7_c_7_7, b_5_6_d_5_6__19, z0);
    z1 = _mm256_fmadd_pd(a_7_7_c_7_7, b_7_8_d_7_8__19, z1);
    z2 = _mm256_fmadd_pd(a_7_7_c_7_7, b_9_10_d_9_10__19, z2);
    z3 = _mm256_fmadd_pd(a_7_7_c_7_7, b_11_0_d_11_0__19, z3);
    z4 = _mm256_fmadd_pd(a_7_7_c_7_7, b_1_2_d_1_2, z4);
    z5 = _mm256_fmadd_pd(a_7_7_c_7_7, b_3_4_d_3_4, z5);
    __m256d a_9_9_c_9_9 = _mm256_shuffle_pd(ac4, ac4, 0xf);
    z0 = _mm256_fmadd_pd(a_9_9_c_9_9, b_3_4_d_3_4__19, z0);
    z1 = _mm256_fmadd_pd(a_9_9_c_9_9, b_5_6_d_5_6__19, z1);
    z2 = _mm256_fmadd_pd(a_9_9_c_9_9, b_7_8_d_7_8__19, z2);
    z3 = _mm256_fmadd_pd(a_9_9_c_9_9, b_9_10_d_9_10__19, z3);
    z4 = _mm256_fmadd_pd(a_9_9_c_9_9, b_11_0_d_11_0__19, z4);
    z5 = _mm256_fmadd_pd(a_9_9_c_9_9, b_1_2_d_1_2, z5);
    __m256d a_11_11_c_11_11 = _mm256_shuffle_pd(ac5, ac5, 0xf);
    z0 = _mm256_fmadd_pd(a_11_11_c_11_11, b_1_2_d_1_2__19, z0);
    z1 = _mm256_fmadd_pd(a_11_11_c_11_11, b_3_4_d_3_4__19, z1);
    z2 = _mm256_fmadd_pd(a_11_11_c_11_11, b_5_6_d_5_6__19, z2);
    z3 = _mm256_fmadd_pd(a_11_11_c_11_11, b_7_8_d_7_8__19, z3);
    z4 = _mm256_fmadd_pd(a_11_11_c_11_11, b_9_10_d_9_10__19, z4);
    z5 = _mm256_fmadd_pd(a_11_11_c_11_11, b_11_0_d_11_0__19, z5);

    _mm256_store_pd(dst+0, z0);
    _mm256_store_pd(dst+4, z1);
    _mm256_store_pd(dst+8, z2);
    _mm256_store_pd(dst+12, z3);
    _mm256_store_pd(dst+16, z4);
    _mm256_store_pd(dst+20, z5);
}

force_inline
void field_packed_square(field_twopack_t dst, field_twopack_t ab) {
    __m256d z0 = _mm256_setzero_pd();
    __m256d z1 = _mm256_setzero_pd();
    __m256d z2 = _mm256_setzero_pd();
    __m256d z3 = _mm256_setzero_pd();
    __m256d z4 = _mm256_setzero_pd();
    __m256d z5 = _mm256_setzero_pd();

    __m256d ab0 = _mm256_load_pd(ab+0); // (a0, a1, b0, b1)
    __m256d ab1 = _mm256_load_pd(ab+4);
    __m256d ab2 = _mm256_load_pd(ab+8);
    __m256d ab3 = _mm256_load_pd(ab+12);
    __m256d ab4 = _mm256_load_pd(ab+16);
    __m256d ab5 = _mm256_load_pd(ab+20);

    __m256d v2 = _mm256_set1_pd(2.0);
    __m256d ab0_2 = _mm256_mul_pd(ab0, v2); // (2*a0, 2*a1, 2*b0, 2*b1)
    __m256d ab1_2 = _mm256_mul_pd(ab1, v2);
    __m256d ab2_2 = _mm256_mul_pd(ab2, v2);
    __m256d ab3_2 = _mm256_mul_pd(ab3, v2);
    __m256d ab4_2 = _mm256_mul_pd(ab4, v2);
    __m256d ab5_2 = _mm256_mul_pd(ab5, v2);

    __m256d zero_v = _mm256_setzero_pd();

    __m256d ab0_1_2 = _mm256_blend_pd(ab0, ab0_2, 0xa); // (a0, 2*a1, b0, 2*b1), 0xa = 0b1010
    __m256d ab1_1_2 = _mm256_blend_pd(ab1, ab1_2, 0xa);
    __m256d ab2_1_2 = _mm256_blend_pd(ab2, ab2_2, 0xa);
    __m256d ab_6_X_b_6_X = _mm256_blend_pd(ab3, zero_v, 0xa); // (a6, 0, b6, 0), 0xa = 0b1010
    __m256d a_8_X_b_8_X = _mm256_blend_pd(ab4, zero_v, 0xa);
    __m256d a_10_X_b_10_X = _mm256_blend_pd(ab5, zero_v, 0xa);

    __m256d c19_v = _mm256_set1_pd(c19);

    // even columns
    __m256d a_0_0_b_0_0 = _mm256_shuffle_pd(ab0, ab0, 0x0);
    z0 = _mm256_fmadd_pd(a_0_0_b_0_0, ab0_1_2, z0);
    z1 = _mm256_fmadd_pd(a_0_0_b_0_0, ab1_2, z1);
    z2 = _mm256_fmadd_pd(a_0_0_b_0_0, ab2_2, z2);
    z3 = _mm256_fmadd_pd(a_0_0_b_0_0, ab3_2, z3);
    z4 = _mm256_fmadd_pd(a_0_0_b_0_0, ab4_2, z4);
    z5 = _mm256_fmadd_pd(a_0_0_b_0_0, ab5_2, z5);
    __m256d a_2_2_b_2_2 = _mm256_shuffle_pd(ab1, ab1, 0x0);
    z2 = _mm256_fmadd_pd(a_2_2_b_2_2, ab1_1_2, z2);
    z3 = _mm256_fmadd_pd(a_2_2_b_2_2, ab2_2, z3);
    z4 = _mm256_fmadd_pd(a_2_2_b_2_2, ab3_2, z4);
    z5 = _mm256_fmadd_pd(a_2_2_b_2_2, ab4_2, z5);
    __m256d a_4_4_b_4_4 = _mm256_shuffle_pd(ab2, ab2, 0x0);
    z4 = _mm256_fmadd_pd(a_4_4_b_4_4, ab2_1_2, z4);
    z5 = _mm256_fmadd_pd(a_4_4_b_4_4, ab3_2, z5);
    __m256d a_6_6_b_6_6 = _mm256_mul_pd(_mm256_shuffle_pd(ab3, ab3, 0x0), c19_v);
    z0 = _mm256_fmadd_pd(a_6_6_b_6_6, ab_6_X_b_6_X, z0);
    __m256d a_8_8_b_8_8 = _mm256_mul_pd(_mm256_shuffle_pd(ab4, ab4, 0x0), c19_v);
    z0 = _mm256_fmadd_pd(a_8_8_b_8_8, ab2_2, z0);
    z1 = _mm256_fmadd_pd(a_8_8_b_8_8, ab3_2, z1);
    z2 = _mm256_fmadd_pd(a_8_8_b_8_8, a_8_X_b_8_X, z2);
    __m256d a_10_10_b_10_10 = _mm256_mul_pd(_mm256_shuffle_pd(ab5, ab5, 0x0), c19_v);
    z0 = _mm256_fmadd_pd(a_10_10_b_10_10, ab1_2, z0);
    z1 = _mm256_fmadd_pd(a_10_10_b_10_10, ab2_2, z1);
    z2 = _mm256_fmadd_pd(a_10_10_b_10_10, ab3_2, z2);
    z3 = _mm256_fmadd_pd(a_10_10_b_10_10, ab4_2, z3);
    z4  = _mm256_fmadd_pd(a_10_10_b_10_10, a_10_X_b_10_X, z4);

    // odd columns
    __m256d a_1_2_b_1_2__1_2 = _mm256_shuffle_pd(ab0, ab1_2, 0x5); // 0x5 = 0b0101
    __m256d a_3_4_b_3_4__1_2 = _mm256_shuffle_pd(ab1, ab2_2, 0x5);
    __m256d a_5_6_b_5_6__1_2 = _mm256_shuffle_pd(ab2, ab3_2, 0x5);

    __m256d a_7_X_b_7_X = _mm256_shuffle_pd(ab3, zero_v, 0x5);
    __m256d a_9_X_b_9_X = _mm256_shuffle_pd(ab4, zero_v, 0x5);
    __m256d a_11_X_b_11_X = _mm256_shuffle_pd(ab5, zero_v, 0x5);

    __m256d a_1_2_b_1_2__2 = _mm256_shuffle_pd(ab0_2, ab1_2, 0x5);
    __m256d a_3_4_b_3_4__2 = _mm256_shuffle_pd(ab1_2, ab2_2, 0x5);
    __m256d a_5_6_b_5_6__2 = _mm256_shuffle_pd(ab2_2, ab3_2, 0x5);
    __m256d a_7_8_b_7_8__2 = _mm256_shuffle_pd(ab3_2, ab4_2, 0x5);
    __m256d a_9_10_b_9_10__2 = _mm256_shuffle_pd(ab4_2, ab5_2, 0x5);

    __m256d a_1_1_b_1_1 = _mm256_shuffle_pd(ab0, ab0, 0xf); // 0xf = 0b1111
    z1 = _mm256_fmadd_pd(a_1_1_b_1_1, a_1_2_b_1_2__1_2, z1);
    z2 = _mm256_fmadd_pd(a_1_1_b_1_1, a_3_4_b_3_4__2, z2);
    z3 = _mm256_fmadd_pd(a_1_1_b_1_1, a_5_6_b_5_6__2, z3);
    z4 = _mm256_fmadd_pd(a_1_1_b_1_1, a_7_8_b_7_8__2, z4);
    z5 = _mm256_fmadd_pd(a_1_1_b_1_1, a_9_10_b_9_10__2, z5);
    __m256d a_3_3_b_3_3 = _mm256_shuffle_pd(ab1, ab1, 0xf);
    z3 = _mm256_fmadd_pd(a_3_3_b_3_3, a_3_4_b_3_4__1_2, z3);
    z4 = _mm256_fmadd_pd(a_3_3_b_3_3, a_5_6_b_5_6__2, z4);
    z5 = _mm256_fmadd_pd(a_3_3_b_3_3, a_7_8_b_7_8__2, z5);
    __m256d a_5_5_b_5_5 = _mm256_shuffle_pd(ab2, ab2, 0xf);
    z5 = _mm256_fmadd_pd(a_5_5_b_5_5, a_5_6_b_5_6__1_2, z5);
    __m256d a_7_7_b_7_7 = _mm256_mul_pd(_mm256_shuffle_pd(ab3, ab3, 0xf), c19_v);
    z0 = _mm256_fmadd_pd(a_7_7_b_7_7, a_5_6_b_5_6__2, z0);
    z1 = _mm256_fmadd_pd(a_7_7_b_7_7, a_7_X_b_7_X, z1);
    __m256d a_9_9_b_9_9 = _mm256_mul_pd(_mm256_shuffle_pd(ab4, ab4, 0xf), c19_v);
    z0 = _mm256_fmadd_pd(a_9_9_b_9_9, a_3_4_b_3_4__2, z0);
    z1 = _mm256_fmadd_pd(a_9_9_b_9_9, a_5_6_b_5_6__2, z1);
    z2 = _mm256_fmadd_pd(a_9_9_b_9_9, a_7_8_b_7_8__2, z2);
    z3 = _mm256_fmadd_pd(a_9_9_b_9_9, a_9_X_b_9_X, z3);
    __m256d a_11_11_b_11_11 = _mm256_mul_pd(_mm256_shuffle_pd(ab5, ab5, 0xf), c19_v);
    z0 = _mm256_fmadd_pd(a_11_11_b_11_11, a_1_2_b_1_2__2, z0);
    z1 = _mm256_fmadd_pd(a_11_11_b_11_11, a_3_4_b_3_4__2, z1);
    z2 = _mm256_fmadd_pd(a_11_11_b_11_11, a_5_6_b_5_6__2, z2);
    z3 = _mm256_fmadd_pd(a_11_11_b_11_11, a_7_8_b_7_8__2, z3);
    z4 = _mm256_fmadd_pd(a_11_11_b_11_11, a_9_10_b_9_10__2, z4);
    z5 = _mm256_fmadd_pd(a_11_11_b_11_11, a_11_X_b_11_X, z5);

    _mm256_store_pd(dst+0, z0);
    _mm256_store_pd(dst+4, z1);
    _mm256_store_pd(dst+8, z2);
    _mm256_store_pd(dst+12, z3);
    _mm256_store_pd(dst+16, z4);
    _mm256_store_pd(dst+20, z5);
}

force_inline
void field_mul_x1_upper(field_twopack_t dst, field_twopack_t a) {
    // reduce dependencies by using two sets of accumulators
    __m256d b0_0 = _mm256_setzero_pd();
    __m256d b1_0 = _mm256_setzero_pd();
    __m256d b2_0 = _mm256_setzero_pd();
    __m256d b0_1 = _mm256_setzero_pd();
    __m256d b1_1 = _mm256_setzero_pd();
    __m256d b2_1 = _mm256_setzero_pd();

    // even columns
    __m256d col0_0 = _mm256_load_pd(g_x1_col0_0);
    __m256d col0_1 = _mm256_load_pd(g_x1_col0_4);
    __m256d col0_2 = _mm256_load_pd(g_x1_col0_8);
    __m256d a0 = _mm256_broadcast_sd(a+2);
    b0_0 = _mm256_fmadd_pd(a0, col0_0, b0_0);
    b1_0 = _mm256_fmadd_pd(a0, col0_1, b1_0);
    b2_0 = _mm256_fmadd_pd(a0, col0_2, b2_0);

    __m256d col2_0 = _mm256_load_pd(g_x1_col2_0);
    __m256d col2_1 = _mm256_load_pd(g_x1_col2_4);
    __m256d col2_2 = _mm256_load_pd(g_x1_col2_8);
    __m256d a2 = _mm256_broadcast_sd(a+6);
    b0_1 = _mm256_fmadd_pd(a2, col2_0, b0_1);
    b1_1 = _mm256_fmadd_pd(a2, col2_1, b1_1);
    b2_1 = _mm256_fmadd_pd(a2, col2_2, b2_1);

    __m256d col4_0 = _mm256_load_pd(g_x1_col4_0);
    __m256d a4 = _mm256_broadcast_sd(a+10);
    b0_0 = _mm256_fmadd_pd(a4, col4_0, b0_0);
    b1_0 = _mm256_fmadd_pd(a4, col0_0, b1_0);
    b2_0 = _mm256_fmadd_pd(a4, col0_1, b2_0);

    __m256d col6_0 = _mm256_load_pd(g_x1_col6_0);
    __m256d a6 = _mm256_broadcast_sd(a+14);
    b0_1 = _mm256_fmadd_pd(a6, col6_0, b0_1);
    b1_1 = _mm256_fmadd_pd(a6, col2_0, b1_1);
    b2_1 = _mm256_fmadd_pd(a6, col2_1, b2_1);

    __m256d col8_0 = _mm256_load_pd(g_x1_col8_0);
    __m256d a8 = _mm256_broadcast_sd(a+18);
    b0_0 = _mm256_fmadd_pd(a8, col8_0, b0_0);
    b1_0 = _mm256_fmadd_pd(a8, col4_0, b1_0);
    b2_0 = _mm256_fmadd_pd(a8, col0_0, b2_0);

    __m256d col10_0 = _mm256_load_pd(g_x1_col10_0);
    __m256d a10 = _mm256_broadcast_sd(a+22);
    b0_1 = _mm256_fmadd_pd(a10, col10_0, b0_1);
    b1_1 = _mm256_fmadd_pd(a10, col6_0, b1_1);
    b2_1 = _mm256_fmadd_pd(a10, col2_0, b2_1);

    // odd columns
    __m256d col1_0 = _mm256_load_pd(g_x1_col1_0);
    __m256d col1_1 = _mm256_load_pd(g_x1_col1_4);
    __m256d col1_2 = _mm256_load_pd(g_x1_col1_8);
    __m256d a1 = _mm256_broadcast_sd(a+3);
    b0_0 = _mm256_fmadd_pd(a1, col1_0, b0_0);
    b1_0 = _mm256_fmadd_pd(a1, col1_1, b1_0);
    b2_0 = _mm256_fmadd_pd(a1, col1_2, b2_0);

    __m256d col3_0 = _mm256_load_pd(g_x1_col3_0);
    __m256d col3_1 = _mm256_load_pd(g_x1_col3_4);
    __m256d col3_2 = _mm256_load_pd(g_x1_col3_8);
    __m256d a3 = _mm256_broadcast_sd(a+7);
    b0_1 = _mm256_fmadd_pd(a3, col3_0, b0_1);
    b1_1 = _mm256_fmadd_pd(a3, col3_1, b1_1);
    b2_1 = _mm256_fmadd_pd(a3, col3_2, b2_1);

    __m256d col5_0 = _mm256_load_pd(g_x1_col5_0);
    __m256d a5 = _mm256_broadcast_sd(a+11);
    b0_0 = _mm256_fmadd_pd(a5, col5_0, b0_0);
    b1_0 = _mm256_fmadd_pd(a5, col1_0, b1_0);
    b2_0 = _mm256_fmadd_pd(a5, col1_1, b2_0);

    __m256d col7_0 = _mm256_load_pd(g_x1_col7_0);
    __m256d a7 = _mm256_broadcast_sd(a+15);
    b0_1 = _mm256_fmadd_pd(a7, col7_0, b0_1);
    b1_1 = _mm256_fmadd_pd(a7, col3_0, b1_1);
    b2_1 = _mm256_fmadd_pd(a7, col3_1, b2_1);

    __m256d col9_0 = _mm256_load_pd(g_x1_col9_0);
    __m256d a9 = _mm256_broadcast_sd(a+19);
    b0_0 = _mm256_fmadd_pd(a9, col9_0, b0_0);
    b1_0 = _mm256_fmadd_pd(a9, col5_0, b1_0);
    b2_0 = _mm256_fmadd_pd(a9, col1_0, b2_0);

    __m256d col11_0 = _mm256_load_pd(g_x1_col11_0);
    __m256d a11 = _mm256_broadcast_sd(a+23);
    b0_1 = _mm256_fmadd_pd(a11, col11_0, b0_1);
    b1_1 = _mm256_fmadd_pd(a11, col7_0, b1_1);
    b2_1 = _mm256_fmadd_pd(a11, col3_0, b2_1);

    b0_0 = _mm256_add_pd(b0_0, b0_1);
    b1_0 = _mm256_add_pd(b1_0, b1_1);
    b2_0 = _mm256_add_pd(b2_0, b2_1);

    __m256d xxax1_0 = _mm256_permute2f128_pd(b0_0, b0_0, 0x0);
    __m256d xxax1_2 = _mm256_permute2f128_pd(b1_0, b1_0, 0x0);
    __m256d xxax1_4 = _mm256_permute2f128_pd(b2_0, b2_0, 0x0);

    _mm256_store_pd(dst+0, xxax1_0);
    _mm256_store_pd(dst+4, b0_0); // can store directly, because lower half is ignored
    _mm256_store_pd(dst+8, xxax1_2);
    _mm256_store_pd(dst+12, b1_0);
    _mm256_store_pd(dst+16, xxax1_4);
    _mm256_store_pd(dst+20, b2_0);
}

force_inline
void decode_scalar(byte32_t dst, byte32_t src) {
    memcpy(dst, src, sizeof(byte32_t));
    dst[0] &= 248;
    dst[31] &= 127;
    dst[31] |= 64;
}

static void decode_point(field_t dst, byte32_t src) {
    int32_t a0 = (*(int32_t *) (src+0) >> 0) & 0x3fffff;
    int32_t a1 = (*(int32_t *) (src+2) >> 6) & 0x1fffff;
    int32_t a2 = (*(int32_t *) (src+5) >> 3) & 0x1fffff;
    int32_t a3 = (*(int32_t *) (src+8) >> 0) & 0x1fffff;
    int32_t a4 = (*(int32_t *) (src+10) >> 5) & 0x3fffff;
    int32_t a5 = (*(int32_t *) (src+13) >> 3) & 0x1fffff;
    int32_t a6 = (*(int32_t *) (src+15) >> 8) & 0x1fffff;
    int32_t a7 = (*(int32_t *) (src+18) >> 5) & 0x1fffff;
    int32_t a8 = (*(int32_t *) (src+21) >> 2) & 0x3fffff;
    int32_t a9 = (*(int32_t *) (src+24) >> 0) & 0x1fffff;
    int32_t a10 = (*(int32_t *) (src+26) >> 5) & 0x1fffff;
    int32_t a11 = (*(int32_t *) (src+29) >> 2) & 0x1fffff;

    dst[0] = ((double) a0);
    dst[1] = ((double) a1) * c2p22;
    dst[2] = ((double) a2) * c2p43;
    dst[3] = ((double) a3) * c2p64;
    dst[4] = ((double) a4) * c2p85;
    dst[5] = ((double) a5) * c2p107;
    dst[6] = ((double) a6) * c2p128;
    dst[7] = ((double) a7) * c2p149;
    dst[8] = ((double) a8) * c2p170;
    dst[9] = ((double) a9) * c2p192;
    dst[10] = ((double) a10) * c2p213;
    dst[11] = ((double) a11) * c2p234;
}

force_inline
void field_two_pack(field_twopack_t dst, field_t a, field_t b) {
    for (int i = 0; i < 6; i++) {
        dst[i*4 + 0] = a[i*2];
        dst[i*4 + 1] = a[i*2 + 1];
        dst[i*4 + 2] = b[i*2];
        dst[i*4 + 3] = b[i*2 + 1];
    }
}

force_inline
void field_two_unpack(field_t dst0, field_t dst1, field_twopack_t a) {
    for (int i = 0; i < 6; i++) {
        dst0[i*2] = a[i*4 + 0];
        dst0[i*2 + 1] = a[i*4 + 1];
        dst1[i*2] = a[i*4 + 2];
        dst1[i*2 + 1] = a[i*4 + 3];
    }
}

// swap (<a0,a1>,<b0,b1>) with (<b0,b1>,<a0,a1>) iff swap == 1.
force_inline
void double_packed_cswap(int64_t swap, field_twopack_t a, field_twopack_t b) {
    __m256i swapv = _mm256_set1_epi64x(-swap);

    __m256i a0 = _mm256_load_si256((__m256i *) (a+0));
    __m256i a1 = _mm256_load_si256((__m256i *) (a+4));
    __m256i a2 = _mm256_load_si256((__m256i *) (a+8));
    __m256i a3 = _mm256_load_si256((__m256i *) (a+12));
    __m256i a4 = _mm256_load_si256((__m256i *) (a+16));
    __m256i a5 = _mm256_load_si256((__m256i *) (a+20));
    __m256i b0 = _mm256_load_si256((__m256i *) (b+0));
    __m256i b1 = _mm256_load_si256((__m256i *) (b+4));
    __m256i b2 = _mm256_load_si256((__m256i *) (b+8));
    __m256i b3 = _mm256_load_si256((__m256i *) (b+12));
    __m256i b4 = _mm256_load_si256((__m256i *) (b+16));
    __m256i b5 = _mm256_load_si256((__m256i *) (b+20));

    __m256i ab0_xor = _mm256_xor_si256(a0, b0);
    __m256i ab1_xor = _mm256_xor_si256(a1, b1);
    __m256i ab2_xor = _mm256_xor_si256(a2, b2);
    __m256i ab3_xor = _mm256_xor_si256(a3, b3);
    __m256i ab4_xor = _mm256_xor_si256(a4, b4);
    __m256i ab5_xor = _mm256_xor_si256(a5, b5);
    __m256i t0 = _mm256_and_si256(swapv, ab0_xor);
    __m256i t1 = _mm256_and_si256(swapv, ab1_xor);
    __m256i t2 = _mm256_and_si256(swapv, ab2_xor);
    __m256i t3 = _mm256_and_si256(swapv, ab3_xor);
    __m256i t4 = _mm256_and_si256(swapv, ab4_xor);
    __m256i t5 = _mm256_and_si256(swapv, ab5_xor);

    a0 = _mm256_xor_si256(a0, t0);
    a1 = _mm256_xor_si256(a1, t1);
    a2 = _mm256_xor_si256(a2, t2);
    a3 = _mm256_xor_si256(a3, t3);
    a4 = _mm256_xor_si256(a4, t4);
    a5 = _mm256_xor_si256(a5, t5);
    b0 = _mm256_xor_si256(b0, t0);
    b1 = _mm256_xor_si256(b1, t1);
    b2 = _mm256_xor_si256(b2, t2);
    b3 = _mm256_xor_si256(b3, t3);
    b4 = _mm256_xor_si256(b4, t4);
    b5 = _mm256_xor_si256(b5, t5);

    _mm256_store_si256((__m256i *) (a+0), a0);
    _mm256_store_si256((__m256i *) (a+4), a1);
    _mm256_store_si256((__m256i *) (a+8), a2);
    _mm256_store_si256((__m256i *) (a+12), a3);
    _mm256_store_si256((__m256i *) (a+16), a4);
    _mm256_store_si256((__m256i *) (a+20), a5);
    _mm256_store_si256((__m256i *) (b+0), b0);
    _mm256_store_si256((__m256i *) (b+4), b1);
    _mm256_store_si256((__m256i *) (b+8), b2);
    _mm256_store_si256((__m256i *) (b+12), b3);
    _mm256_store_si256((__m256i *) (b+16), b4);
    _mm256_store_si256((__m256i *) (b+20), b5);
}

// As per RFC 7748, Chapter 5
void curve_scalar_mult(field_t dst_x_2, field_t dst_z_2, byte32_t n, field_t P) {
    field_t x_1; memcpy(x_1, P, sizeof(field_t));
    field_t x_2 = { 1 };
    field_t z_2 = { 0 };
    field_t x_3; memcpy(x_3, P, sizeof(field_t));
    field_t z_3 = { 1 };
    int64_t swap = 0;

    init_glob_const_x1(x_1);

    field_twopack_t p_x_2__z_2, p_x_3__z_3;
    field_two_pack(p_x_2__z_2, x_2, z_2);
    field_two_pack(p_x_3__z_3, x_3, z_3);

    __m256d v_ppmm = _mm256_set_pd(-1.0, -1.0, 1.0, 1.0);
    __m256d v_mmpp = _mm256_set_pd(1.0, 1.0, -1.0, -1.0);

    for (int32_t i = 254; i >= 0; i--) {
        int64_t bit = (n[i / 8] >> (i & 7)) & 1;
        swap ^= bit;
        double_packed_cswap(swap, p_x_2__z_2, p_x_3__z_3);
        swap = bit;

        field_twopack_t p_AB,
                        p_DC,
                        p_AA_BB,
                        p_DA_CB,
                        p_t0_t1,
                        p_t0_sq__t1_sq,
                        p_0_t4,
                        p_0_E,
                        p_AA_t4,
                        p_BB_E,
                        p_0__z_3;

        // p_AB = <x_2+z_2, x_2-z_2>
        V_LOAD_PACKED(x2z2_, p_x_2__z_2);
        __m256d x2z2_0_flip = _mm256_permute2f128_pd(x2z2_0, x2z2_0, 0x21);
        __m256d x2z2_1_flip = _mm256_permute2f128_pd(x2z2_1, x2z2_1, 0x21);
        __m256d x2z2_2_flip = _mm256_permute2f128_pd(x2z2_2, x2z2_2, 0x21);
        __m256d x2z2_3_flip = _mm256_permute2f128_pd(x2z2_3, x2z2_3, 0x21);
        __m256d x2z2_4_flip = _mm256_permute2f128_pd(x2z2_4, x2z2_4, 0x21);
        __m256d x2z2_5_flip = _mm256_permute2f128_pd(x2z2_5, x2z2_5, 0x21);
        __m256d AB0 = _mm256_fmadd_pd(x2z2_0, v_ppmm, x2z2_0_flip);
        __m256d AB1 = _mm256_fmadd_pd(x2z2_1, v_ppmm, x2z2_1_flip);
        __m256d AB2 = _mm256_fmadd_pd(x2z2_2, v_ppmm, x2z2_2_flip);
        __m256d AB3 = _mm256_fmadd_pd(x2z2_3, v_ppmm, x2z2_3_flip);
        __m256d AB4 = _mm256_fmadd_pd(x2z2_4, v_ppmm, x2z2_4_flip);
        __m256d AB5 = _mm256_fmadd_pd(x2z2_5, v_ppmm, x2z2_5_flip);
        V_STORE_PACKED(AB, p_AB);

        // p_DC = <x_3-z_3, x_3+z_3>
        V_LOAD_PACKED(x3z3_, p_x_3__z_3);
        __m256d x3z3_0_flip = _mm256_permute2f128_pd(x3z3_0, x3z3_0, 0x21);
        __m256d x3z3_1_flip = _mm256_permute2f128_pd(x3z3_1, x3z3_1, 0x21);
        __m256d x3z3_2_flip = _mm256_permute2f128_pd(x3z3_2, x3z3_2, 0x21);
        __m256d x3z3_3_flip = _mm256_permute2f128_pd(x3z3_3, x3z3_3, 0x21);
        __m256d x3z3_4_flip = _mm256_permute2f128_pd(x3z3_4, x3z3_4, 0x21);
        __m256d x3z3_5_flip = _mm256_permute2f128_pd(x3z3_5, x3z3_5, 0x21);
        __m256d DC0 = _mm256_fmadd_pd(x3z3_0_flip, v_mmpp, x3z3_0);
        __m256d DC1 = _mm256_fmadd_pd(x3z3_1_flip, v_mmpp, x3z3_1);
        __m256d DC2 = _mm256_fmadd_pd(x3z3_2_flip, v_mmpp, x3z3_2);
        __m256d DC3 = _mm256_fmadd_pd(x3z3_3_flip, v_mmpp, x3z3_3);
        __m256d DC4 = _mm256_fmadd_pd(x3z3_4_flip, v_mmpp, x3z3_4);
        __m256d DC5 = _mm256_fmadd_pd(x3z3_5_flip, v_mmpp, x3z3_5);
        V_STORE_PACKED(DC, p_DC);

        // p_DA_CB = <D*A,C*B>
        field_packed_mul(p_DA_CB, p_DC, p_AB);

        // p_AA_BB = <A^2,B^2>
        field_packed_square(p_AA_BB, p_AB);

        field_double_packed_carry(p_AA_BB, p_DA_CB);

        // p_t0_t1 = <t0,t1>
        V_LOAD_PACKED(da_cb, p_DA_CB);
        __m256d da_cb0_flip = _mm256_permute2f128_pd(da_cb0, da_cb0, 0x21);
        __m256d da_cb1_flip = _mm256_permute2f128_pd(da_cb1, da_cb1, 0x21);
        __m256d da_cb2_flip = _mm256_permute2f128_pd(da_cb2, da_cb2, 0x21);
        __m256d da_cb3_flip = _mm256_permute2f128_pd(da_cb3, da_cb3, 0x21);
        __m256d da_cb4_flip = _mm256_permute2f128_pd(da_cb4, da_cb4, 0x21);
        __m256d da_cb5_flip = _mm256_permute2f128_pd(da_cb5, da_cb5, 0x21);
        __m256d t0t1_0 = _mm256_fmadd_pd(da_cb0_flip, v_ppmm, da_cb0);
        __m256d t0t1_1 = _mm256_fmadd_pd(da_cb1_flip, v_ppmm, da_cb1);
        __m256d t0t1_2 = _mm256_fmadd_pd(da_cb2_flip, v_ppmm, da_cb2);
        __m256d t0t1_3 = _mm256_fmadd_pd(da_cb3_flip, v_ppmm, da_cb3);
        __m256d t0t1_4 = _mm256_fmadd_pd(da_cb4_flip, v_ppmm, da_cb4);
        __m256d t0t1_5 = _mm256_fmadd_pd(da_cb5_flip, v_ppmm, da_cb5);
        V_STORE_PACKED(t0t1_, p_t0_t1);

        // p_t0_sq__t1_sq = <t0^2,t1^2>
        field_packed_square(p_t0_sq__t1_sq, p_t0_t1);

        // p_0_E = <0,E>
        V_LOAD_PACKED(aabb_, p_AA_BB);
        __m256d BBAA0 = _mm256_permute2f128_pd(aabb_0, aabb_0, 0x21);
        __m256d BBAA1 = _mm256_permute2f128_pd(aabb_1, aabb_1, 0x21);
        __m256d BBAA2 = _mm256_permute2f128_pd(aabb_2, aabb_2, 0x21);
        __m256d BBAA3 = _mm256_permute2f128_pd(aabb_3, aabb_3, 0x21);
        __m256d BBAA4 = _mm256_permute2f128_pd(aabb_4, aabb_4, 0x21);
        __m256d BBAA5 = _mm256_permute2f128_pd(aabb_5, aabb_5, 0x21);
        __m256d xE0 = _mm256_sub_pd(BBAA0, aabb_0);
        __m256d xE1 = _mm256_sub_pd(BBAA1, aabb_1);
        __m256d xE2 = _mm256_sub_pd(BBAA2, aabb_2);
        __m256d xE3 = _mm256_sub_pd(BBAA3, aabb_3);
        __m256d xE4 = _mm256_sub_pd(BBAA4, aabb_4);
        __m256d xE5 = _mm256_sub_pd(BBAA5, aabb_5);
        V_STORE_PACKED(xE, p_0_E);

        __m256d BB_E0 = _mm256_blend_pd(BBAA0, xE0, 0xc);
        __m256d BB_E1 = _mm256_blend_pd(BBAA1, xE1, 0xc);
        __m256d BB_E2 = _mm256_blend_pd(BBAA2, xE2, 0xc);
        __m256d BB_E3 = _mm256_blend_pd(BBAA3, xE3, 0xc);
        __m256d BB_E4 = _mm256_blend_pd(BBAA4, xE4, 0xc);
        __m256d BB_E5 = _mm256_blend_pd(BBAA5, xE5, 0xc);
        V_STORE_PACKED(BB_E, p_BB_E);

        // p_0_t4 = <0,E*a24 + AA>
        __m256d a24_v = _mm256_set1_pd(a24);
        __m256d xxt4_0 = _mm256_fmadd_pd(xE0, a24_v, BBAA0);
        __m256d xxt4_1 = _mm256_fmadd_pd(xE1, a24_v, BBAA1);
        __m256d xxt4_2 = _mm256_fmadd_pd(xE2, a24_v, BBAA2);
        __m256d xxt4_3 = _mm256_fmadd_pd(xE3, a24_v, BBAA3);
        __m256d xxt4_4 = _mm256_fmadd_pd(xE4, a24_v, BBAA4);
        __m256d xxt4_5 = _mm256_fmadd_pd(xE5, a24_v, BBAA5);
        V_STORE_PACKED(xxt4_, p_0_t4);

        field_double_packed_carry(p_t0_sq__t1_sq, p_0_t4);

        // p_AA_t4 = <AA,t4>
        V_LOAD_PACKED(AAxx_, p_AA_BB);
        V_LOAD_PACKED(xxt4_c_, p_0_t4);
        __m256d AA_t4_0 = _mm256_blend_pd(AAxx_0, xxt4_c_0, 0xc);
        __m256d AA_t4_1 = _mm256_blend_pd(AAxx_1, xxt4_c_1, 0xc);
        __m256d AA_t4_2 = _mm256_blend_pd(AAxx_2, xxt4_c_2, 0xc);
        __m256d AA_t4_3 = _mm256_blend_pd(AAxx_3, xxt4_c_3, 0xc);
        __m256d AA_t4_4 = _mm256_blend_pd(AAxx_4, xxt4_c_4, 0xc);
        __m256d AA_t4_5 = _mm256_blend_pd(AAxx_5, xxt4_c_5, 0xc);
        V_STORE_PACKED(AA_t4_, p_AA_t4);

        // <x_2,z_2> = <AA*BB,t4*E>
        field_packed_mul(p_x_2__z_2, p_AA_t4, p_BB_E);

        // <_,z_3> = <_,t1^2*x1>
        field_mul_x1_upper(p_0__z_3, p_t0_sq__t1_sq);

        field_double_packed_carry(p_x_2__z_2, p_0__z_3);

        // build <x_3,z_3>
        V_LOAD_PACKED(x3_xx_, p_t0_sq__t1_sq);
        V_LOAD_PACKED(xx_z3_, p_0__z_3);
        __m256d x3z3_p_0 = _mm256_blend_pd(x3_xx_0, xx_z3_0, 0xc);
        __m256d x3z3_p_1 = _mm256_blend_pd(x3_xx_1, xx_z3_1, 0xc);
        __m256d x3z3_p_2 = _mm256_blend_pd(x3_xx_2, xx_z3_2, 0xc);
        __m256d x3z3_p_3 = _mm256_blend_pd(x3_xx_3, xx_z3_3, 0xc);
        __m256d x3z3_p_4 = _mm256_blend_pd(x3_xx_4, xx_z3_4, 0xc);
        __m256d x3z3_p_5 = _mm256_blend_pd(x3_xx_5, xx_z3_5, 0xc);
        V_STORE_PACKED(x3z3_p_, p_x_3__z_3);
    }

    double_packed_cswap(swap, p_x_2__z_2, p_x_3__z_3);
    field_two_unpack(dst_x_2, dst_z_2, p_x_2__z_2);
}

int crypto_scalarmult(unsigned char * dst,
                      const unsigned char *n,
                      const unsigned char *P) {
    byte32_t scalar;
    decode_scalar(scalar, (uint8_t *) n);

    field_t base, x_2, z_2;
    decode_point(base, (uint8_t *) P);
    curve_scalar_mult(x_2, z_2, scalar, base);

    field51_t x, z;
    field_double_to_51(x, x_2);
    field_double_to_51(z, z_2);
    field_invert_51(z, z);
    field_mul_51(x, x, z);
    encode_point_51(dst, x);

    return 0;
}

