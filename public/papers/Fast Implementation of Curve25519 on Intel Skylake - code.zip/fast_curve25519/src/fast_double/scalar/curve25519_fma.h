#ifndef __CURVE25519_FMA_H
#define __CURVE25519_FMA_H

#include <stdint.h>

typedef uint8_t byte32_t[32] __attribute__((aligned(32)));
typedef double field_t[12] __attribute__((aligned(32)));
typedef double field_quadpack_t[48] __attribute__((aligned(32)));

void field_add(field_t dst, field_t a, field_t b);
void field_sub(field_t dst, field_t a, field_t b);
void field_square(field_t dst, field_t src);
void field_mul(field_t dst, field_t a, field_t b);
void field_invert(field_t dst, field_t src);
void field_mul_a24(field_t dst, field_t src);
void field_carry(field_t a);
void field_quad_pack(field_quadpack_t dst, field_t a, field_t b, field_t c, field_t d);
void field_quad_unpack(field_t a, field_t b, field_t c, field_t d, field_quadpack_t src);
void decode_point(field_t dst, byte32_t src);
void encode_point(byte32_t dst, field_t src);
void decode_scalar(byte32_t dst, byte32_t src);
void cswap(int64_t swap, field_t a, field_t b);
void curve_scalar_mult(field_t dst_x_2, field_t dst_z_2, byte32_t n, field_t P);
uint64_t load3(uint8_t *in);
uint64_t load2(uint8_t *in);

#endif // __CURVE25519_FMA_H
