#ifndef __RADIX51_H
#define __RADIX51_H

#include <inttypes.h>
#include "curve25519_fma.h"

typedef uint64_t field51_t[5];
typedef __uint128_t uint128_t;

void field_double_to_51(field51_t dst, field_t src);
void field_square_51(field51_t dst, field51_t src);
void field_mul_51(field51_t dst, field51_t a, field51_t b);
void field_invert_51(field51_t dst, field51_t src);
void encode_point_51(unsigned char *dst, field51_t src);
void decode_point_51(field51_t dst, unsigned char *src);

#endif // __RADIX51_H

