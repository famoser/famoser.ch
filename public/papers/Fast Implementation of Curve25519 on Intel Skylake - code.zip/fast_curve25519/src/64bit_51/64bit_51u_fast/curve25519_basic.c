#include <stdio.h>
#include <string.h>

#include "curve25519_basic.h"
#include "crypto_scalarmult.h"

#define a24 121665

#define force_inline __attribute__((always_inline)) inline

// 5 add
force_inline
void field_add(field_t dst, field_t a, field_t b) {
    dst[0] = a[0] + b[0];
    dst[1] = a[1] + b[1];
    dst[2] = a[2] + b[2];
    dst[3] = a[3] + b[3];
    dst[4] = a[4] + b[4];
}

// 5 add
force_inline
void field_sub(field_t dst, field_t a, field_t b) {
    // (2^0 * (2^54-152) + 2^51 * (2^54-8) + 2^102 * (2^54-8) + 2^153 * (2^54-8) + 2^204 * (2^54-8))/(2^255-19) = 8
    static const limb two54m152 = (((limb)1) << 54) - 152;
    static const limb two54m8 = (((limb)1) << 54) - 8;

    dst[0] = a[0] + two54m152 - b[0];
    dst[1] = a[1] + two54m8 - b[1];
    dst[2] = a[2] + two54m8 - b[2];
    dst[3] = a[3] + two54m8 - b[3];
    dst[4] = a[4] + two54m8 - b[4];
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
force_inline
void field_square(field_t dst, field_t src) {
    uint128_t h0;
    uint128_t h1;
    uint128_t h2;
    uint128_t h3;
    uint128_t h4;

    limb f0 = src[0];
    limb f1 = src[1];
    limb f2 = src[2];
    limb f3 = src[3];
    limb f4 = src[4];
    

    //uint64_t f1_19 = 19 * f1; // f < 2^51 & 19 < 2^6 => 19*f < 2^57
    //uint64_t f2_19 = 19 * f2;
    uint64_t f3_19 = 19 * f3;
    uint64_t f4_19 = 19 * f4;
    
    uint128_t f0f0 = (uint128_t) f0 * f0;
    uint128_t f0f1 =(uint128_t) f0 * f1;
    uint128_t f0f2 =(uint128_t) f0 * f2;
    uint128_t f0f3 =(uint128_t) f0 * f3;
    uint128_t f0f4 =(uint128_t) f0 * f4;
    h0 = f0f0;
    h1 = f0f1;
    h2 = f0f2;
    h3 = f0f3;
    h4 = f0f4;

    uint128_t f1f0 = f0f1;
    uint128_t f1f1 = (uint128_t) f1 * f1;
    uint128_t f1f2 = (uint128_t) f1 * f2;
    uint128_t f1f3 = (uint128_t) f1 * f3;
    uint128_t f1f4_19 = (uint128_t) f1 * f4_19;
    h0 += f1f4_19;
    h1 += f1f0;
    h2 += f1f1;
    h3 += f1f2;
    h4 += f1f3;

    uint128_t f2f0 = f0f2;
    uint128_t f2f1 = f1f2;
    uint128_t f2f2 = (uint128_t) f2 * f2;
    uint128_t f2f3_19 = (uint128_t) f2 * f3_19;
    uint128_t f2f4_19 = (uint128_t) f2 * f4_19;
    h0 += f2f3_19;
    h1 += f2f4_19;
    h2 += f2f0;
    h3 += f2f1;
    h4 += f2f2;
    
    uint128_t f3f0 = f0f3;
    uint128_t f3f1 = f1f3;
    uint128_t f3f2_19 = f2f3_19;
    uint128_t f3f3_19 = (uint128_t) f3 * f3_19;
    uint128_t f3f4_19 = (uint128_t) f3 * f4_19;
    h0 += f3f2_19;
    h1 += f3f3_19;
    h2 += f3f4_19;
    h3 += f3f0;
    h4 += f3f1;

    uint128_t f4f0 = f0f4;
    uint128_t f4f1_19 = f1f4_19;
    uint128_t f4f2_19 = f2f4_19;
    uint128_t f4f3_19 = f3f4_19;
    uint128_t f4f4_19 = (uint128_t) f4 * f4_19;
    h0 += f4f1_19;
    h1 += f4f2_19;
    h2 += f4f3_19;
    h3 += f4f4_19;
    h4 += f4f0;

    h1 += h0 >> 51;
    h0 &= 0x7ffffffffffff;

    h2 += h1 >> 51;
    h1 &= 0x7ffffffffffff;

    h3 += h2 >> 51;
    h2 &= 0x7ffffffffffff;

    h4 += h3 >> 51;
    h3 &= 0x7ffffffffffff;

    h0 += (h4 >> 51) * 19;
    h4 &= 0x7ffffffffffff;

    h1 += (h0 >> 51);
    h0 &= 0x7ffffffffffff;

    dst[0] = (limb) h0;
    dst[1] = (limb) h1;
    dst[2] = (limb) h2;
    dst[3] = (limb) h3;
    dst[4] = (limb) h4;
}

// 26 add (128), 6 shift (128), 30 mul
// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
force_inline
void field_mul(field_t output, field_t in, field_t in2) {
    uint128_t h0;
    uint128_t h1;
    uint128_t h2;
    uint128_t h3;
    uint128_t h4;
    
    limb f0 = in[0];
    limb f1 = in[1];
    limb f2 = in[2];
    limb f3 = in[3];
    limb f4 = in[4];
    
    limb g0 = in2[0];
    limb g1 = in2[1];
    limb g2 = in2[2];
    limb g3 = in2[3];
    limb g4 = in2[4];

    uint64_t g1_19 = 19 * g1; // g < 2^51 & 19 < 2^6 => 19*g < 2^57
    uint64_t g2_19 = 19 * g2;
    uint64_t g3_19 = 19 * g3;
    uint64_t g4_19 = 19 * g4;
    
    uint128_t f0g0 = (uint128_t) f0 * g0;
    uint128_t f0g1 =(uint128_t) f0 * g1;
    uint128_t f0g2 =(uint128_t) f0 * g2;
    uint128_t f0g3 =(uint128_t) f0 * g3;
    uint128_t f0g4 =(uint128_t) f0 * g4;
    h0 = f0g0;
    h1 = f0g1;
    h2 = f0g2;
    h3 = f0g3;
    h4 = f0g4;

    uint128_t f1g0 = (uint128_t) f1 * g0;
    uint128_t f1g1 = (uint128_t) f1 * g1;
    uint128_t f1g2 = (uint128_t) f1 * g2;
    uint128_t f1g3 = (uint128_t) f1 * g3;
    uint128_t f1g4_19 = (uint128_t)f1 * g4_19;
    h0 += f1g4_19;
    h1 += f1g0;
    h2 += f1g1;
    h3 += f1g2;
    h4 += f1g3;

    uint128_t f2g0 = (uint128_t) f2 * g0;
    uint128_t f2g1 = (uint128_t) f2 * g1;
    uint128_t f2g2 = (uint128_t) f2 * g2;
    uint128_t f2g3_19 = (uint128_t) f2 * g3_19;
    uint128_t f2g4_19 = (uint128_t) f2 * g4_19;
    h0 += f2g3_19;
    h1 += f2g4_19;
    h2 += f2g0;
    h3 += f2g1;
    h4 += f2g2;
    
    uint128_t f3g0 = (uint128_t) f3 * g0;
    uint128_t f3g1 = (uint128_t) f3 * g1;
    uint128_t f3g2_19 = (uint128_t) f3 * g2_19;
    uint128_t f3g3_19 = (uint128_t) f3 * g3_19;
    uint128_t f3g4_19 = (uint128_t) f3 * g4_19;
    h0 += f3g2_19;
    h1 += f3g3_19;
    h2 += f3g4_19;
    h3 += f3g0;
    h4 += f3g1;

    uint128_t f4g0 = (uint128_t) f4 * g0;
    uint128_t f4g1_19 = (uint128_t) f4 * g1_19;
    uint128_t f4g2_19 = (uint128_t) f4 * g2_19;
    uint128_t f4g3_19 = (uint128_t) f4 * g3_19;
    uint128_t f4g4_19 = (uint128_t) f4 * g4_19;
    h0 += f4g1_19;
    h1 += f4g2_19;
    h2 += f4g3_19;
    h3 += f4g4_19;
    h4 += f4g0;

    h1 += h0 >> 51;
    h0 &= 0x7ffffffffffff;

    h2 += h1 >> 51;
    h1 &= 0x7ffffffffffff;

    h3 += h2 >> 51;
    h2 &= 0x7ffffffffffff;

    h4 += h3 >> 51;
    h3 &= 0x7ffffffffffff;

    h0 += (h4 >> 51) * 19;
    h4 &= 0x7ffffffffffff;

    h1 += (h0 >> 51);
    h0 &= 0x7ffffffffffff;

    output[0] = (limb) h0;
    output[1] = (limb) h1;
    output[2] = (limb) h2;
    output[3] = (limb) h3;
    output[4] = (limb) h4;
}

// taken from djb's original implementation
void field_invert(field_t dst, field_t src) {
    field_t z2, z9, z11, z2_5_0, z2_10_0, z2_20_0, z2_50_0, z2_100_0, t0, t1;
    int i;

    // 4s, 3m
    field_square(z2,src);           // 2
    field_square(t1,z2);            // 4
    field_square(t0,t1);            // 8
    field_mul(z9,t0,src);           // 9
    field_mul(z11,z9,z2);           // 11
    field_square(t0,z11);           // 22
    field_mul(z2_5_0,t0,z9);        // 2^5 - 2^0 = 31

    // 5s, 1m
    field_square(t0,z2_5_0);        // 2^6 - 2^1
    field_square(t1,t0);            // 2^7 - 2^2
    field_square(t0,t1);            // 2^8 - 2^3
    field_square(t1,t0);            // 2^9 - 2^4
    field_square(t0,t1);            // 2^10 - 2^5
    field_mul(z2_10_0,t0,z2_5_0);   // 2^10 - 2^0

    // 10s, 1m
    field_square(t0,z2_10_0);       // 2^11 - 2^1
    field_square(t1,t0);            // 2^12 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^20 - 2^10
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_20_0,t1,z2_10_0);  // 2^20 - 2^0

    // 20s, 1m
    field_square(t0,z2_20_0);       // 2^21 - 2^1
    field_square(t1,t0);            // 2^22 - 2^2
    for (i = 2;i < 20;i += 2) {     // 2^40 - 2^20
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_20_0);       // 2^40 - 2^0

    // 10s, 1m
    field_square(t1,t0);            // 2^41 - 2^1
    field_square(t0,t1);            // 2^42 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^50 - 2^10
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(z2_50_0,t0,z2_10_0);  // 2^50 - 2^0

    // 50s, 1m
    field_square(t0,z2_50_0);       // 2^51 - 2^1
    field_square(t1,t0);            // 2^52 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^100 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_100_0,t1,z2_50_0); // 2^100 - 2^0

    // 100s, 1m
    field_square(t1,z2_100_0);      // 2^101 - 2^1
    field_square(t0,t1);            // 2^102 - 2^2
    for (i = 2;i < 100;i += 2) {    // 2^200 - 2^100
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(t1,t0,z2_100_0);      // 2^200 - 2^0

    // 50s, 1m
    field_square(t0,t1);            // 2^201 - 2^1
    field_square(t1,t0);            // 2^202 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^250 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_50_0);       // 2^250 - 2^0

    // 5s, 1m
    field_square(t1,t0);            // 2^251 - 2^1
    field_square(t0,t1);            // 2^252 - 2^2
    field_square(t1,t0);            // 2^253 - 2^3
    field_square(t0,t1);            // 2^254 - 2^4
    field_square(t1,t0);            // 2^255 - 2^5
    field_mul(dst,t1,z11);          // 2^255 - 21
}

// 4 mul, 
// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
force_inline
void field_mul_a24(field_t dst, field_t src) {
    uint128_t h0 = (uint128_t) src[0] * a24;
    uint128_t h1 = (uint128_t) src[1] * a24;
    uint128_t h2 = (uint128_t) src[2] * a24;
    uint128_t h3 = (uint128_t) src[3] * a24;
    uint128_t h4 = (uint128_t) src[4] * a24;

    h1 += h0 >> 51;
    h0 &= 0x7ffffffffffff;

    h2 += h1 >> 51;
    h1 &= 0x7ffffffffffff;

    h3 += h2 >> 51;
    h2 &= 0x7ffffffffffff;

    h4 += h3 >> 51;
    h3 &= 0x7ffffffffffff;

    h0 += (h4 >> 51) * 19;
    h4 &= 0x7ffffffffffff;

    dst[0] = (limb) h0;
    dst[1] = (limb) h1;
    dst[2] = (limb) h2;
    dst[3] = (limb) h3;
    dst[4] = (limb) h4;
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
// see bernstein page 5, upper paragrpah for secret key definition
void decode_scalar(byte32_t dst, byte32_t src) {
    memcpy(dst, src, sizeof(byte32_t));
    dst[0] &= 248; // ensure multiple of 8 (248 = 1111 1000)
    dst[31] &= 127; // ensure biggest secret key <= 8*(2^251 - 1) = 2^254 - 1 (127 = 0111 1111)
    dst[31] |= 64; // ensure secret key offset of + 2^254 (64 = 0100 0000) 
}


// source: supercop amd64-51
void decode_point(field_t dst, byte32_t src) {
    limb h0;
    limb h1;
    limb h2;
    limb h3;
    limb h4;

    h0 = *(limb *) src & 0x7ffffffffffff;
    h1 = *(limb *) (src+6); h1 = (h1 >> 3) & 0x7ffffffffffff;
    h2 = *(limb *) (src+12); h2 = (h2 >> 6) & 0x7ffffffffffff;
    h3 = *(limb *) (src+19); h3 = (h3 >> 1) & 0x7ffffffffffff;
    h4 = *(limb *) (src+25); h4 = (h4 >> 4) & 0x7ffffffffffff;

    // this part is only needed if the input is too large
    h1 += h0 >> 51;
    h0 &= 0x7ffffffffffff;

    h2 += h1 >> 51;
    h1 &= 0x7ffffffffffff;

    h3 += h2 >> 51;
    h2 &= 0x7ffffffffffff;

    h4 += h3 >> 51;
    h3 &= 0x7ffffffffffff;

    h0 += (h4 >> 51) * 19;
    h4 &= 0x7ffffffffffff;

    dst[0] = (limb) h0;
    dst[1] = (limb) h1;
    dst[2] = (limb) h2;
    dst[3] = (limb) h3;
    dst[4] = (limb) h4;
}


// source: supercop amd64-51
void encode_point(byte32_t dst, field_t src) {

    limb q = (19*src[4] + ((limb)1 << 50)) >> 51;
    q = (src[0] + q) >> 51;
    q = (src[1] + q) >> 51;
    q = (src[2] + q) >> 51;
    q = (src[3] + q) >> 51;
    q = (src[4] + q) >> 51;

    // Goal: Output h-(2^255-19)q, which is between 0 and 2^255-20.
    src[0] += 19 * q;
    // Goal: Output h-2^255 q, which is between 0 and 2^255-20.


    src[1] += src[0] >> 51;
    src[0] &= 0x7ffffffffffff;

    src[2] += src[1] >> 51;
    src[1] &= 0x7ffffffffffff;

    src[3] += src[2] >> 51;
    src[2] &= 0x7ffffffffffff;

    src[4] += src[3] >> 51;
    src[3] &= 0x7ffffffffffff;

    src[0] += (src[4] >> 51) * 19;
    src[4] &= 0x7ffffffffffff;


    *(limb *) dst = src[0] | (src[1] << 51);
    *(limb *) (dst+8) = (src[1] >> 13) | (src[2] << 38);
    *(limb *) (dst+16) = (src[2] >> 26) | (src[3] << 25);
    *(limb *) (dst+24) = (src[3] >> 39) | (src[4] << 12);
}

// swap (a, b) with (b, a) iff swap == 1.
void cswap(limb swap, field_t a, field_t b) {
    swap = -swap;
    for (unsigned i = 0; i < 5; i++) {
        limb t = swap & (a[i] ^ b[i]);
        a[i] ^= t;
        b[i] ^= t;
    }
}

// 1 invert, 255+2 cswap, 1275+1 mul, 255 mul24, 1020 sq, 1020 add, 1020 sub, 255 xor
// As per RFC 7748, Chapter 5
void curve_scalar_mult(field_t dst, byte32_t n, field_t P) {
    field_t x_1; memcpy(x_1, P, sizeof(field_t));
    field_t x_2 = { 1 };
    field_t z_2 = { 0 };
    field_t x_3; memcpy(x_3, P, sizeof(field_t));
    field_t z_3 = { 1 };
    limb swap = 0;

    for (int32_t i = 254; i >= 0; i--) {
        uint32_t bit = (n[i / 8] >> (i & 7)) & 1;
        swap ^= bit;
        cswap(swap, x_2, x_3);
        cswap(swap, z_2, z_3);
        swap = bit;

        field_t A, AA, B, BB, E, C, D, DA, CB;
        field_t t0, t1, t2, t3, t4;

        // 4 add, 4 sub, 4 square, 5 mul, 1 mul24
        field_add(A, x_2, z_2);
        field_sub(B, x_2, z_2);
        field_add(C, x_3, z_3);
        field_sub(D, x_3, z_3);

        field_mul(DA, D, A);
        field_mul(CB, C, B);
        field_add(t0, DA, CB);
        field_sub(t1, DA, CB);

        field_square(x_3, t0);
        field_square(t2, t1);

        field_mul(z_3, t2, x_1);

        field_square(AA, A);
        field_square(BB, B);
        field_mul(x_2, AA, BB);
        field_sub(E, AA, BB);
        field_mul_a24(t3, E);
        field_add(t4, AA, t3);
        field_mul(z_2, E, t4);
    }

    cswap(swap, x_2, x_3);
    cswap(swap, z_2, z_3);
    field_invert(z_2, z_2);         // z_2 = z_2 ^-1
    field_mul(dst, x_2, z_2);       // dst = x_2 * z_2
}

void curve25519(byte32_t dst, byte32_t n, byte32_t P) {
    byte32_t scalar;
    decode_scalar(scalar, n);

    field_t base, result;
    decode_point(base, P);
    curve_scalar_mult(result, scalar, base);

    encode_point(dst, result);
}

int crypto_scalarmult(unsigned char * dst,
                      const unsigned char *n,
                      const unsigned char *P) {
    curve25519((uint8_t *) dst, (uint8_t *) n, (uint8_t *) P);
    return 0;
}

