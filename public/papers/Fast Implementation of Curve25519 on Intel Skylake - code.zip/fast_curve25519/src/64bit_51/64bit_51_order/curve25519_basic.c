#include <stdio.h>
#include <string.h>

#include "curve25519_basic.h"
#include "crypto_scalarmult.h"

#define force_inline __attribute__((always_inline)) inline
#define a24 121665

force_inline
void field_add(field_t dst, field_t a, field_t b) {
    for (unsigned i = 0; i < 5; i++) {
        dst[i] = a[i] + b[i];
    }
}

force_inline
void field_sub(field_t dst, field_t a, field_t b) {
    for (unsigned i = 0; i < 5; i++) {
        dst[i] = a[i] - b[i];
    }
}

force_inline
void field_add_sub(field_t dst0, field_t dst1, field_t a, field_t b) {
    for (unsigned i = 0; i < 5; i++) {
        dst0[i] = a[i] + b[i];
        dst1[i] = a[i] - b[i];
    }
}

force_inline
void field_carry(int128_t h[5]) {
    int128_t carry[5];
    
    carry[0] = (h[0] + ((int64_t)1 << 50)) >> 51;
    h[1] += carry[0];
    h[0] -= carry[0] << 51;

    carry[1] = (h[1] + ((int64_t)1 << 50)) >> 51;
    h[2] += carry[1];
    h[1] -= carry[1] << 51;

    carry[2] = (h[2] + ((int64_t)1 << 50)) >> 51;
    h[3] += carry[2];
    h[2] -= carry[2] << 51;

    carry[3] = (h[3] + ((int64_t)1 << 50)) >> 51;
    h[4] += carry[3];
    h[3] -= carry[3] << 51;

    carry[4] = (h[4] + ((int64_t)1 << 50)) >> 51;
    h[0] += carry[4] * 19;
    h[4] -= carry[4] << 51;

    carry[0] = (h[0] + ((int64_t)1 << 50)) >> 51;
    h[1] += carry[0];
    h[0] -= carry[0] << 51;
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_square(field_t dst, field_t src) {
    field_mul(dst, src, src);
}


// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_mul(field_t dst, field_t a, field_t b) {
    int64_t f0 = a[0];
    int64_t f1 = a[1];
    int64_t f2 = a[2];
    int64_t f3 = a[3];
    int64_t f4 = a[4];
    
    int64_t g0 = b[0];
    int64_t g1 = b[1];
    int64_t g2 = b[2];
    int64_t g3 = b[3];
    int64_t g4 = b[4];

    int128_t h[5];
    int128_t carry[5];
    
    int128_t f0g0 = (int128_t) f0 * g0;
    h[0] = f0g0;
    int128_t f0g1 =(int128_t) f0 * g1;
    h[1] = f0g1;
    int128_t f0g2 =(int128_t) f0 * g2;
    h[2] = f0g2;
    int128_t f0g3 =(int128_t) f0 * g3;
    h[3] = f0g3;
    int128_t f0g4 =(int128_t) f0 * g4;
    h[4] = f0g4;

    int64_t g4_19 = 19 * g4;
    int128_t f1g0 = (int128_t) f1 * g0;
    h[1] += f1g0;
    int128_t f1g1 = (int128_t) f1 * g1;
    h[2] += f1g1;
    int128_t f1g2 = (int128_t) f1 * g2;
    h[3] += f1g2;
    int128_t f1g3 = (int128_t) f1 * g3;
    h[4] += f1g3;
    int128_t f1g4_19 = (int128_t) f1 * g4_19;
    h[0] += f1g4_19;

    int64_t g3_19 = 19 * g3;
    int128_t f2g0 = (int128_t) f2 * g0;
    h[2] += f2g0;
    int128_t f2g1 = (int128_t) f2 * g1;
    h[3] += f2g1;
    int128_t f2g2 = (int128_t) f2 * g2;
    h[4] += f2g2;
    int128_t f2g3_19 = (int128_t) f2 * g3_19;
    h[0] += f2g3_19;
    int128_t f2g4_19 = (int128_t) f2 * g4_19;
    h[1] += f2g4_19;
    
    int64_t g2_19 = 19 * g2;
    int128_t f3g0 = (int128_t) f3 * g0;
    h[3] += f3g0;
    int128_t f3g1 = (int128_t) f3 * g1;
    h[4] += f3g1;
    int128_t f3g2_19 = (int128_t) f3 * g2_19;
    h[0] += f3g2_19;
    int128_t f3g3_19 = (int128_t) f3 * g3_19;
    h[1] += f3g3_19;
    int128_t f3g4_19 = (int128_t) f3 * g4_19;
    h[2] += f3g4_19;

    int64_t g1_19 = 19 * g1; // g < 2^51 & 19 < 2^6 => 19*g < 2^57
    int128_t f4g0 = (int128_t) f4 * g0;
    h[4] += f4g0;
    int128_t f4g1_19 = (int128_t) f4 * g1_19;
    h[0] += f4g1_19;
    int128_t f4g2_19 = (int128_t) f4 * g2_19;
    h[1] += f4g2_19;
    int128_t f4g3_19 = (int128_t) f4 * g3_19;
    h[2] += f4g3_19;
    int128_t f4g4_19 = (int128_t) f4 * g4_19;
    h[3] += f4g4_19;
    
    
    carry[0] = (h[0] + ((int64_t)1 << 50)) >> 51;
    h[1] += carry[0];
    h[0] -= carry[0] << 51;

    carry[1] = (h[1] + ((int64_t)1 << 50)) >> 51;
    h[2] += carry[1];
    h[1] -= carry[1] << 51;

    carry[2] = (h[2] + ((int64_t)1 << 50)) >> 51;
    h[3] += carry[2];
    h[2] -= carry[2] << 51;

    carry[3] = (h[3] + ((int64_t)1 << 50)) >> 51;
    h[4] += carry[3];
    h[3] -= carry[3] << 51;

    carry[4] = (h[4] + ((int64_t)1 << 50)) >> 51;
    h[0] += carry[4] * 19;
    h[4] -= carry[4] << 51;

    carry[0] = (h[0] + ((int64_t)1 << 50)) >> 51;
    h[1] += carry[0];
    h[0] -= carry[0] << 51;

    dst[0] = (int64_t) h[0];
    dst[1] = (int64_t) h[1];
    dst[2] = (int64_t) h[2];
    dst[3] = (int64_t) h[3];
    dst[4] = (int64_t) h[4];
}

// taken from djb's original implementation
void field_invert(field_t dst, field_t src) {
    field_t z2, z9, z11, z2_5_0, z2_10_0, z2_20_0, z2_50_0, z2_100_0, t0, t1;
    int i;

    field_square(z2,src);           // 2
    field_square(t1,z2);            // 4
    field_square(t0,t1);            // 8
    field_mul(z9,t0,src);           // 9
    field_mul(z11,z9,z2);           // 11
    field_square(t0,z11);           // 22
    field_mul(z2_5_0,t0,z9);        // 2^5 - 2^0 = 31

    field_square(t0,z2_5_0);        // 2^6 - 2^1
    field_square(t1,t0);            // 2^7 - 2^2
    field_square(t0,t1);            // 2^8 - 2^3
    field_square(t1,t0);            // 2^9 - 2^4
    field_square(t0,t1);            // 2^10 - 2^5
    field_mul(z2_10_0,t0,z2_5_0);   // 2^10 - 2^0

    field_square(t0,z2_10_0);       // 2^11 - 2^1
    field_square(t1,t0);            // 2^12 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^20 - 2^10
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_20_0,t1,z2_10_0);  // 2^20 - 2^0

    field_square(t0,z2_20_0);       // 2^21 - 2^1
    field_square(t1,t0);            // 2^22 - 2^2
    for (i = 2;i < 20;i += 2) {     // 2^40 - 2^20
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_20_0);       // 2^40 - 2^0

    field_square(t1,t0);            // 2^41 - 2^1
    field_square(t0,t1);            // 2^42 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^50 - 2^10
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(z2_50_0,t0,z2_10_0);  // 2^50 - 2^0

    field_square(t0,z2_50_0);       // 2^51 - 2^1
    field_square(t1,t0);            // 2^52 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^100 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_100_0,t1,z2_50_0); // 2^100 - 2^0

    field_square(t1,z2_100_0);      // 2^101 - 2^1
    field_square(t0,t1);            // 2^102 - 2^2
    for (i = 2;i < 100;i += 2) {    // 2^200 - 2^100
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(t1,t0,z2_100_0);      // 2^200 - 2^0

    field_square(t0,t1);            // 2^201 - 2^1
    field_square(t1,t0);            // 2^202 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^250 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_50_0);       // 2^250 - 2^0

    field_square(t1,t0);            // 2^251 - 2^1
    field_square(t0,t1);            // 2^252 - 2^2
    field_square(t1,t0);            // 2^253 - 2^3
    field_square(t0,t1);            // 2^254 - 2^4
    field_square(t1,t0);            // 2^255 - 2^5
    field_mul(dst,t1,z11);          // 2^255 - 21
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go

force_inline
void field_mul_a24(field_t dst, field_t src) {
    int128_t h[5];

    h[0] = (int128_t) src[0] * a24;
    h[1] = (int128_t) src[1] * a24;
    h[2] = (int128_t) src[2] * a24;
    h[3] = (int128_t) src[3] * a24;
    h[4] = (int128_t) src[4] * a24;

    field_carry(h);

    dst[0] = (int64_t) h[0];
    dst[1] = (int64_t) h[1];
    dst[2] = (int64_t) h[2];
    dst[3] = (int64_t) h[3];
    dst[4] = (int64_t) h[4];
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
// see bernstein page 5, upper paragrpah for secret key definition
void decode_scalar(byte32_t dst, byte32_t src) {
    memcpy(dst, src, sizeof(byte32_t));
    dst[0] &= 248; // ensure multiple of 8 (248 = 1111 1000)
    dst[31] &= 127; // ensure biggest secret key <= 8*(2^251 - 1) = 2^254 - 1 (127 = 0111 1111)
    dst[31] |= 64; // ensure secret key offset of + 2^254 (64 = 0100 0000) 
}


// source: supercop amd64-51
void decode_point(field_t dst, byte32_t src) {
    int64_t h[5];

    h[0] = (int64_t) src[0];
    h[0] += (int64_t) src[1] << 8;
    h[0] += (int64_t) src[2] << 16;
    h[0] += (int64_t) src[3] << 24;
    h[0] += (int64_t) src[4] << 32;
    h[0] += (int64_t) src[5] << 40;
    h[0] += ((int64_t) src[6] & 7) << 48; // take the first 3 bits

    h[1] = (int64_t) src[6] >> 3;         //skip the first 3 bits (take 5 bits)
    h[1] += (int64_t) src[7] << 5;
    h[1] += (int64_t) src[8] << 13;
    h[1] += (int64_t) src[9] << 21;
    h[1] += (int64_t) src[10] << 29;
    h[1] += (int64_t) src[11] << 37;
    h[1] += ((int64_t) src[12] & 63) << 45;

    h[2] = (int64_t) src[12] >> 6;
    h[2] += (int64_t) src[13] << 2;
    h[2] += (int64_t) src[14] << 10;
    h[2] += (int64_t) src[15] << 18;
    h[2] += (int64_t) src[16] << 26;
    h[2] += (int64_t) src[17] << 34;
    h[2] += (int64_t) src[18] << 42;
    h[2] += ((int64_t) src[19] & 1) << 50;

    h[3] = (int64_t) src[19] >> 1;
    h[3] += (int64_t) src[20] << 7;
    h[3] += (int64_t) src[21] << 15;
    h[3] += (int64_t) src[22] << 23;
    h[3] += (int64_t) src[23] << 31;
    h[3] += (int64_t) src[24] << 39;
    h[3] += ((int64_t) src[25] & 15) << 47;

    h[4] = (int64_t) src[25] >> 4;
    h[4] += (int64_t) src[26] << 4;
    h[4] += (int64_t) src[27] << 12;
    h[4] += (int64_t) src[28] << 20;
    h[4] += (int64_t) src[29] << 28;
    h[4] += (int64_t) src[30] << 36;
    h[4] += ((int64_t) src[31] & 127) << 44;

    //field_carry(h);

    dst[0] = (int64_t) h[0];
    dst[1] = (int64_t) h[1];
    dst[2] = (int64_t) h[2];
    dst[3] = (int64_t) h[3];
    dst[4] = (int64_t) h[4];

}


// source: supercop amd64-51
void encode_point(byte32_t dst, field_t src) {
    int128_t carry[5];

    int64_t q = (19*src[4] + ((int64_t)1 << 50)) >> 51;
    q = (src[0] + q) >> 51;
    q = (src[1] + q) >> 51;
    q = (src[2] + q) >> 51;
    q = (src[3] + q) >> 51;
    q = (src[4] + q) >> 51;

    // Goal: Output h-(2^255-19)q, which is between 0 and 2^255-20.
    src[0] += 19 * q;
    // Goal: Output h-2^255 q, which is between 0 and 2^255-20.

    carry[0] = src[0] >> 51;
    src[1] += carry[0];
    src[0] -= carry[0] << 51;
    carry[1] = src[1] >> 51;
    src[2] += carry[1];
    src[1] -= carry[1] << 51;
    carry[2] = src[2] >> 51;
    src[3] += carry[2];
    src[2] -= carry[2] << 51;
    carry[3] = src[3] >> 51;
    src[4] += carry[3];
    src[3] -= carry[3] << 51;
    carry[4] = src[4] >> 51;
    //src[5] += carry[4];
    src[4] -= carry[4] << 51;



    dst[0] = (uint8_t) (src[0] >> 0);
    dst[1] = (uint8_t) (src[0] >> 8);
    dst[2] = (uint8_t) (src[0] >> 16);
    dst[3] = (uint8_t) (src[0] >> 24);
    dst[4] = (uint8_t) (src[0] >> 32);
    dst[5] = (uint8_t) (src[0] >> 40);

    dst[6] = (uint8_t) (src[0] >> 48) | (src[1] << 3);

    dst[7] = (uint8_t) (src[1] >> 5);
    dst[8] = (uint8_t) (src[1] >> 13);
    dst[9] = (uint8_t) (src[1] >> 21);
    dst[10] = (uint8_t) (src[1] >> 29);
    dst[11] = (uint8_t) (src[1] >> 37);

    dst[12] = (uint8_t) (src[1] >> 45) | (src[2] << 6);

    dst[13] = (uint8_t) (src[2] >> 2);
    dst[14] = (uint8_t) (src[2] >> 10);
    dst[15] = (uint8_t) (src[2] >> 18);
    dst[16] = (uint8_t) (src[2] >> 26);
    dst[17] = (uint8_t) (src[2] >> 34);
    dst[18] = (uint8_t) (src[2] >> 42);

    dst[19] = (uint8_t) (src[2] >> 50) | (src[3] << 1);

    dst[20] = (uint8_t) (src[3] >> 7);
    dst[21] = (uint8_t) (src[3] >> 15);
    dst[22] = (uint8_t) (src[3] >> 23);
    dst[23] = (uint8_t) (src[3] >> 31);
    dst[24] = (uint8_t) (src[3] >> 39);

    dst[25] = (uint8_t) (src[3] >> 47) | (src[4] << 4);

    dst[26] = (uint8_t) (src[4] >> 4);
    dst[27] = (uint8_t) (src[4] >> 12);
    dst[28] = (uint8_t) (src[4] >> 20);
    dst[29] = (uint8_t) (src[4] >> 28);
    dst[30] = (uint8_t) (src[4] >> 36);
    dst[31] = (uint8_t) (src[4] >> 44);
}

// swap (a, b) with (b, a) iff swap == 1.
void cswap(int64_t swap, field_t a, field_t b) {
    swap = -swap;
    for (unsigned i = 0; i < 5; i++) {
        int64_t t = swap & (a[i] ^ b[i]);
        a[i] ^= t;
        b[i] ^= t;
    }
}

// As per RFC 7748, Chapter 5
void curve_scalar_mult(field_t dst, byte32_t n, field_t P) {
    field_t x_1; memcpy(x_1, P, sizeof(field_t));
    field_t x_2 = { 1 };
    field_t z_2 = { 0 };
    field_t x_3; memcpy(x_3, P, sizeof(field_t));
    field_t z_3 = { 1 };
    int64_t swap = 0;

    for (int32_t i = 254; i >= 0; i--) {
        int32_t bit = (n[i / 8] >> (i & 7)) & 1;
        swap ^= bit;
        cswap(swap, x_2, x_3);
        cswap(swap, z_2, z_3);
        swap = bit;

        field_t A, AA, B, BB, E, C, D, DA, CB;
        field_t t0, t1, t2, t3, t4;

        field_add(A, x_2, z_2);
        field_sub(B, x_2, z_2);
        field_add(C, x_3, z_3);
        field_sub(D, x_3, z_3);

        /*
        for (unsigned i = 0; i < 5; i++) {
            A[i] = x_2[i] + z_2[i];
            B[i] = x_2[i] - z_2[i];
            C[i] = x_3[i] + z_3[i];
            D[i] = x_3[i] - z_3[i];
        }
        */

        field_square(AA, A);
        field_square(BB, B);


        field_mul(DA, D, A);
        field_mul(CB, C, B);

        field_sub(E, AA, BB);
        field_add(t0, DA, CB);
        field_sub(t1, DA, CB);

        /*
        for (unsigned i = 0; i < 5; i++) {
            E[i] = AA[i] - BB[i];
            t0[i] = DA[i] + CB[i];
            t1[i] = DA[i] - CB[i];
        }
        */

        field_square(x_3, t0);
        field_square(t2, t1);

        field_mul(z_3, t2, x_1);
        field_mul(x_2, AA, BB);

        field_mul_a24(t3, E);

        field_add(t4, AA, t3);
        field_mul(z_2, E, t4);
    }

    cswap(swap, x_2, x_3);
    cswap(swap, z_2, z_3);
    field_invert(z_2, z_2);         // z_2 = z_2 ^-1
    field_mul(dst, x_2, z_2);       // dst = x_2 * z_2
}

void curve25519(byte32_t dst, byte32_t n, byte32_t P) {
    byte32_t scalar;
    decode_scalar(scalar, n);

    field_t base, result;
    decode_point(base, P);
    curve_scalar_mult(result, scalar, base);

    encode_point(dst, result);
}

int crypto_scalarmult(unsigned char * dst,
                      const unsigned char *n,
                      const unsigned char *P) {
    curve25519((uint8_t *) dst, (uint8_t *) n, (uint8_t *) P);
    return 0;
}

