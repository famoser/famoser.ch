#!/usr/bin/env python3

import csv
import matplotlib.pyplot as plt

csv_file = './benchmark.csv'
bench = {}

# find the fastest run for each implementation
with open(csv_file) as csvf:
    csv_reader = csv.reader(csvf, delimiter=',', quotechar='|')
    for row in csv_reader:
        impl = str(row[0])
        cycles = int(row[2])

        if impl in bench:
            bench[impl] = min(bench[impl], cycles)
        else:
            bench[impl] = cycles

bench_sorted = {k: v for k, v in sorted(bench.items(),
                                        key=lambda item: item[1])}

labels = []
values = []
for k, v in bench_sorted.items():
    labels.append(k)
    values.append(v)

fig = plt.figure()
ax = fig.add_axes([0, 0, 1, 1])
ax.bar(labels, values)
# ax.set_ylim(100000, 160000)

fig.autofmt_xdate()
fig.savefig("benchmark.pdf", bbox_inches='tight')
