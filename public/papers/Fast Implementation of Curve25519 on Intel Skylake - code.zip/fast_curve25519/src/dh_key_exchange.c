#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <inttypes.h>
#include<time.h> 
#include <stdlib.h>

#include "crypto_scalarmult.h"

/**
 * DO NOT USE THIS FUNCTION TO GENERATE RANDOM KEYS USED IN REAL SCENARIOS!
 */
void generate_random_key(uint8_t* k, int n) {

    // Initialize random number generator
    srand((unsigned) time(0));

    for (int i = 0; i < n; ++i) {
        k[i] = rand();
    }
}

static void dh_key_exchange(void **state) {
    (void) state;

    uint8_t base_point[32] = {9};

    /*
        ALICE
    */
    // private key
    uint8_t k_A[32];
    generate_random_key(k_A, 32);
    // public key
    uint8_t p_A[32];
    crypto_scalarmult(p_A, k_A, base_point);

    /*
        BOB
    */
    // private key
    uint8_t k_B[32];
    generate_random_key(k_B, 32);
    // public key
    uint8_t p_B[32];
    crypto_scalarmult(p_B, k_B, base_point);

    /*****************
        EXCHANGE
    A ---p_A---> B
    B ---p_B---> A
    ******************/

    /*
        ALICE
    */
    // shared secret
    uint8_t s_A[32];
    crypto_scalarmult(s_A, k_A, p_B);

    /*
        BOB
    */
    // shared secret
    uint8_t s_B[32];
    crypto_scalarmult(s_B, k_B, p_A);


    /*****************
        VALIDATION
        s_A == s_B
    ******************/
    assert_memory_equal(s_A, s_B, sizeof(uint8_t) * 32);

}


int main() {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(dh_key_exchange)
    };
    return cmocka_run_group_tests(tests, NULL, NULL);
}
