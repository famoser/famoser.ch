#include <stdio.h>
#include <string.h>
#include <immintrin.h>
#include <inttypes.h>

#include "crypto_scalarmult.h"

#define force_inline __attribute__((always_inline)) inline
#define a24 121665

typedef uint8_t byte32_t[32] __attribute__((aligned(32)));
typedef int32_t field_t[10] __attribute__((aligned(32)));

void field_add(field_t dst, field_t a, field_t b) {
    __m256i av = _mm256_load_si256((__m256i *) a);
    __m256i bv = _mm256_load_si256((__m256i *) b);
    __m256i cv = _mm256_add_epi32(av, bv);
    _mm256_store_si256((__m256i *) dst, cv);
    dst[8] = a[8] + b[8];
    dst[9] = a[9] + b[9];
}

void field_sub(field_t dst, field_t a, field_t b) {
    __m256i av = _mm256_load_si256((__m256i *) a);
    __m256i bv = _mm256_load_si256((__m256i *) b);
    __m256i cv = _mm256_sub_epi32(av, bv);
    _mm256_store_si256((__m256i *) dst, cv);
    dst[8] = a[8] - b[8];
    dst[9] = a[9] - b[9];
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_square(field_t dst, field_t src) {
    int32_t f0 = src[0];
	int32_t f1 = src[1];
	int32_t f2 = src[2];
	int32_t f3 = src[3];
	int32_t f4 = src[4];
	int32_t f5 = src[5];
	int32_t f6 = src[6];
	int32_t f7 = src[7];
	int32_t f8 = src[8];
	int32_t f9 = src[9];

	int32_t f0_2 = 2 * f0;
	int32_t f1_2 = 2 * f1;
	int32_t f2_2 = 2 * f2;
	int32_t f3_2 = 2 * f3;
	int32_t f4_2 = 2 * f4;
	int32_t f5_2 = 2 * f5;
	int32_t f6_2 = 2 * f6;
	int32_t f7_2 = 2 * f7;
	int32_t f5_38 = 38 * f5; // 1.31*2^30
	int32_t f6_19 = 19 * f6; // 1.31*2^30
	int32_t f7_38 = 38 * f7; // 1.31*2^30
	int32_t f8_19 = 19 * f8; // 1.31*2^30
	int32_t f9_38 = 38 * f9; // 1.31*2^30
	int64_t f0f0 = (int64_t) f0 * (int64_t) f0;
	int64_t f0f1_2 = (int64_t) f0_2 * (int64_t) f1;
	int64_t f0f2_2 = (int64_t) f0_2 * (int64_t) f2;
	int64_t f0f3_2 = (int64_t) f0_2 * (int64_t) f3;
	int64_t f0f4_2 = (int64_t) f0_2 * (int64_t) f4;
	int64_t f0f5_2 = (int64_t) f0_2 * (int64_t) f5;
	int64_t f0f6_2 = (int64_t) f0_2 * (int64_t) f6;
	int64_t f0f7_2 = (int64_t) f0_2 * (int64_t) f7;
	int64_t f0f8_2 = (int64_t) f0_2 * (int64_t) f8;
	int64_t f0f9_2 = (int64_t) f0_2 * (int64_t) f9;
	int64_t f1f1_2 = (int64_t) f1_2 * (int64_t) f1;
	int64_t f1f2_2 = (int64_t) f1_2 * (int64_t) f2;
	int64_t f1f3_4 = (int64_t) f1_2 * (int64_t) f3_2;
	int64_t f1f4_2 = (int64_t) f1_2 * (int64_t) f4;
	int64_t f1f5_4 = (int64_t) f1_2 * (int64_t) f5_2;
	int64_t f1f6_2 = (int64_t) f1_2 * (int64_t) f6;
	int64_t f1f7_4 = (int64_t) f1_2 * (int64_t) f7_2;
	int64_t f1f8_2 = (int64_t) f1_2 * (int64_t) f8;
	int64_t f1f9_76 = (int64_t) f1_2 * (int64_t) f9_38;
	int64_t f2f2 = (int64_t) f2 * (int64_t) f2;
	int64_t f2f3_2 = (int64_t) f2_2 * (int64_t) f3;
	int64_t f2f4_2 = (int64_t) f2_2 * (int64_t) f4;
	int64_t f2f5_2 = (int64_t) f2_2 * (int64_t) f5;
	int64_t f2f6_2 = (int64_t) f2_2 * (int64_t) f6;
	int64_t f2f7_2 = (int64_t) f2_2 * (int64_t) f7;
	int64_t f2f8_38 = (int64_t) f2_2 * (int64_t) f8_19;
	int64_t f2f9_38 = (int64_t) f2 * (int64_t) f9_38;
	int64_t f3f3_2 = (int64_t) f3_2 * (int64_t) f3;
	int64_t f3f4_2 = (int64_t) f3_2 * (int64_t) f4;
	int64_t f3f5_4 = (int64_t) f3_2 * (int64_t) f5_2;
	int64_t f3f6_2 = (int64_t) f3_2 * (int64_t) f6;
	int64_t f3f7_76 = (int64_t) f3_2 * (int64_t) f7_38;
	int64_t f3f8_38 = (int64_t) f3_2 * (int64_t) f8_19;
	int64_t f3f9_76 = (int64_t) f3_2 * (int64_t) f9_38;
	int64_t f4f4 = (int64_t) f4 * (int64_t) f4;
	int64_t f4f5_2 = (int64_t) f4_2 * (int64_t) f5;
	int64_t f4f6_38 = (int64_t) f4_2 * (int64_t) f6_19;
	int64_t f4f7_38 = (int64_t) f4 * (int64_t) f7_38;
	int64_t f4f8_38 = (int64_t) f4_2 * (int64_t) f8_19;
	int64_t f4f9_38 = (int64_t) f4 * (int64_t) f9_38;
	int64_t f5f5_38 = (int64_t) f5 * (int64_t) f5_38;
	int64_t f5f6_38 = (int64_t) f5_2 * (int64_t) f6_19;
	int64_t f5f7_76 = (int64_t) f5_2 * (int64_t) f7_38;
	int64_t f5f8_38 = (int64_t) f5_2 * (int64_t) f8_19;
	int64_t f5f9_76 = (int64_t) f5_2 * (int64_t) f9_38;
	int64_t f6f6_19 = (int64_t) f6 * (int64_t) f6_19;
	int64_t f6f7_38 = (int64_t) f6 * (int64_t) f7_38;
	int64_t f6f8_38 = (int64_t) f6_2 * (int64_t) f8_19;
	int64_t f6f9_38 = (int64_t) f6 * (int64_t) f9_38;
	int64_t f7f7_38 = (int64_t) f7 * (int64_t) f7_38;
	int64_t f7f8_38 = (int64_t) f7_2 * (int64_t) f8_19;
	int64_t f7f9_76 = (int64_t) f7_2 * (int64_t) f9_38;
	int64_t f8f8_19 = (int64_t) f8 * (int64_t) f8_19;
	int64_t f8f9_38 = (int64_t) f8 * (int64_t) f9_38;
	int64_t f9f9_38 = (int64_t) f9 * (int64_t) f9_38;
	int64_t h0 = f0f0 + f1f9_76 + f2f8_38 + f3f7_76 + f4f6_38 + f5f5_38;
	int64_t h1 = f0f1_2 + f2f9_38 + f3f8_38 + f4f7_38 + f5f6_38;
	int64_t h2 = f0f2_2 + f1f1_2 + f3f9_76 + f4f8_38 + f5f7_76 + f6f6_19;
	int64_t h3 = f0f3_2 + f1f2_2 + f4f9_38 + f5f8_38 + f6f7_38;
	int64_t h4 = f0f4_2 + f1f3_4 + f2f2 + f5f9_76 + f6f8_38 + f7f7_38;
	int64_t h5 = f0f5_2 + f1f4_2 + f2f3_2 + f6f9_38 + f7f8_38;
	int64_t h6 = f0f6_2 + f1f5_4 + f2f4_2 + f3f3_2 + f7f9_76 + f8f8_19;
	int64_t h7 = f0f7_2 + f1f6_2 + f2f5_2 + f3f4_2 + f8f9_38;
	int64_t h8 = f0f8_2 + f1f7_4 + f2f6_2 + f3f5_4 + f4f4 + f9f9_38;
	int64_t h9 = f0f9_2 + f1f8_2 + f2f7_2 + f3f6_2 + f4f5_2;
	int64_t carry[10];

	carry[0] = (h0 + (1 << 25)) >> 26;
	h1 += carry[0];
	h0 -= carry[0] << 26;
	carry[4] = (h4 + (1 << 25)) >> 26;
	h5 += carry[4];
	h4 -= carry[4] << 26;

	carry[1] = (h1 + (1 << 24)) >> 25;
	h2 += carry[1];
	h1 -= carry[1] << 25;
	carry[5] = (h5 + (1 << 24)) >> 25;
	h6 += carry[5];
	h5 -= carry[5] << 25;

	carry[2] = (h2 + (1 << 25)) >> 26;
	h3 += carry[2];
	h2 -= carry[2] << 26;
	carry[6] = (h6 + (1 << 25)) >> 26;
	h7 += carry[6];
	h6 -= carry[6] << 26;

	carry[3] = (h3 + (1 << 24)) >> 25;
	h4 += carry[3];
	h3 -= carry[3] << 25;
	carry[7] = (h7 + (1 << 24)) >> 25;
	h8 += carry[7];
	h7 -= carry[7] << 25;

	carry[4] = (h4 + (1 << 25)) >> 26;
	h5 += carry[4];
	h4 -= carry[4] << 26;
	carry[8] = (h8 + (1 << 25)) >> 26;
	h9 += carry[8];
	h8 -= carry[8] << 26;

	carry[9] = (h9 + (1 << 24)) >> 25;
	h0 += carry[9] * 19;
	h9 -= carry[9] << 25;

	carry[0] = (h0 + (1 << 25)) >> 26;
	h1 += carry[0];
	h0 -= carry[0] << 26;

	dst[0] = (int32_t) h0;
	dst[1] = (int32_t) h1;
	dst[2] = (int32_t) h2;
	dst[3] = (int32_t) h3;
	dst[4] = (int32_t) h4;
	dst[5] = (int32_t) h5;
	dst[6] = (int32_t) h6;
	dst[7] = (int32_t) h7;
	dst[8] = (int32_t) h8;
	dst[9] = (int32_t) h9;
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_mul(field_t dst, field_t a, field_t b) {
    int32_t f0 = a[0];
    int32_t f1 = a[1];
    int32_t f2 = a[2];
    int32_t f3 = a[3];
    int32_t f4 = a[4];
    int32_t f5 = a[5];
    int32_t f6 = a[6];
    int32_t f7 = a[7];
    int32_t f8 = a[8];
    int32_t f9 = a[9];
    int32_t g0 = b[0];
    int32_t g1 = b[1];
    int32_t g2 = b[2];
    int32_t g3 = b[3];
    int32_t g4 = b[4];
    int32_t g5 = b[5];
    int32_t g6 = b[6];
    int32_t g7 = b[7];
    int32_t g8 = b[8];
    int32_t g9 = b[9];

    int32_t g1_19 = 19 * g1; // 1.4*2^29;
    int32_t g2_19 = 19 * g2; // 1.4*2^30; still ok
    int32_t g3_19 = 19 * g3;
    int32_t g4_19 = 19 * g4;
    int32_t g5_19 = 19 * g5;
    int32_t g6_19 = 19 * g6;
    int32_t g7_19 = 19 * g7;
    int32_t g8_19 = 19 * g8;
    int32_t g9_19 = 19 * g9;
    int32_t f1_2 = 2 * f1;
    int32_t f3_2 = 2 * f3;
    int32_t f5_2 = 2 * f5;
    int32_t f7_2 = 2 * f7;
    int32_t f9_2 = 2 * f9;
    int64_t f0g0 = (int64_t) f0 * (int64_t) g0;
    int64_t f0g1 = (int64_t) f0 * (int64_t) g1;
    int64_t f0g2 = (int64_t) f0 * (int64_t) g2;
    int64_t f0g3 = (int64_t) f0 * (int64_t) g3;
    int64_t f0g4 = (int64_t) f0 * (int64_t) g4;
    int64_t f0g5 = (int64_t) f0 * (int64_t) g5;
    int64_t f0g6 = (int64_t) f0 * (int64_t) g6;
    int64_t f0g7 = (int64_t) f0 * (int64_t) g7;
    int64_t f0g8 = (int64_t) f0 * (int64_t) g8;
    int64_t f0g9 = (int64_t) f0 * (int64_t) g9;
    int64_t f1g0 = (int64_t) f1 * (int64_t) g0;
    int64_t f1g1_2 = (int64_t) f1_2 * (int64_t) g1;
    int64_t f1g2 = (int64_t) f1 * (int64_t) g2;
    int64_t f1g3_2 = (int64_t) f1_2 * (int64_t) g3;
    int64_t f1g4 = (int64_t) f1 * (int64_t) g4;
    int64_t f1g5_2 = (int64_t) f1_2 * (int64_t) g5;
    int64_t f1g6 = (int64_t) f1 * (int64_t) g6;
    int64_t f1g7_2 = (int64_t) f1_2 * (int64_t) g7;
    int64_t f1g8 = (int64_t) f1 * (int64_t) g8;
    int64_t f1g9_38 = (int64_t) f1_2 * (int64_t) g9_19;
    int64_t f2g0 = (int64_t) f2 * (int64_t) g0;
    int64_t f2g1 = (int64_t) f2 * (int64_t) g1;
    int64_t f2g2 = (int64_t) f2 * (int64_t) g2;
    int64_t f2g3 = (int64_t) f2 * (int64_t) g3;
    int64_t f2g4 = (int64_t) f2 * (int64_t) g4;
    int64_t f2g5 = (int64_t) f2 * (int64_t) g5;
    int64_t f2g6 = (int64_t) f2 * (int64_t) g6;
    int64_t f2g7 = (int64_t) f2 * (int64_t) g7;
    int64_t f2g8_19 = (int64_t) f2 * (int64_t) g8_19;
    int64_t f2g9_19 = (int64_t) f2 * (int64_t) g9_19;
    int64_t f3g0 = (int64_t) f3 * (int64_t) g0;
    int64_t f3g1_2 = (int64_t) f3_2 * (int64_t) g1;
    int64_t f3g2 = (int64_t) f3 * (int64_t) g2;
    int64_t f3g3_2 = (int64_t) f3_2 * (int64_t) g3;
    int64_t f3g4 = (int64_t) f3 * (int64_t) g4;
    int64_t f3g5_2 = (int64_t) f3_2 * (int64_t) g5;
    int64_t f3g6 = (int64_t) f3 * (int64_t) g6;
    int64_t f3g7_38 = (int64_t) f3_2 * (int64_t) g7_19;
    int64_t f3g8_19 = (int64_t) f3 * (int64_t) g8_19;
    int64_t f3g9_38 = (int64_t) f3_2 * (int64_t) g9_19;
    int64_t f4g0 = (int64_t) f4 * (int64_t) g0;
    int64_t f4g1 = (int64_t) f4 * (int64_t) g1;
    int64_t f4g2 = (int64_t) f4 * (int64_t) g2;
    int64_t f4g3 = (int64_t) f4 * (int64_t) g3;
    int64_t f4g4 = (int64_t) f4 * (int64_t) g4;
    int64_t f4g5 = (int64_t) f4 * (int64_t) g5;
    int64_t f4g6_19 = (int64_t) f4 * (int64_t) g6_19;
    int64_t f4g7_19 = (int64_t) f4 * (int64_t) g7_19;
    int64_t f4g8_19 = (int64_t) f4 * (int64_t) g8_19;
    int64_t f4g9_19 = (int64_t) f4 * (int64_t) g9_19;
    int64_t f5g0 = (int64_t) f5 * (int64_t) g0;
    int64_t f5g1_2 = (int64_t) f5_2 * (int64_t) g1;
    int64_t f5g2 = (int64_t) f5 * (int64_t) g2;
    int64_t f5g3_2 = (int64_t) f5_2 * (int64_t) g3;
    int64_t f5g4 = (int64_t) f5 * (int64_t) g4;
    int64_t f5g5_38 = (int64_t) f5_2 * (int64_t) g5_19;
    int64_t f5g6_19 = (int64_t) f5 * (int64_t) g6_19;
    int64_t f5g7_38 = (int64_t) f5_2 * (int64_t) g7_19;
    int64_t f5g8_19 = (int64_t) f5 * (int64_t) g8_19;
    int64_t f5g9_38 = (int64_t) f5_2 * (int64_t) g9_19;
    int64_t f6g0 = (int64_t) f6 * (int64_t) g0;
    int64_t f6g1 = (int64_t) f6 * (int64_t) g1;
    int64_t f6g2 = (int64_t) f6 * (int64_t) g2;
    int64_t f6g3 = (int64_t) f6 * (int64_t) g3;
    int64_t f6g4_19 = (int64_t) f6 * (int64_t) g4_19;
    int64_t f6g5_19 = (int64_t) f6 * (int64_t) g5_19;
    int64_t f6g6_19 = (int64_t) f6 * (int64_t) g6_19;
    int64_t f6g7_19 = (int64_t) f6 * (int64_t) g7_19;
    int64_t f6g8_19 = (int64_t) f6 * (int64_t) g8_19;
    int64_t f6g9_19 = (int64_t) f6 * (int64_t) g9_19;
    int64_t f7g0 = (int64_t) f7 * (int64_t) g0;
    int64_t f7g1_2 = (int64_t) f7_2 * (int64_t) g1;
    int64_t f7g2 = (int64_t) f7 * (int64_t) g2;
    int64_t f7g3_38 = (int64_t) f7_2 * (int64_t) g3_19;
    int64_t f7g4_19 = (int64_t) f7 * (int64_t) g4_19;
    int64_t f7g5_38 = (int64_t) f7_2 * (int64_t) g5_19;
    int64_t f7g6_19 = (int64_t) f7 * (int64_t) g6_19;
    int64_t f7g7_38 = (int64_t) f7_2 * (int64_t) g7_19;
    int64_t f7g8_19 = (int64_t) f7 * (int64_t) g8_19;
    int64_t f7g9_38 = (int64_t) f7_2 * (int64_t) g9_19;
    int64_t f8g0 = (int64_t) f8 * (int64_t) g0;
    int64_t f8g1 = (int64_t) f8 * (int64_t) g1;
    int64_t f8g2_19 = (int64_t) f8 * (int64_t) g2_19;
    int64_t f8g3_19 = (int64_t) f8 * (int64_t) g3_19;
    int64_t f8g4_19 = (int64_t) f8 * (int64_t) g4_19;
    int64_t f8g5_19 = (int64_t) f8 * (int64_t) g5_19;
    int64_t f8g6_19 = (int64_t) f8 * (int64_t) g6_19;
    int64_t f8g7_19 = (int64_t) f8 * (int64_t) g7_19;
    int64_t f8g8_19 = (int64_t) f8 * (int64_t) g8_19;
    int64_t f8g9_19 = (int64_t) f8 * (int64_t) g9_19;
    int64_t f9g0 = (int64_t) f9 * (int64_t) g0;
    int64_t f9g1_38 = (int64_t) f9_2 * (int64_t) g1_19;
    int64_t f9g2_19 = (int64_t) f9 * (int64_t) g2_19;
    int64_t f9g3_38 = (int64_t) f9_2 * (int64_t) g3_19;
    int64_t f9g4_19 = (int64_t) f9 * (int64_t) g4_19;
    int64_t f9g5_38 = (int64_t) f9_2 * (int64_t) g5_19;
    int64_t f9g6_19 = (int64_t) f9 * (int64_t) g6_19;
    int64_t f9g7_38 = (int64_t) f9_2 * (int64_t) g7_19;
    int64_t f9g8_19 = (int64_t) f9 * (int64_t) g8_19;
    int64_t f9g9_38 = (int64_t) f9_2 * (int64_t) g9_19;

    int64_t h0 = f0g0 + f1g9_38 + f2g8_19 + f3g7_38 + f4g6_19 + f5g5_38 + f6g4_19 + f7g3_38 + f8g2_19 + f9g1_38;
    int64_t h1 = f0g1 + f1g0 + f2g9_19 + f3g8_19 + f4g7_19 + f5g6_19 + f6g5_19 + f7g4_19 + f8g3_19 + f9g2_19;
    int64_t h2 = f0g2 + f1g1_2 + f2g0 + f3g9_38 + f4g8_19 + f5g7_38 + f6g6_19 + f7g5_38 + f8g4_19 + f9g3_38;
    int64_t h3 = f0g3 + f1g2 + f2g1 + f3g0 + f4g9_19 + f5g8_19 + f6g7_19 + f7g6_19 + f8g5_19 + f9g4_19;
    int64_t h4 = f0g4 + f1g3_2 + f2g2 + f3g1_2 + f4g0 + f5g9_38 + f6g8_19 + f7g7_38 + f8g6_19 + f9g5_38;
    int64_t h5 = f0g5 + f1g4 + f2g3 + f3g2 + f4g1 + f5g0 + f6g9_19 + f7g8_19 + f8g7_19 + f9g6_19;
    int64_t h6 = f0g6 + f1g5_2 + f2g4 + f3g3_2 + f4g2 + f5g1_2 + f6g0 + f7g9_38 + f8g8_19 + f9g7_38;
    int64_t h7 = f0g7 + f1g6 + f2g5 + f3g4 + f4g3 + f5g2 + f6g1 + f7g0 + f8g9_19 + f9g8_19;
    int64_t h8 = f0g8 + f1g7_2 + f2g6 + f3g5_2 + f4g4 + f5g3_2 + f6g2 + f7g1_2 + f8g0 + f9g9_38;
    int64_t h9 = f0g9 + f1g8 + f2g7 + f3g6 + f4g5 + f5g4 + f6g3 + f7g2 + f8g1 + f9g0;

    int64_t carry[10];

    carry[0] = (h0 + (1 << 25)) >> 26;
    h1 += carry[0];
    h0 -= carry[0] << 26;
    carry[4] = (h4 + (1 << 25)) >> 26;
    h5 += carry[4];
    h4 -= carry[4] << 26;
    // |h0| <= 2^25
    // |h4| <= 2^25
    // |h1| <= 1.51*2^58
    // |h5| <= 1.51*2^58

    carry[1] = (h1 + (1 << 24)) >> 25;
    h2 += carry[1];
    h1 -= carry[1] << 25;
    carry[5] = (h5 + (1 << 24)) >> 25;
    h6 += carry[5];
    h5 -= carry[5] << 25;
    // |h1| <= 2^24; from now on fits into int32
    // |h5| <= 2^24; from now on fits into int32
    // |h2| <= 1.21*2^59
    // |h6| <= 1.21*2^59

    carry[2] = (h2 + (1 << 25)) >> 26;
    h3 += carry[2];
    h2 -= carry[2] << 26;
    carry[6] = (h6 + (1 << 25)) >> 26;
    h7 += carry[6];
    h6 -= carry[6] << 26;
    // |h2| <= 2^25; from now on fits into int32 unchanged
    // |h6| <= 2^25; from now on fits into int32 unchanged
    // |h3| <= 1.51*2^58
    // |h7| <= 1.51*2^58

    carry[3] = (h3 + (1 << 24)) >> 25;
    h4 += carry[3];
    h3 -= carry[3] << 25;
    carry[7] = (h7 + (1 << 24)) >> 25;
    h8 += carry[7];
    h7 -= carry[7] << 25;
    // |h3| <= 2^24; from now on fits into int32 unchanged
    // |h7| <= 2^24; from now on fits into int32 unchanged
    // |h4| <= 1.52*2^33
    // |h8| <= 1.52*2^33

    carry[4] = (h4 + (1 << 25)) >> 26;
    h5 += carry[4];
    h4 -= carry[4] << 26;
    carry[8] = (h8 + (1 << 25)) >> 26;
    h9 += carry[8];
    h8 -= carry[8] << 26;
    // |h4| <= 2^25; from now on fits into int32 unchanged
    // |h8| <= 2^25; from now on fits into int32 unchanged
    // |h5| <= 1.01*2^24
    // |h9| <= 1.51*2^58

    carry[9] = (h9 + (1 << 24)) >> 25;
    h0 += carry[9] * 19;
    h9 -= carry[9] << 25;
    // |h9| <= 2^24; from now on fits into int32 unchanged
    // |h0| <= 1.8*2^37

    carry[0] = (h0 + (1 << 25)) >> 26;
    h1 += carry[0];
    h0 -= carry[0] << 26;
    // |h0| <= 2^25; from now on fits into int32 unchanged
    // |h1| <= 1.01*2^24

    dst[0] = (int32_t) h0;
    dst[1] = (int32_t) h1;
    dst[2] = (int32_t) h2;
    dst[3] = (int32_t) h3;
    dst[4] = (int32_t) h4;
    dst[5] = (int32_t) h5;
    dst[6] = (int32_t) h6;
    dst[7] = (int32_t) h7;
    dst[8] = (int32_t) h8;
    dst[9] = (int32_t) h9;
}

// taken from djb's original implementation
void field_invert(field_t dst, field_t src) {
    field_t z2, z9, z11, z2_5_0, z2_10_0, z2_20_0, z2_50_0, z2_100_0, t0, t1;
    int i;

    field_square(z2,src);           // 2
    field_square(t1,z2);            // 4
    field_square(t0,t1);            // 8
    field_mul(z9,t0,src);           // 9
    field_mul(z11,z9,z2);           // 11
    field_square(t0,z11);           // 22
    field_mul(z2_5_0,t0,z9);        // 2^5 - 2^0 = 31

    field_square(t0,z2_5_0);        // 2^6 - 2^1
    field_square(t1,t0);            // 2^7 - 2^2
    field_square(t0,t1);            // 2^8 - 2^3
    field_square(t1,t0);            // 2^9 - 2^4
    field_square(t0,t1);            // 2^10 - 2^5
    field_mul(z2_10_0,t0,z2_5_0);   // 2^10 - 2^0

    field_square(t0,z2_10_0);       // 2^11 - 2^1
    field_square(t1,t0);            // 2^12 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^20 - 2^10
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_20_0,t1,z2_10_0);  // 2^20 - 2^0

    field_square(t0,z2_20_0);       // 2^21 - 2^1
    field_square(t1,t0);            // 2^22 - 2^2
    for (i = 2;i < 20;i += 2) {     // 2^40 - 2^20
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_20_0);       // 2^40 - 2^0

    field_square(t1,t0);            // 2^41 - 2^1
    field_square(t0,t1);            // 2^42 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^50 - 2^10
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(z2_50_0,t0,z2_10_0);  // 2^50 - 2^0

    field_square(t0,z2_50_0);       // 2^51 - 2^1
    field_square(t1,t0);            // 2^52 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^100 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_100_0,t1,z2_50_0); // 2^100 - 2^0

    field_square(t1,z2_100_0);      // 2^101 - 2^1
    field_square(t0,t1);            // 2^102 - 2^2
    for (i = 2;i < 100;i += 2) {    // 2^200 - 2^100
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(t1,t0,z2_100_0);      // 2^200 - 2^0

    field_square(t0,t1);            // 2^201 - 2^1
    field_square(t1,t0);            // 2^202 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^250 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_50_0);       // 2^250 - 2^0

    field_square(t1,t0);            // 2^251 - 2^1
    field_square(t0,t1);            // 2^252 - 2^2
    field_square(t1,t0);            // 2^253 - 2^3
    field_square(t0,t1);            // 2^254 - 2^4
    field_square(t1,t0);            // 2^255 - 2^5
    field_mul(dst,t1,z11);          // 2^255 - 21
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_mul_a24(field_t dst, field_t src) {
    int64_t h0 = (int64_t) src[0] * a24;
    int64_t h1 = (int64_t) src[1] * a24;
    int64_t h2 = (int64_t) src[2] * a24;
    int64_t h3 = (int64_t) src[3] * a24;
    int64_t h4 = (int64_t) src[4] * a24;
    int64_t h5 = (int64_t) src[5] * a24;
    int64_t h6 = (int64_t) src[6] * a24;
    int64_t h7 = (int64_t) src[7] * a24;
    int64_t h8 = (int64_t) src[8] * a24;
    int64_t h9 = (int64_t) src[9] * a24;
    int64_t carry[10];

    carry[9] = (h9 + (1 << 24)) >> 25;
    h0 += carry[9] * 19;
    h9 -= carry[9] << 25;
    carry[1] = (h1 + (1 << 24)) >> 25;
    h2 += carry[1];
    h1 -= carry[1] << 25;
    carry[3] = (h3 + (1 << 24)) >> 25;
    h4 += carry[3];
    h3 -= carry[3] << 25;
    carry[5] = (h5 + (1 << 24)) >> 25;
    h6 += carry[5];
    h5 -= carry[5] << 25;
    carry[7] = (h7 + (1 << 24)) >> 25;
    h8 += carry[7];
    h7 -= carry[7] << 25;

    carry[0] = (h0 + (1 << 25)) >> 26;
    h1 += carry[0];
    h0 -= carry[0] << 26;
    carry[2] = (h2 + (1 << 25)) >> 26;
    h3 += carry[2];
    h2 -= carry[2] << 26;
    carry[4] = (h4 + (1 << 25)) >> 26;
    h5 += carry[4];
    h4 -= carry[4] << 26;
    carry[6] = (h6 + (1 << 25)) >> 26;
    h7 += carry[6];
    h6 -= carry[6] << 26;
    carry[8] = (h8 + (1 << 25)) >> 26;
    h9 += carry[8];
    h8 -= carry[8] << 26;

    dst[0] = (int32_t) h0;
    dst[1] = (int32_t) h1;
    dst[2] = (int32_t) h2;
    dst[3] = (int32_t) h3;
    dst[4] = (int32_t) h4;
    dst[5] = (int32_t) h5;
    dst[6] = (int32_t) h6;
    dst[7] = (int32_t) h7;
    dst[8] = (int32_t) h8;
    dst[9] = (int32_t) h9;
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
// see bernstein page 5, upper paragrpah for secret key definition
void decode_scalar(byte32_t dst, byte32_t src) {
    memcpy(dst, src, sizeof(byte32_t));
    dst[0] &= 248; // ensure multiple of 8 (248 = 1111 1000)
    dst[31] &= 127; // ensure biggest secret key <= 8*(2^251 - 1) = 2^254 - 1 (127 = 0111 1111)
    dst[31] |= 64; // ensure secret key offset of + 2^254 (64 = 0100 0000) 
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
int64_t load3(uint8_t *in) {
    int64_t r = 0;
    r |= ((int64_t) in[0]);
    r |= ((int64_t) in[1]) << 8;
    r |= ((int64_t) in[2]) << 16;
    return r;
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
int64_t load4(uint8_t *in) {
    int64_t r = 0;
    r |= ((int64_t) in[0]);
    r |= ((int64_t) in[1]) << 8;
    r |= ((int64_t) in[2]) << 16;
    r |= ((int64_t) in[3]) << 24;
    return r;
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void decode_point(field_t dst, byte32_t src) {
    int64_t h0 = load4(src);
    int64_t h1 = load3(src+4) << 6;
    int64_t h2 = load3(src+7) << 5;
    int64_t h3 = load3(src+10) << 3;
    int64_t h4 = load3(src+13) << 2;
    int64_t h5 = load4(src+16);
    int64_t h6 = load3(src+20) << 7;
    int64_t h7 = load3(src+23) << 5;
    int64_t h8 = load3(src+26) << 4;
    int64_t h9 = (load3(src+29) & 0x7fffff) << 2;

    int64_t carry[10] = { 0 };
    carry[9] = (h9 + (1<<24)) >> 25;
    h0 += carry[9] * 19;
    h9 -= carry[9] << 25;
    carry[1] = (h1 + (1<<24)) >> 25;
    h2 += carry[1];
    h1 -= carry[1] << 25;
    carry[3] = (h3 + (1<<24)) >> 25;
    h4 += carry[3];
    h3 -= carry[3] << 25;
    carry[5] = (h5 + (1<<24)) >> 25;
    h6 += carry[5];
    h5 -= carry[5] << 25;
    carry[7] = (h7 + (1<<24)) >> 25;
    h8 += carry[7];
    h7 -= carry[7] << 25;

    carry[0] = (h0 + (1<<25)) >> 26;
    h1 += carry[0];
    h0 -= carry[0] << 26;
    carry[2] = (h2 + (1<<25)) >> 26;
    h3 += carry[2];
    h2 -= carry[2] << 26;
    carry[4] = (h4 + (1<<25)) >> 26;
    h5 += carry[4];
    h4 -= carry[4] << 26;
    carry[6] = (h6 + (1<<25)) >> 26;
    h7 += carry[6];
    h6 -= carry[6] << 26;
    carry[8] = (h8 + (1<<25)) >> 26;
    h9 += carry[8];
    h8 -= carry[8] << 26;

    dst[0] = (int32_t) h0;
    dst[1] = (int32_t) h1;
    dst[2] = (int32_t) h2;
    dst[3] = (int32_t) h3;
    dst[4] = (int32_t) h4;
    dst[5] = (int32_t) h5;
    dst[6] = (int32_t) h6;
    dst[7] = (int32_t) h7;
    dst[8] = (int32_t) h8;
    dst[9] = (int32_t) h9;
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void encode_point(byte32_t dst, field_t src) {
    int32_t carry[10];

    int32_t q = (19*src[9] + (1 << 24)) >> 25;
    q = (src[0] + q) >> 26;
    q = (src[1] + q) >> 25;
    q = (src[2] + q) >> 26;
    q = (src[3] + q) >> 25;
    q = (src[4] + q) >> 26;
    q = (src[5] + q) >> 25;
    q = (src[6] + q) >> 26;
    q = (src[7] + q) >> 25;
    q = (src[8] + q) >> 26;
    q = (src[9] + q) >> 25;

    // Goal: Output h-(2^255-19)q, which is between 0 and 2^255-20.
    src[0] += 19 * q;
    // Goal: Output h-2^255 q, which is between 0 and 2^255-20.

    carry[0] = src[0] >> 26;
    src[1] += carry[0];
    src[0] -= carry[0] << 26;
    carry[1] = src[1] >> 25;
    src[2] += carry[1];
    src[1] -= carry[1] << 25;
    carry[2] = src[2] >> 26;
    src[3] += carry[2];
    src[2] -= carry[2] << 26;
    carry[3] = src[3] >> 25;
    src[4] += carry[3];
    src[3] -= carry[3] << 25;
    carry[4] = src[4] >> 26;
    src[5] += carry[4];
    src[4] -= carry[4] << 26;
    carry[5] = src[5] >> 25;
    src[6] += carry[5];
    src[5] -= carry[5] << 25;
    carry[6] = src[6] >> 26;
    src[7] += carry[6];
    src[6] -= carry[6] << 26;
    carry[7] = src[7] >> 25;
    src[8] += carry[7];
    src[7] -= carry[7] << 25;
    carry[8] = src[8] >> 26;
    src[9] += carry[8];
    src[8] -= carry[8] << 26;
    carry[9] = src[9] >> 25;
    src[9] -= carry[9] << 25;
    // h10 = carry9

    // Goal: Output h[0]+...+2^255 h10-2^255 q, which is between 0 and 2^255-20.
    // Have h[0]+...+2^230 h[9] between 0 and 2^255-1;
    // evidently 2^255 h10-2^255 q = 0.
    // Goal: Output h[0]+...+2^230 h[9].

    dst[0] = (uint8_t) (src[0] >> 0);
    dst[1] = (uint8_t) (src[0] >> 8);
    dst[2] = (uint8_t) (src[0] >> 16);
    dst[3] = (uint8_t) ((src[0] >> 24) | (src[1] << 2));
    dst[4] = (uint8_t) (src[1] >> 6);
    dst[5] = (uint8_t) (src[1] >> 14);
    dst[6] = (uint8_t) ((src[1] >> 22) | (src[2] << 3));
    dst[7] = (uint8_t) (src[2] >> 5);
    dst[8] = (uint8_t) (src[2] >> 13);
    dst[9] = (uint8_t) ((src[2] >> 21) | (src[3] << 5));
    dst[10] = (uint8_t) (src[3] >> 3);
    dst[11] = (uint8_t) (src[3] >> 11);
    dst[12] = (uint8_t) ((src[3] >> 19) | (src[4] << 6));
    dst[13] = (uint8_t) (src[4] >> 2);
    dst[14] = (uint8_t) (src[4] >> 10);
    dst[15] = (uint8_t) (src[4] >> 18);
    dst[16] = (uint8_t) (src[5] >> 0);
    dst[17] = (uint8_t) (src[5] >> 8);
    dst[18] = (uint8_t) (src[5] >> 16);
    dst[19] = (uint8_t) ((src[5] >> 24) | (src[6] << 1));
    dst[20] = (uint8_t) (src[6] >> 7);
    dst[21] = (uint8_t) (src[6] >> 15);
    dst[22] = (uint8_t) ((src[6] >> 23) | (src[7] << 3));
    dst[23] = (uint8_t) (src[7] >> 5);
    dst[24] = (uint8_t) (src[7] >> 13);
    dst[25] = (uint8_t) ((src[7] >> 21) | (src[8] << 4));
    dst[26] = (uint8_t) (src[8] >> 4);
    dst[27] = (uint8_t) (src[8] >> 12);
    dst[28] = (uint8_t) ((src[8] >> 20) | (src[9] << 6));
    dst[29] = (uint8_t) (src[9] >> 2);
    dst[30] = (uint8_t) (src[9] >> 10);
    dst[31] = (uint8_t) (src[9] >> 18);
}

// swap (a, b) with (b, a) iff swap == 1.
void cswap(int32_t swap, field_t a, field_t b) {
    swap = -swap;
    __m256i swapv = _mm256_set1_epi32(swap);

    __m256i av = _mm256_load_si256((__m256i *) a);
    __m256i bv = _mm256_load_si256((__m256i *) b);
    __m256i ab_xor = _mm256_xor_si256(av, bv);
    __m256i tv = _mm256_and_si256(swapv, ab_xor);
    av = _mm256_xor_si256(av, tv);
    bv = _mm256_xor_si256(bv, tv);
    _mm256_store_si256((__m256i *) a, av);
    _mm256_store_si256((__m256i *) b, bv);

    int32_t t8 = swap & (a[8] ^ b[8]);
    a[8] ^= t8;
    b[8] ^= t8;
    int32_t t9 = swap & (a[9] ^ b[9]);
    a[9] ^= t9;
    b[9] ^= t9;
}

// As per RFC 7748, Chapter 5
void curve_scalar_mult(field_t dst, byte32_t n, field_t P) {
    field_t x_1; memcpy(x_1, P, sizeof(field_t));
    field_t x_2 = { 1 };
    field_t z_2 = { 0 };
    field_t x_3; memcpy(x_3, P, sizeof(field_t));
    field_t z_3 = { 1 };
    int32_t swap = 0;

    for (int32_t i = 254; i >= 0; i--) {
        int32_t bit = (n[i / 8] >> (i & 7)) & 1;
        swap ^= bit;
        cswap(swap, x_2, x_3);
        cswap(swap, z_2, z_3);
        swap = bit;

        field_t A, AA, B, BB, E, C, D, DA, CB;
        field_t t0, t1;

        field_add(A, x_2, z_2);
        field_add(C, x_3, z_3);
        field_sub(B, x_2, z_2);
        field_sub(D, x_3, z_3);

        field_square(AA, A);
        field_square(BB, B);

        field_mul(DA, D, A);
        field_mul(CB, C, B);

        field_add(t0, DA, CB);
        field_sub(t1, DA, CB);

        field_square(x_3, t0);
        field_square(t1, t1);

        field_mul(z_3, t1, x_1);
        field_mul(x_2, AA, BB);

        field_sub(E, AA, BB);
        field_mul_a24(t0, E);

        field_add(t0, AA, t0);
        field_mul(z_2, E, t0);
    }

    cswap(swap, x_2, x_3);
    cswap(swap, z_2, z_3);
    field_invert(z_2, z_2);
    field_mul(dst, x_2, z_2);
}

int crypto_scalarmult(unsigned char * dst,
                      const unsigned char *n,
                      const unsigned char *P) {
    byte32_t scalar;
    decode_scalar(scalar, (uint8_t*) n);

    field_t base, result;
    decode_point(base, (uint8_t*) P);
    curve_scalar_mult(result, scalar, base);

    encode_point((uint8_t*) dst, result);
    return 0;
}

