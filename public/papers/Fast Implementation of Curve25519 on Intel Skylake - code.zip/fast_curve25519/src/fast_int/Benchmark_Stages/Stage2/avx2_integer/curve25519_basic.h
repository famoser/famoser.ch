#ifndef __CURVE25519_H
#define __CURVE25519_H

#include <inttypes.h>

typedef uint8_t byte32_t[32];
typedef int32_t field_t[16];

void field_add(field_t dst, field_t a, field_t b);
void field_sub(field_t dst, field_t a, field_t b);
void field_square(field_t dst, field_t src);
void field_mul(field_t dst, field_t a, field_t b);
void field_invert(field_t dst, field_t src);
void field_mul_a24(field_t dst, field_t src);

int64_t load3(uint8_t *in);
int64_t load4(uint8_t *in);
void decode_point(field_t dst, byte32_t src);
void encode_point(byte32_t dst, field_t src);
void decode_scalar(byte32_t dst, byte32_t src);

void cswap(int32_t swap, field_t a, field_t b);
void curve_scalar_mult(field_t dst, byte32_t n, field_t P);
void curve25519(byte32_t dst, byte32_t n, byte32_t P);

#endif /* __CURVE25519_H */
