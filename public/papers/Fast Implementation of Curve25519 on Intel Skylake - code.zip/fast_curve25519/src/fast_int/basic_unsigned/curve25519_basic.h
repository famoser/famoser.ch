#ifndef __CURVE25519_H
#define __CURVE25519_H

#include <inttypes.h>

#define limb uint32_t

typedef uint8_t byte32_t[32];
typedef limb field_t[10];

void field_add(field_t dst, field_t a, field_t b);
void field_sub(field_t dst, field_t a, field_t b);
void field_square(field_t dst, field_t src);
void field_mul(field_t dst, field_t a, field_t b);
void field_invert(field_t dst, field_t src);
void field_mul_a24(field_t dst, field_t src);

void decode_point(field_t dst, byte32_t src);
void encode_point(byte32_t dst, field_t src);
void decode_scalar(byte32_t dst, byte32_t src);

void cswap(limb swap, field_t a, field_t b);
void curve_scalar_mult(field_t dst, byte32_t n, field_t P);
void curve25519(byte32_t dst, byte32_t n, byte32_t P);

#endif /* __CURVE25519_H */
