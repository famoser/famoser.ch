#include <stdio.h>
#include <string.h>

#include "curve25519_basic.h"
//#include "crypto_scalarmult.h"

#define a24 121665


void field_add(field_t dst, field_t a, field_t b) {
    for (unsigned i = 0; i < 10; i++) {
        dst[i] = a[i] + b[i];
    }
}

void field_carry(field_t dst, uint64_t h[10]) {
    h[1] += h[0] >> 26; h[0] &= 0x3ffffff;
    h[2] += h[1] >> 25; h[1] &= 0x1ffffff;
    h[3] += h[2] >> 26; h[2] &= 0x3ffffff;
    h[4] += h[3] >> 25; h[3] &= 0x1ffffff;
    h[5] += h[4] >> 26; h[4] &= 0x3ffffff;
    h[6] += h[5] >> 25; h[5] &= 0x1ffffff;
    h[7] += h[6] >> 26; h[6] &= 0x3ffffff;
    h[8] += h[7] >> 25; h[7] &= 0x1ffffff;
    h[9] += h[8] >> 26; h[8] &= 0x3ffffff;
    h[0] += (h[9] >> 25) * 19; h[9] &= 0x1ffffff;
    h[1] += h[0] >> 26; h[0] &= 0x3ffffff;

    dst[0] = (limb) h[0];
	dst[1] = (limb) h[1];
	dst[2] = (limb) h[2];
	dst[3] = (limb) h[3];
	dst[4] = (limb) h[4];
	dst[5] = (limb) h[5];
	dst[6] = (limb) h[6];
	dst[7] = (limb) h[7];
	dst[8] = (limb) h[8];
	dst[9] = (limb) h[9];
}

void field_sub(field_t dst, field_t a, field_t b) {
    //(2^0 * (2^28-19*4) + 2^26 * (2^27-4) + 2^51 * (2^28-4) + 2^77 * (2^27-4) + 2^102 * (2^28-4) + 2^128 * (2^27-4) + 2^153 * (2^28-4) + 2^179 * (2^27-4) + 2^204 * (2^28-4) + 2^230 * (2^27-4)) /(2^255-19) = 8
    limb two28m76 = ((limb) 1 << 28) - 76;
    limb two28m4 = ((limb) 1 << 28) - 4;
    limb two27m4 = ((limb) 1 << 27) - 4;

    dst[0] = a[0] + two28m76 - b[0];
    dst[1] = a[1] + two27m4 - b[1];
    dst[2] = a[2] + two28m4 - b[2];
    dst[3] = a[3] + two27m4 - b[3];
    dst[4] = a[4] + two28m4 - b[4];
    dst[5] = a[5] + two27m4 - b[5];
    dst[6] = a[6] + two28m4 - b[6];
    dst[7] = a[7] + two27m4 - b[7];
    dst[8] = a[8] + two28m4 - b[8];
    dst[9] = a[9] + two27m4 - b[9];
}


// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_square(field_t dst, field_t src) {
    limb f0 = src[0];
	limb f1 = src[1];
	limb f2 = src[2];
	limb f3 = src[3];
	limb f4 = src[4];
	limb f5 = src[5];
	limb f6 = src[6];
	limb f7 = src[7];
	limb f8 = src[8];
	limb f9 = src[9];

	uint64_t f0_2 = (uint64_t) 2 * (uint64_t) f0;
	uint64_t f1_2 = (uint64_t) 2 * (uint64_t) f1;
	uint64_t f2_2 = (uint64_t) 2 * (uint64_t) f2;
	uint64_t f3_2 = (uint64_t) 2 * (uint64_t) f3;
	uint64_t f4_2 = (uint64_t) 2 * (uint64_t) f4;
	uint64_t f5_2 = (uint64_t) 2 * (uint64_t) f5;
	uint64_t f6_2 = (uint64_t) 2 * (uint64_t) f6;
	uint64_t f7_2 = (uint64_t) 2 * (uint64_t) f7;
	uint64_t f5_38 = (uint64_t) 38 * (uint64_t) f5; // 1.31*2^30
	uint64_t f6_19 = (uint64_t) 19 * (uint64_t) f6; // 1.31*2^30
	uint64_t f7_38 = (uint64_t) 38 * (uint64_t) f7; // 1.31*2^30
	uint64_t f8_19 = (uint64_t) 19 * (uint64_t) f8; // 1.31*2^30
	uint64_t f9_38 = (uint64_t) 38 * (uint64_t) f9; // 1.31*2^30
	uint64_t f0f0 = (uint64_t) f0 * (uint64_t) f0;
	uint64_t f0f1_2 = (uint64_t) f0_2 * (uint64_t) f1;
	uint64_t f0f2_2 = (uint64_t) f0_2 * (uint64_t) f2;
	uint64_t f0f3_2 = (uint64_t) f0_2 * (uint64_t) f3;
	uint64_t f0f4_2 = (uint64_t) f0_2 * (uint64_t) f4;
	uint64_t f0f5_2 = (uint64_t) f0_2 * (uint64_t) f5;
	uint64_t f0f6_2 = (uint64_t) f0_2 * (uint64_t) f6;
	uint64_t f0f7_2 = (uint64_t) f0_2 * (uint64_t) f7;
	uint64_t f0f8_2 = (uint64_t) f0_2 * (uint64_t) f8;
	uint64_t f0f9_2 = (uint64_t) f0_2 * (uint64_t) f9;
	uint64_t f1f1_2 = (uint64_t) f1_2 * (uint64_t) f1;
	uint64_t f1f2_2 = (uint64_t) f1_2 * (uint64_t) f2;
	uint64_t f1f3_4 = (uint64_t) f1_2 * (uint64_t) f3_2;
	uint64_t f1f4_2 = (uint64_t) f1_2 * (uint64_t) f4;
	uint64_t f1f5_4 = (uint64_t) f1_2 * (uint64_t) f5_2;
	uint64_t f1f6_2 = (uint64_t) f1_2 * (uint64_t) f6;
	uint64_t f1f7_4 = (uint64_t) f1_2 * (uint64_t) f7_2;
	uint64_t f1f8_2 = (uint64_t) f1_2 * (uint64_t) f8;
	uint64_t f1f9_76 = (uint64_t) f1_2 * (uint64_t) f9_38;
	uint64_t f2f2 = (uint64_t) f2 * (uint64_t) f2;
	uint64_t f2f3_2 = (uint64_t) f2_2 * (uint64_t) f3;
	uint64_t f2f4_2 = (uint64_t) f2_2 * (uint64_t) f4;
	uint64_t f2f5_2 = (uint64_t) f2_2 * (uint64_t) f5;
	uint64_t f2f6_2 = (uint64_t) f2_2 * (uint64_t) f6;
	uint64_t f2f7_2 = (uint64_t) f2_2 * (uint64_t) f7;
	uint64_t f2f8_38 = (uint64_t) f2_2 * (uint64_t) f8_19;
	uint64_t f2f9_38 = (uint64_t) f2 * (uint64_t) f9_38;
	uint64_t f3f3_2 = (uint64_t) f3_2 * (uint64_t) f3;
	uint64_t f3f4_2 = (uint64_t) f3_2 * (uint64_t) f4;
	uint64_t f3f5_4 = (uint64_t) f3_2 * (uint64_t) f5_2;
	uint64_t f3f6_2 = (uint64_t) f3_2 * (uint64_t) f6;
	uint64_t f3f7_76 = (uint64_t) f3_2 * (uint64_t) f7_38;
	uint64_t f3f8_38 = (uint64_t) f3_2 * (uint64_t) f8_19;
	uint64_t f3f9_76 = (uint64_t) f3_2 * (uint64_t) f9_38;
	uint64_t f4f4 = (uint64_t) f4 * (uint64_t) f4;
	uint64_t f4f5_2 = (uint64_t) f4_2 * (uint64_t) f5;
	uint64_t f4f6_38 = (uint64_t) f4_2 * (uint64_t) f6_19;
	uint64_t f4f7_38 = (uint64_t) f4 * (uint64_t) f7_38;
	uint64_t f4f8_38 = (uint64_t) f4_2 * (uint64_t) f8_19;
	uint64_t f4f9_38 = (uint64_t) f4 * (uint64_t) f9_38;
	uint64_t f5f5_38 = (uint64_t) f5 * (uint64_t) f5_38;
	uint64_t f5f6_38 = (uint64_t) f5_2 * (uint64_t) f6_19;
	uint64_t f5f7_76 = (uint64_t) f5_2 * (uint64_t) f7_38;
	uint64_t f5f8_38 = (uint64_t) f5_2 * (uint64_t) f8_19;
	uint64_t f5f9_76 = (uint64_t) f5_2 * (uint64_t) f9_38;
	uint64_t f6f6_19 = (uint64_t) f6 * (uint64_t) f6_19;
	uint64_t f6f7_38 = (uint64_t) f6 * (uint64_t) f7_38;
	uint64_t f6f8_38 = (uint64_t) f6_2 * (uint64_t) f8_19;
	uint64_t f6f9_38 = (uint64_t) f6 * (uint64_t) f9_38;
	uint64_t f7f7_38 = (uint64_t) f7 * (uint64_t) f7_38;
	uint64_t f7f8_38 = (uint64_t) f7_2 * (uint64_t) f8_19;
	uint64_t f7f9_76 = (uint64_t) f7_2 * (uint64_t) f9_38;
	uint64_t f8f8_19 = (uint64_t) f8 * (uint64_t) f8_19;
	uint64_t f8f9_38 = (uint64_t) f8 * (uint64_t) f9_38;
	uint64_t f9f9_38 = (uint64_t) f9 * (uint64_t) f9_38;
	uint64_t h0 = f0f0 + f1f9_76 + f2f8_38 + f3f7_76 + f4f6_38 + f5f5_38;
	uint64_t h1 = f0f1_2 + f2f9_38 + f3f8_38 + f4f7_38 + f5f6_38;
	uint64_t h2 = f0f2_2 + f1f1_2 + f3f9_76 + f4f8_38 + f5f7_76 + f6f6_19;
	uint64_t h3 = f0f3_2 + f1f2_2 + f4f9_38 + f5f8_38 + f6f7_38;
	uint64_t h4 = f0f4_2 + f1f3_4 + f2f2 + f5f9_76 + f6f8_38 + f7f7_38;
	uint64_t h5 = f0f5_2 + f1f4_2 + f2f3_2 + f6f9_38 + f7f8_38;
	uint64_t h6 = f0f6_2 + f1f5_4 + f2f4_2 + f3f3_2 + f7f9_76 + f8f8_19;
	uint64_t h7 = f0f7_2 + f1f6_2 + f2f5_2 + f3f4_2 + f8f9_38;
	uint64_t h8 = f0f8_2 + f1f7_4 + f2f6_2 + f3f5_4 + f4f4 + f9f9_38;
	uint64_t h9 = f0f9_2 + f1f8_2 + f2f7_2 + f3f6_2 + f4f5_2;

    uint64_t h[10] = {h0,h1,h2,h3,h4,h5,h6,h7,h8,h9};

    field_carry(dst, h);
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_mul(field_t dst, field_t a, field_t b) {
    limb f0 = a[0];
    limb f1 = a[1];
    limb f2 = a[2];
    limb f3 = a[3];
    limb f4 = a[4];
    limb f5 = a[5];
    limb f6 = a[6];
    limb f7 = a[7];
    limb f8 = a[8];
    limb f9 = a[9];
    limb g0 = b[0];
    limb g1 = b[1];
    limb g2 = b[2];
    limb g3 = b[3];
    limb g4 = b[4];
    limb g5 = b[5];
    limb g6 = b[6];
    limb g7 = b[7];
    limb g8 = b[8];
    limb g9 = b[9];

    uint64_t g1_19 = (uint64_t) 19 * (uint64_t) g1; // 1.4*2^29;
    uint64_t g2_19 = (uint64_t) 19 * (uint64_t) g2; // 1.4*2^30; still ok
    uint64_t g3_19 = (uint64_t) 19 * (uint64_t) g3;
    uint64_t g4_19 = (uint64_t) 19 * (uint64_t) g4;
    uint64_t g5_19 = (uint64_t) 19 * (uint64_t) g5;
    uint64_t g6_19 = (uint64_t) 19 * (uint64_t) g6;
    uint64_t g7_19 = (uint64_t) 19 * (uint64_t) g7;
    uint64_t g8_19 = (uint64_t) 19 * (uint64_t) g8;
    uint64_t g9_19 = (uint64_t) 19 * (uint64_t) g9;
    uint64_t f1_2 = (uint64_t) 2 * (uint64_t) f1;
    uint64_t f3_2 = (uint64_t) 2 * (uint64_t) f3;
    uint64_t f5_2 = (uint64_t) 2 * (uint64_t) f5;
    uint64_t f7_2 = (uint64_t) 2 * (uint64_t) f7;
    uint64_t f9_2 = (uint64_t) 2 * (uint64_t) f9;
    uint64_t f0g0 = (uint64_t) f0 * (uint64_t) g0;
    uint64_t f0g1 = (uint64_t) f0 * (uint64_t) g1;
    uint64_t f0g2 = (uint64_t) f0 * (uint64_t) g2;
    uint64_t f0g3 = (uint64_t) f0 * (uint64_t) g3;
    uint64_t f0g4 = (uint64_t) f0 * (uint64_t) g4;
    uint64_t f0g5 = (uint64_t) f0 * (uint64_t) g5;
    uint64_t f0g6 = (uint64_t) f0 * (uint64_t) g6;
    uint64_t f0g7 = (uint64_t) f0 * (uint64_t) g7;
    uint64_t f0g8 = (uint64_t) f0 * (uint64_t) g8;
    uint64_t f0g9 = (uint64_t) f0 * (uint64_t) g9;
    uint64_t f1g0 = (uint64_t) f1 * (uint64_t) g0;
    uint64_t f1g1_2 = (uint64_t) f1_2 * (uint64_t) g1;
    uint64_t f1g2 = (uint64_t) f1 * (uint64_t) g2;
    uint64_t f1g3_2 = (uint64_t) f1_2 * (uint64_t) g3;
    uint64_t f1g4 = (uint64_t) f1 * (uint64_t) g4;
    uint64_t f1g5_2 = (uint64_t) f1_2 * (uint64_t) g5;
    uint64_t f1g6 = (uint64_t) f1 * (uint64_t) g6;
    uint64_t f1g7_2 = (uint64_t) f1_2 * (uint64_t) g7;
    uint64_t f1g8 = (uint64_t) f1 * (uint64_t) g8;
    uint64_t f1g9_38 = (uint64_t) f1_2 * (uint64_t) g9_19;
    uint64_t f2g0 = (uint64_t) f2 * (uint64_t) g0;
    uint64_t f2g1 = (uint64_t) f2 * (uint64_t) g1;
    uint64_t f2g2 = (uint64_t) f2 * (uint64_t) g2;
    uint64_t f2g3 = (uint64_t) f2 * (uint64_t) g3;
    uint64_t f2g4 = (uint64_t) f2 * (uint64_t) g4;
    uint64_t f2g5 = (uint64_t) f2 * (uint64_t) g5;
    uint64_t f2g6 = (uint64_t) f2 * (uint64_t) g6;
    uint64_t f2g7 = (uint64_t) f2 * (uint64_t) g7;
    uint64_t f2g8_19 = (uint64_t) f2 * (uint64_t) g8_19;
    uint64_t f2g9_19 = (uint64_t) f2 * (uint64_t) g9_19;
    uint64_t f3g0 = (uint64_t) f3 * (uint64_t) g0;
    uint64_t f3g1_2 = (uint64_t) f3_2 * (uint64_t) g1;
    uint64_t f3g2 = (uint64_t) f3 * (uint64_t) g2;
    uint64_t f3g3_2 = (uint64_t) f3_2 * (uint64_t) g3;
    uint64_t f3g4 = (uint64_t) f3 * (uint64_t) g4;
    uint64_t f3g5_2 = (uint64_t) f3_2 * (uint64_t) g5;
    uint64_t f3g6 = (uint64_t) f3 * (uint64_t) g6;
    uint64_t f3g7_38 = (uint64_t) f3_2 * (uint64_t) g7_19;
    uint64_t f3g8_19 = (uint64_t) f3 * (uint64_t) g8_19;
    uint64_t f3g9_38 = (uint64_t) f3_2 * (uint64_t) g9_19;
    uint64_t f4g0 = (uint64_t) f4 * (uint64_t) g0;
    uint64_t f4g1 = (uint64_t) f4 * (uint64_t) g1;
    uint64_t f4g2 = (uint64_t) f4 * (uint64_t) g2;
    uint64_t f4g3 = (uint64_t) f4 * (uint64_t) g3;
    uint64_t f4g4 = (uint64_t) f4 * (uint64_t) g4;
    uint64_t f4g5 = (uint64_t) f4 * (uint64_t) g5;
    uint64_t f4g6_19 = (uint64_t) f4 * (uint64_t) g6_19;
    uint64_t f4g7_19 = (uint64_t) f4 * (uint64_t) g7_19;
    uint64_t f4g8_19 = (uint64_t) f4 * (uint64_t) g8_19;
    uint64_t f4g9_19 = (uint64_t) f4 * (uint64_t) g9_19;
    uint64_t f5g0 = (uint64_t) f5 * (uint64_t) g0;
    uint64_t f5g1_2 = (uint64_t) f5_2 * (uint64_t) g1;
    uint64_t f5g2 = (uint64_t) f5 * (uint64_t) g2;
    uint64_t f5g3_2 = (uint64_t) f5_2 * (uint64_t) g3;
    uint64_t f5g4 = (uint64_t) f5 * (uint64_t) g4;
    uint64_t f5g5_38 = (uint64_t) f5_2 * (uint64_t) g5_19;
    uint64_t f5g6_19 = (uint64_t) f5 * (uint64_t) g6_19;
    uint64_t f5g7_38 = (uint64_t) f5_2 * (uint64_t) g7_19;
    uint64_t f5g8_19 = (uint64_t) f5 * (uint64_t) g8_19;
    uint64_t f5g9_38 = (uint64_t) f5_2 * (uint64_t) g9_19;
    uint64_t f6g0 = (uint64_t) f6 * (uint64_t) g0;
    uint64_t f6g1 = (uint64_t) f6 * (uint64_t) g1;
    uint64_t f6g2 = (uint64_t) f6 * (uint64_t) g2;
    uint64_t f6g3 = (uint64_t) f6 * (uint64_t) g3;
    uint64_t f6g4_19 = (uint64_t) f6 * (uint64_t) g4_19;
    uint64_t f6g5_19 = (uint64_t) f6 * (uint64_t) g5_19;
    uint64_t f6g6_19 = (uint64_t) f6 * (uint64_t) g6_19;
    uint64_t f6g7_19 = (uint64_t) f6 * (uint64_t) g7_19;
    uint64_t f6g8_19 = (uint64_t) f6 * (uint64_t) g8_19;
    uint64_t f6g9_19 = (uint64_t) f6 * (uint64_t) g9_19;
    uint64_t f7g0 = (uint64_t) f7 * (uint64_t) g0;
    uint64_t f7g1_2 = (uint64_t) f7_2 * (uint64_t) g1;
    uint64_t f7g2 = (uint64_t) f7 * (uint64_t) g2;
    uint64_t f7g3_38 = (uint64_t) f7_2 * (uint64_t) g3_19;
    uint64_t f7g4_19 = (uint64_t) f7 * (uint64_t) g4_19;
    uint64_t f7g5_38 = (uint64_t) f7_2 * (uint64_t) g5_19;
    uint64_t f7g6_19 = (uint64_t) f7 * (uint64_t) g6_19;
    uint64_t f7g7_38 = (uint64_t) f7_2 * (uint64_t) g7_19;
    uint64_t f7g8_19 = (uint64_t) f7 * (uint64_t) g8_19;
    uint64_t f7g9_38 = (uint64_t) f7_2 * (uint64_t) g9_19;
    uint64_t f8g0 = (uint64_t) f8 * (uint64_t) g0;
    uint64_t f8g1 = (uint64_t) f8 * (uint64_t) g1;
    uint64_t f8g2_19 = (uint64_t) f8 * (uint64_t) g2_19;
    uint64_t f8g3_19 = (uint64_t) f8 * (uint64_t) g3_19;
    uint64_t f8g4_19 = (uint64_t) f8 * (uint64_t) g4_19;
    uint64_t f8g5_19 = (uint64_t) f8 * (uint64_t) g5_19;
    uint64_t f8g6_19 = (uint64_t) f8 * (uint64_t) g6_19;
    uint64_t f8g7_19 = (uint64_t) f8 * (uint64_t) g7_19;
    uint64_t f8g8_19 = (uint64_t) f8 * (uint64_t) g8_19;
    uint64_t f8g9_19 = (uint64_t) f8 * (uint64_t) g9_19;
    uint64_t f9g0 = (uint64_t) f9 * (uint64_t) g0;
    uint64_t f9g1_38 = (uint64_t) f9_2 * (uint64_t) g1_19;
    uint64_t f9g2_19 = (uint64_t) f9 * (uint64_t) g2_19;
    uint64_t f9g3_38 = (uint64_t) f9_2 * (uint64_t) g3_19;
    uint64_t f9g4_19 = (uint64_t) f9 * (uint64_t) g4_19;
    uint64_t f9g5_38 = (uint64_t) f9_2 * (uint64_t) g5_19;
    uint64_t f9g6_19 = (uint64_t) f9 * (uint64_t) g6_19;
    uint64_t f9g7_38 = (uint64_t) f9_2 * (uint64_t) g7_19;
    uint64_t f9g8_19 = (uint64_t) f9 * (uint64_t) g8_19;
    uint64_t f9g9_38 = (uint64_t) f9_2 * (uint64_t) g9_19;

    uint64_t h0 = f0g0 + f1g9_38 + f2g8_19 + f3g7_38 + f4g6_19 + f5g5_38 + f6g4_19 + f7g3_38 + f8g2_19 + f9g1_38;
    uint64_t h1 = f0g1 + f1g0 + f2g9_19 + f3g8_19 + f4g7_19 + f5g6_19 + f6g5_19 + f7g4_19 + f8g3_19 + f9g2_19;
    uint64_t h2 = f0g2 + f1g1_2 + f2g0 + f3g9_38 + f4g8_19 + f5g7_38 + f6g6_19 + f7g5_38 + f8g4_19 + f9g3_38;
    uint64_t h3 = f0g3 + f1g2 + f2g1 + f3g0 + f4g9_19 + f5g8_19 + f6g7_19 + f7g6_19 + f8g5_19 + f9g4_19;
    uint64_t h4 = f0g4 + f1g3_2 + f2g2 + f3g1_2 + f4g0 + f5g9_38 + f6g8_19 + f7g7_38 + f8g6_19 + f9g5_38;
    uint64_t h5 = f0g5 + f1g4 + f2g3 + f3g2 + f4g1 + f5g0 + f6g9_19 + f7g8_19 + f8g7_19 + f9g6_19;
    uint64_t h6 = f0g6 + f1g5_2 + f2g4 + f3g3_2 + f4g2 + f5g1_2 + f6g0 + f7g9_38 + f8g8_19 + f9g7_38;
    uint64_t h7 = f0g7 + f1g6 + f2g5 + f3g4 + f4g3 + f5g2 + f6g1 + f7g0 + f8g9_19 + f9g8_19;
    uint64_t h8 = f0g8 + f1g7_2 + f2g6 + f3g5_2 + f4g4 + f5g3_2 + f6g2 + f7g1_2 + f8g0 + f9g9_38;
    uint64_t h9 = f0g9 + f1g8 + f2g7 + f3g6 + f4g5 + f5g4 + f6g3 + f7g2 + f8g1 + f9g0;

    uint64_t h[10] = {h0,h1,h2,h3,h4,h5,h6,h7,h8,h9};

    field_carry(dst, h);
}

// taken from djb's original implementation
void field_invert(field_t dst, field_t src) {
    field_t z2, z9, z11, z2_5_0, z2_10_0, z2_20_0, z2_50_0, z2_100_0, t0, t1;
    int i;

    field_square(z2,src);           // 2
    field_square(t1,z2);            // 4
    field_square(t0,t1);            // 8
    field_mul(z9,t0,src);           // 9
    field_mul(z11,z9,z2);           // 11
    field_square(t0,z11);           // 22
    field_mul(z2_5_0,t0,z9);        // 2^5 - 2^0 = 31

    field_square(t0,z2_5_0);        // 2^6 - 2^1
    field_square(t1,t0);            // 2^7 - 2^2
    field_square(t0,t1);            // 2^8 - 2^3
    field_square(t1,t0);            // 2^9 - 2^4
    field_square(t0,t1);            // 2^10 - 2^5
    field_mul(z2_10_0,t0,z2_5_0);   // 2^10 - 2^0

    field_square(t0,z2_10_0);       // 2^11 - 2^1
    field_square(t1,t0);            // 2^12 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^20 - 2^10
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_20_0,t1,z2_10_0);  // 2^20 - 2^0

    field_square(t0,z2_20_0);       // 2^21 - 2^1
    field_square(t1,t0);            // 2^22 - 2^2
    for (i = 2;i < 20;i += 2) {     // 2^40 - 2^20
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_20_0);       // 2^40 - 2^0

    field_square(t1,t0);            // 2^41 - 2^1
    field_square(t0,t1);            // 2^42 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^50 - 2^10
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(z2_50_0,t0,z2_10_0);  // 2^50 - 2^0

    field_square(t0,z2_50_0);       // 2^51 - 2^1
    field_square(t1,t0);            // 2^52 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^100 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_100_0,t1,z2_50_0); // 2^100 - 2^0

    field_square(t1,z2_100_0);      // 2^101 - 2^1
    field_square(t0,t1);            // 2^102 - 2^2
    for (i = 2;i < 100;i += 2) {    // 2^200 - 2^100
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(t1,t0,z2_100_0);      // 2^200 - 2^0

    field_square(t0,t1);            // 2^201 - 2^1
    field_square(t1,t0);            // 2^202 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^250 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_50_0);       // 2^250 - 2^0

    field_square(t1,t0);            // 2^251 - 2^1
    field_square(t0,t1);            // 2^252 - 2^2
    field_square(t1,t0);            // 2^253 - 2^3
    field_square(t0,t1);            // 2^254 - 2^4
    field_square(t1,t0);            // 2^255 - 2^5
    field_mul(dst,t1,z11);          // 2^255 - 21
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void field_mul_a24(field_t dst, field_t src) {
    uint64_t h0 = (uint64_t) src[0] * (uint64_t) a24;
    uint64_t h1 = (uint64_t) src[1] * (uint64_t) a24;
    uint64_t h2 = (uint64_t) src[2] * (uint64_t) a24;
    uint64_t h3 = (uint64_t) src[3] * (uint64_t) a24;
    uint64_t h4 = (uint64_t) src[4] * (uint64_t) a24;
    uint64_t h5 = (uint64_t) src[5] * (uint64_t) a24;
    uint64_t h6 = (uint64_t) src[6] * (uint64_t) a24;
    uint64_t h7 = (uint64_t) src[7] * (uint64_t) a24;
    uint64_t h8 = (uint64_t) src[8] * (uint64_t) a24;
    uint64_t h9 = (uint64_t) src[9] * (uint64_t) a24;
    uint64_t h[10] = {h0,h1,h2,h3,h4,h5,h6,h7,h8,h9};

    field_carry(dst, h);
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
// see bernstein page 5, upper paragrpah for secret key definition
void decode_scalar(byte32_t dst, byte32_t src) {
    memcpy(dst, src, sizeof(byte32_t));
    dst[0] &= 248; // ensure multiple of 8 (248 = 1111 1000)
    dst[31] &= 127; // ensure biggest secret key <= 8*(2^251 - 1) = 2^254 - 1 (127 = 0111 1111)
    dst[31] |= 64; // ensure secret key offset of + 2^254 (64 = 0100 0000) 
}

void decode_point(field_t dst, byte32_t src) {
    limb h0;
    limb h1;
    limb h2;
    limb h3;
    limb h4;
    limb h5;
    limb h6;
    limb h7;
    limb h8;
    limb h9;

    h0 = (limb) src[0];
    h0 += (limb) src[1] << 8;
    h0 += (limb) src[2] << 16;
    h0 += ((limb) src[3] & 3) << 24; // take the first 2 bits

    h1 = (limb) src[3] >> 2;
    h1 += (limb) src[4] << 6;
    h1 += (limb) src[5] << 14;
    h1 += ((limb) src[6] & 7) << 22; // take the first 3 bits

    h2 = (limb) src[6] >> 3;
    h2 += (limb) src[7] << 5;
    h2 += (limb) src[8] << 13;
    h2 += ((limb) src[9] & 31) << 21; // take the first 5 bits

    h3 = (limb) src[9] >> 5;
    h3 += (limb) src[10] << 3;
    h3 += (limb) src[11] << 11;
    h3 += ((limb) src[12] & 63) << 19; // take the first 6 bits

    h4 = (limb) src[12] >> 6;
    h4 += (limb) src[13] << 2;
    h4 += (limb) src[14] << 10;
    h4 += ((limb) src[15] & 255) << 18; // take the first 8 bits

    h5 = (limb) src[16];
    h5 += (limb) src[17] << 8;
    h5 += (limb) src[18] << 16;
    h5 += ((limb) src[19] & 1) << 24; // take the first 1 bits

    h6 = (limb) src[19] >> 1;
    h6 += (limb) src[20] << 7;
    h6 += (limb) src[21] << 15;
    h6 += ((limb) src[22] & 7) << 23; // take the first 3 bits

    h7 = (limb) src[22] >> 3;
    h7 += (limb) src[23] << 5;
    h7 += (limb) src[24] << 13;
    h7 += ((limb) src[25] & 15) << 21; // take the first 4 bits

    h8 = (limb) src[25] >> 4;
    h8 += (limb) src[26] << 4;
    h8 += (limb) src[27] << 12;
    h8 += ((limb) src[28] & 63) << 20; // take the first 6 bits

    h9 = (limb) src[28] >> 6;
    h9 += (limb) src[29] << 2;
    h9 += (limb) src[30] << 10;
    h9 += ((limb) src[31] & 127) << 18; // take the first 7 bits
                                      // mask out the msb, because rfc7748 says so.

    
    uint64_t h[10] = {h0,h1,h2,h3,h4,h5,h6,h7,h8,h9};
    field_carry(dst, h);
}

void encode_point(byte32_t dst, field_t src) {

    limb q = (19*src[9] + ((limb)1 << 24)) >> 25;
    q = (src[0] + q) >> 26;
    q = (src[1] + q) >> 25;
    q = (src[2] + q) >> 26;
    q = (src[3] + q) >> 25;
    q = (src[4] + q) >> 26;
    q = (src[5] + q) >> 25;
    q = (src[6] + q) >> 26;
    q = (src[7] + q) >> 25;
    q = (src[8] + q) >> 26;
    q = (src[9] + q) >> 25;

    // Goal: Output h-(2^255-19)q, which is between 0 and 2^255-20.
    src[0] += 19 * q;
    // Goal: Output h-2^255 q, which is between 0 and 2^255-20.


    src[1] += src[0] >> 26; src[0] &= 0x3ffffff;
    src[2] += src[1] >> 25; src[1] &= 0x1ffffff;
    src[3] += src[2] >> 26; src[2] &= 0x3ffffff;
    src[4] += src[3] >> 25; src[3] &= 0x1ffffff;
    src[5] += src[4] >> 26; src[4] &= 0x3ffffff;
    src[6] += src[5] >> 25; src[5] &= 0x1ffffff;
    src[7] += src[6] >> 26; src[6] &= 0x3ffffff;
    src[8] += src[7] >> 25; src[7] &= 0x1ffffff;
    src[9] += src[8] >> 26; src[8] &= 0x3ffffff;
    src[0] += (src[9] >> 25) * 19; src[9] &= 0x1ffffff;
    src[1] += src[0] >> 26; src[0] &= 0x3ffffff;


    // Goal: Output h[0]+...+2^255 h10-2^255 q, which is between 0 and 2^255-20.
    // Have h[0]+...+2^230 h[9] between 0 and 2^255-1;
    // evidently 2^255 h10-2^255 q = 0.
    // Goal: Output h[0]+...+2^230 h[9].

    dst[0] = (uint8_t) (src[0] >> 0);
    dst[1] = (uint8_t) (src[0] >> 8);
    dst[2] = (uint8_t) (src[0] >> 16);
    dst[3] = (uint8_t) ((src[0] >> 24) | (src[1] << 2));
    dst[4] = (uint8_t) (src[1] >> 6);
    dst[5] = (uint8_t) (src[1] >> 14);
    dst[6] = (uint8_t) ((src[1] >> 22) | (src[2] << 3));
    dst[7] = (uint8_t) (src[2] >> 5);
    dst[8] = (uint8_t) (src[2] >> 13);
    dst[9] = (uint8_t) ((src[2] >> 21) | (src[3] << 5));
    dst[10] = (uint8_t) (src[3] >> 3);
    dst[11] = (uint8_t) (src[3] >> 11);
    dst[12] = (uint8_t) ((src[3] >> 19) | (src[4] << 6));
    dst[13] = (uint8_t) (src[4] >> 2);
    dst[14] = (uint8_t) (src[4] >> 10);
    dst[15] = (uint8_t) (src[4] >> 18);
    dst[16] = (uint8_t) (src[5] >> 0);
    dst[17] = (uint8_t) (src[5] >> 8);
    dst[18] = (uint8_t) (src[5] >> 16);
    dst[19] = (uint8_t) ((src[5] >> 24) | (src[6] << 1));
    dst[20] = (uint8_t) (src[6] >> 7);
    dst[21] = (uint8_t) (src[6] >> 15);
    dst[22] = (uint8_t) ((src[6] >> 23) | (src[7] << 3));
    dst[23] = (uint8_t) (src[7] >> 5);
    dst[24] = (uint8_t) (src[7] >> 13);
    dst[25] = (uint8_t) ((src[7] >> 21) | (src[8] << 4));
    dst[26] = (uint8_t) (src[8] >> 4);
    dst[27] = (uint8_t) (src[8] >> 12);
    dst[28] = (uint8_t) ((src[8] >> 20) | (src[9] << 6));
    dst[29] = (uint8_t) (src[9] >> 2);
    dst[30] = (uint8_t) (src[9] >> 10);
    dst[31] = (uint8_t) (src[9] >> 18);
}

// swap (a, b) with (b, a) iff swap == 1.
void cswap(limb swap, field_t a, field_t b) {
    swap = -swap;
    for (unsigned i = 0; i < 10; i++) {
        limb t = swap & (a[i] ^ b[i]);
        a[i] ^= t;
        b[i] ^= t;
    }
}

// As per RFC 7748, Chapter 5
void curve_scalar_mult(field_t dst, byte32_t n, field_t P) {
    field_t x_1; memcpy(x_1, P, sizeof(field_t));
    field_t x_2 = { 1 };
    field_t z_2 = { 0 };
    field_t x_3; memcpy(x_3, P, sizeof(field_t));
    field_t z_3 = { 1 };
    limb swap = 0;

    for (int32_t i = 254; i >= 0; i--) {
        limb bit = (n[i / 8] >> (i & 7)) & 1;
        swap ^= bit;
        cswap(swap, x_2, x_3);
        cswap(swap, z_2, z_3);
        swap = bit;

        field_t A, AA, B, BB, E, C, D, DA, CB;
        field_t t0;

        field_add(A, x_2, z_2);     // A = x_2 + z_2
        field_square(AA, A);        // AA = A^2
        field_sub(B, x_2, z_2);     // B = x_2 - z_2
        field_square(BB, B);        // BB = B^2
        field_sub(E, AA, BB);       // E = AA - BB
        field_add(C, x_3, z_3);     // C = x_3 + z_3
        field_sub(D, x_3, z_3);     // D = x_3 - z_3
        field_mul(DA, D, A);        // DA = D * A
        field_mul(CB, C, B);        // CB = C * B
        field_add(t0, DA, CB);      // x_3 = (DA + CB)^2
        field_square(x_3, t0);
        field_sub(t0, DA, CB);      // z_3 = x_1 * (DA - CB)^2
        field_square(t0, t0);
        field_mul(z_3, t0, x_1);
        field_mul(x_2, AA, BB);     // x_2 = AA * BB
        field_mul_a24(t0, E);       // z_2 = E * (AA + a24 * E)
        field_add(t0, AA, t0);
        field_mul(z_2, E, t0);
    }

    cswap(swap, x_2, x_3);
    cswap(swap, z_2, z_3);
    field_invert(z_2, z_2);         // z_2 = z_2 ^-1
    field_mul(dst, x_2, z_2);       // dst = x_2 * z_2
}

void curve25519(byte32_t dst, byte32_t n, byte32_t P) {
    byte32_t scalar;
    decode_scalar(scalar, n);

    field_t base, result;
    decode_point(base, P);
    curve_scalar_mult(result, scalar, base);

    encode_point(dst, result);
}

int crypto_scalarmult(unsigned char * dst,
                      const unsigned char *n,
                      const unsigned char *P) {
    curve25519((uint8_t *) dst, (uint8_t *) n, (uint8_t *) P);
    return 0;
}

