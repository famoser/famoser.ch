#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <assert.h>
#include <math.h>
#include <immintrin.h>
#include <inttypes.h>

#include "debug.c"

// choose a datatypes suitably big according to the bits per limp
#define field_entry_t int32_t

// choose a datatype suitable big for multiplying two limps together
#define field_entry_mul_t int64_t

// choose the datatype of your input
#define input_t uint8_t

typedef input_t byte32_t[32] __attribute__((aligned(32)));
typedef field_entry_t field_t[10] __attribute__((aligned(32)));
typedef field_entry_mul_t field_packed_t[20] __attribute__((aligned(32)));

/*[[[cog
import cog;


def modulo_after_multiplication(dest_name, src_name):
    cog.outl(f'__m256i Zi_times_16;')
    cog.outl(f'__m256i Zi_times_2;')
    cog.outl(f'__m256i Zi_times_19;')
    
    for i in range(0, 5):
        cog.outl(f'Zi_times_16 = _mm256_slli_epi64({src_name}[{i + 5}], 4);')
        cog.outl(f'Zi_times_2 = _mm256_slli_epi64({src_name}[{i + 5}], 1);')
        cog.outl(f'Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);')
        cog.outl(f'{dest_name}[{i}] = _mm256_add_epi64(Zi_times_19, {src_name}[{i + 5}]);')
        cog.outl(f'{dest_name}[{i}] = _mm256_add_epi64({dest_name}[{i}], {src_name}[{i}]);')

]]]*/
//[[[end]]]

void field_square_avx_parallel(__m256i res[5], __m256i AB_v[5]){
    __m256i vec_0101 = _mm256_set_epi64x(1,0,1,0);
    __m256i vec_0000 = _mm256_setzero_si256();
    
    __m256i Z[10];
    __m256i U[10];
    __m256i V[10];
    
    for (int i = 0; i < 5; ++i){
        // U2i <- (A,B)i
        U[2*i] = AB_v[i]; // [0, a_2i+1, 0, a_2i, 0, b_2i+1, 0, b_2i]

        // U2i+1 <- ALIGN((A,B)i+1mod5, (A,B)i)
        U[2*i + 1] = _mm256_blend_epi32(AB_v[(i + 1) % 5], AB_v[i], 0b00110011); // [0, a_2i+1, 0, a_2i+2, 0, b_2i+1, 0, b_2i+2]
        U[2*i + 1] = _mm256_permute4x64_epi64 (U[2*i + 1], 0b10110001); //shuffle [2301] // [0, a_2i+2, 0, a_2i+1, 0, b_2i+2, 0, b_2i+1]
    
        // U2i+1 <- SHLV(U2i+1, [0,1,0,1])
        U[2*i + 1] = _mm256_sllv_epi64(U[2*i + 1],vec_0101); // [0, a_2i+2, 0, 2*a_2i+1, 0, b_2i+2, 0, 2*b_2i+1]

        // V2i <- SHUF((A,B)i, 0)
        V[2*i] = _mm256_shuffle_epi32(AB_v[i], 0b11101110); // [0, a_2i, 0, a_2i, 0, b_2i, 0, b_2i]

        // V2i+1 <- SHUF((A,B)i, 1)
        V[2*i+1] = _mm256_shuffle_epi32(AB_v[i], 0b01000100); // [0, a_2i+1, 0, a_2i+1, 0, b_2i+1, 0, b_2i+1]
    }
    print_m256i(U[0], "U[0]");
    print_m256i(U[1], "U[1]");
    print_m256i(U[2], "U[2]");
    print_m256i(U[3], "U[3]");
    print_m256i(V[0], "V[0]");
    print_m256i(V[1], "V[1]");
    print_m256i(V[2], "V[2]");
    print_m256i(V[3], "V[3]");
    print_newline();

    for (int i = 0; i < 5; i++) {
        // T <- MUL(Ui, Vi)
        __m256i T = _mm256_mul_epi32(U[i], V[i]); // [a_i+1*a_i, a_i*a_i, b_i+1*b_i, b_i*b_i]
        print_m256i(T, "T");

        // Zi <- BLEND(T, [0,0,0,0], 1010)
        Z[i] = _mm256_blend_epi32(T, vec_0000, 0b00110011); // [0, a_i*a_i, 0, b_i*b_i]
        print_m256i_array_entry(Z, i, "Z");

        // W <- BLEND(T, [0,0,0,0], 0101)
        __m256i W = _mm256_blend_epi32(T, vec_0000, 0b11001100); // [a_i+1*a_i, 0, a_i+1*a_i, 0]
        print_m256i(W, "W");

        for (int j = 1; j <= i; j++) {
            // t <- i - j mod 10
            int t = ((i-j)%10+10)%10;
            int index = i + j;

            // W <- ADD(W, MUL(U_j, V_t))
            // print("W = W + U[%i] * V[%i]\n", index, t);
            W = _mm256_add_epi64(W, _mm256_mul_epi32(U[index], V[t])); 
            print_m256i(W, "W");
        }

        // Z_i <- ADD(Z_i, SHL(W, 1))
        Z[i] = _mm256_add_epi64(Z[i], _mm256_slli_epi64(W, 1));
        print_m256i_array_entry(Z, i, "Z");

        // S <- MUL(U_i+5, V_i+5)
        __m256i S = _mm256_mul_epi32(U[i+5], V[i+5]); // [a_i+6*a_i+5, a_i+5*a_i+5, b_i+6*b_i+5, b_i+5*b_i+5]
        print_m256i(S, "S");

        // Z_i+5 <- BLEND(S, [0,0,0,0], 1010)
        Z[i+5] = _mm256_blend_epi32(S, vec_0000, 0b00110011); // [0, a_i+5*a_i+5, 0, a_i+5*a_i+5]
        print_m256i_array_entry(Z, i+5, "Z");

        // X <- [0,0,0,0]
        __m256i X = _mm256_setzero_si256();

        for (int j = i+1; j < 5; j++) {
            // t <- i - j mod 10
            int t = ((i-j)%10+10)%10;
            int index = j+i;

            // X <- ADD(X, MUL(U_j, V_t))
            // printf("X = X + U[%i] * V[%i]\n", index, t);
            X = _mm256_add_epi64(X, _mm256_mul_epi32(U[index], V[t])); 
            print_m256i(X, "X");
        }

        // Z_i+5 <- ADD(Z_i+5, SHL(X, 1))
        Z[i+5] = _mm256_add_epi64(Z[i+5], _mm256_slli_epi64(X, 1));
        print_m256i_array_entry(Z, i+5, "Z");
        print_newline();
    }

    for(int i = 0; i < 5; ++i){
        __m256i Zi_times_16 = _mm256_slli_epi64(Z[i + 5], 4);
        __m256i Zi_times_2 = _mm256_slli_epi64(Z[i + 5], 1);
        __m256i Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
        res[i] = _mm256_add_epi64(Zi_times_19, Z[i + 5]);
        res[i] = _mm256_add_epi64(res[i], Z[i]);
    }
}

void field_square_avx_parallel_generated(__m256i res[5], __m256i AB_v[5]){
    __m256i vec_0101 = _mm256_set_epi64x(1,0,1,0);
    __m256i vec_0000 = _mm256_setzero_si256();
    
    __m256i Z[10];
    __m256i U[10];
    __m256i V[10];
    
    /*[[[cog
    for i in range(0, 5):
        cog.outl(f'U[{2*i}] = AB_v[{i}];')
        cog.outl(f'U[{2*i + 1}] = _mm256_blend_epi32(AB_v[{(i + 1) % 5}], AB_v[{i}], 0b00110011);')
        cog.outl(f'U[{2*i + 1}] = _mm256_permute4x64_epi64(U[{2*i + 1}], 0b10110001);')
        cog.outl(f'U[{2*i + 1}] = _mm256_sllv_epi64(U[{2*i + 1}], vec_0101);')
        cog.outl(f'V[{2*i}] = _mm256_shuffle_epi32(AB_v[{i}], 0b11101110);')
        cog.outl(f'V[{2*i+1}] = _mm256_shuffle_epi32(AB_v[{i}], 0b01000100);')
    ]]]*/
    U[0] = AB_v[0];
    U[1] = _mm256_blend_epi32(AB_v[1], AB_v[0], 0b00110011);
    U[1] = _mm256_permute4x64_epi64(U[1], 0b10110001);
    U[1] = _mm256_sllv_epi64(U[1], vec_0101);
    V[0] = _mm256_shuffle_epi32(AB_v[0], 0b11101110);
    V[1] = _mm256_shuffle_epi32(AB_v[0], 0b01000100);
    U[2] = AB_v[1];
    U[3] = _mm256_blend_epi32(AB_v[2], AB_v[1], 0b00110011);
    U[3] = _mm256_permute4x64_epi64(U[3], 0b10110001);
    U[3] = _mm256_sllv_epi64(U[3], vec_0101);
    V[2] = _mm256_shuffle_epi32(AB_v[1], 0b11101110);
    V[3] = _mm256_shuffle_epi32(AB_v[1], 0b01000100);
    U[4] = AB_v[2];
    U[5] = _mm256_blend_epi32(AB_v[3], AB_v[2], 0b00110011);
    U[5] = _mm256_permute4x64_epi64(U[5], 0b10110001);
    U[5] = _mm256_sllv_epi64(U[5], vec_0101);
    V[4] = _mm256_shuffle_epi32(AB_v[2], 0b11101110);
    V[5] = _mm256_shuffle_epi32(AB_v[2], 0b01000100);
    U[6] = AB_v[3];
    U[7] = _mm256_blend_epi32(AB_v[4], AB_v[3], 0b00110011);
    U[7] = _mm256_permute4x64_epi64(U[7], 0b10110001);
    U[7] = _mm256_sllv_epi64(U[7], vec_0101);
    V[6] = _mm256_shuffle_epi32(AB_v[3], 0b11101110);
    V[7] = _mm256_shuffle_epi32(AB_v[3], 0b01000100);
    U[8] = AB_v[4];
    U[9] = _mm256_blend_epi32(AB_v[0], AB_v[4], 0b00110011);
    U[9] = _mm256_permute4x64_epi64(U[9], 0b10110001);
    U[9] = _mm256_sllv_epi64(U[9], vec_0101);
    V[8] = _mm256_shuffle_epi32(AB_v[4], 0b11101110);
    V[9] = _mm256_shuffle_epi32(AB_v[4], 0b01000100);
    //[[[end]]]

    /*[[[cog
    cog.outl(f'__m256i T;')
    cog.outl(f'__m256i W;')
    cog.outl(f'__m256i S;')
    cog.outl(f'__m256i X;')
    
    for i in range(0, 5):
        cog.outl(f'T = _mm256_mul_epi32(U[{i}], V[{i}]);')
        cog.outl(f'Z[{i}] = _mm256_blend_epi32(T, vec_0000, 0b00110011);')
        cog.outl(f'W = _mm256_blend_epi32(T, vec_0000, 0b11001100);')

        for j in range(1, i+1):
            cog.outl(f'W = _mm256_add_epi64(W, _mm256_mul_epi32(U[{i+j}], V[{(i-j)%10}]));')
        
        cog.outl(f'Z[{i}] = _mm256_add_epi64(Z[{i}], _mm256_slli_epi64(W, 1));')
        cog.outl(f'S = _mm256_mul_epi32(U[{i+5}], V[{i+5}]);')
        cog.outl(f'Z[{i+5}] = _mm256_blend_epi32(S, vec_0000, 0b00110011);')
        cog.outl(f'X = _mm256_setzero_si256();')

        for j in range(i+1, 5):
            cog.outl(f'X = _mm256_add_epi64(X, _mm256_mul_epi32(U[{j+i}], V[{(i-j)%10}]));') 

        cog.outl(f'Z[{i+5}] = _mm256_add_epi64(Z[{i+5}], _mm256_slli_epi64(X, 1));')
    ]]]*/
    __m256i T;
    __m256i W;
    __m256i S;
    __m256i X;
    T = _mm256_mul_epi32(U[0], V[0]);
    Z[0] = _mm256_blend_epi32(T, vec_0000, 0b00110011);
    W = _mm256_blend_epi32(T, vec_0000, 0b11001100);
    Z[0] = _mm256_add_epi64(Z[0], _mm256_slli_epi64(W, 1));
    S = _mm256_mul_epi32(U[5], V[5]);
    Z[5] = _mm256_blend_epi32(S, vec_0000, 0b00110011);
    X = _mm256_setzero_si256();
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[1], V[9]));
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[2], V[8]));
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[3], V[7]));
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[4], V[6]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_slli_epi64(X, 1));
    T = _mm256_mul_epi32(U[1], V[1]);
    Z[1] = _mm256_blend_epi32(T, vec_0000, 0b00110011);
    W = _mm256_blend_epi32(T, vec_0000, 0b11001100);
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[2], V[0]));
    Z[1] = _mm256_add_epi64(Z[1], _mm256_slli_epi64(W, 1));
    S = _mm256_mul_epi32(U[6], V[6]);
    Z[6] = _mm256_blend_epi32(S, vec_0000, 0b00110011);
    X = _mm256_setzero_si256();
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[3], V[9]));
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[4], V[8]));
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[5], V[7]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_slli_epi64(X, 1));
    T = _mm256_mul_epi32(U[2], V[2]);
    Z[2] = _mm256_blend_epi32(T, vec_0000, 0b00110011);
    W = _mm256_blend_epi32(T, vec_0000, 0b11001100);
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[3], V[1]));
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[4], V[0]));
    Z[2] = _mm256_add_epi64(Z[2], _mm256_slli_epi64(W, 1));
    S = _mm256_mul_epi32(U[7], V[7]);
    Z[7] = _mm256_blend_epi32(S, vec_0000, 0b00110011);
    X = _mm256_setzero_si256();
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[5], V[9]));
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[6], V[8]));
    Z[7] = _mm256_add_epi64(Z[7], _mm256_slli_epi64(X, 1));
    T = _mm256_mul_epi32(U[3], V[3]);
    Z[3] = _mm256_blend_epi32(T, vec_0000, 0b00110011);
    W = _mm256_blend_epi32(T, vec_0000, 0b11001100);
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[4], V[2]));
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[5], V[1]));
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[6], V[0]));
    Z[3] = _mm256_add_epi64(Z[3], _mm256_slli_epi64(W, 1));
    S = _mm256_mul_epi32(U[8], V[8]);
    Z[8] = _mm256_blend_epi32(S, vec_0000, 0b00110011);
    X = _mm256_setzero_si256();
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[7], V[9]));
    Z[8] = _mm256_add_epi64(Z[8], _mm256_slli_epi64(X, 1));
    T = _mm256_mul_epi32(U[4], V[4]);
    Z[4] = _mm256_blend_epi32(T, vec_0000, 0b00110011);
    W = _mm256_blend_epi32(T, vec_0000, 0b11001100);
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[5], V[3]));
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[6], V[2]));
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[7], V[1]));
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[8], V[0]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_slli_epi64(W, 1));
    S = _mm256_mul_epi32(U[9], V[9]);
    Z[9] = _mm256_blend_epi32(S, vec_0000, 0b00110011);
    X = _mm256_setzero_si256();
    Z[9] = _mm256_add_epi64(Z[9], _mm256_slli_epi64(X, 1));
    //[[[end]]]
    
    /*[[[cog
    modulo_after_multiplication("res", "Z")
    ]]]*/
    __m256i Zi_times_16;
    __m256i Zi_times_2;
    __m256i Zi_times_19;
    Zi_times_16 = _mm256_slli_epi64(Z[5], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[5], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[0] = _mm256_add_epi64(Zi_times_19, Z[5]);
    res[0] = _mm256_add_epi64(res[0], Z[0]);
    Zi_times_16 = _mm256_slli_epi64(Z[6], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[6], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[1] = _mm256_add_epi64(Zi_times_19, Z[6]);
    res[1] = _mm256_add_epi64(res[1], Z[1]);
    Zi_times_16 = _mm256_slli_epi64(Z[7], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[7], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[2] = _mm256_add_epi64(Zi_times_19, Z[7]);
    res[2] = _mm256_add_epi64(res[2], Z[2]);
    Zi_times_16 = _mm256_slli_epi64(Z[8], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[8], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[3] = _mm256_add_epi64(Zi_times_19, Z[8]);
    res[3] = _mm256_add_epi64(res[3], Z[3]);
    Zi_times_16 = _mm256_slli_epi64(Z[9], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[9], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[4] = _mm256_add_epi64(Zi_times_19, Z[9]);
    res[4] = _mm256_add_epi64(res[4], Z[4]);
    //[[[end]]]
}

void field_reduce_avx_parallel(__m256i res[5], __m256i AB_v[5]) {
    __m256i L[5];
    __m256i M[5];
    __m256i H[5];

    int32_t mask_25 = (1<<25)-1;
    int32_t mask_26 = (1<<26)-1;
    __m256i vec_mask2526 = _mm256_set_epi64x(mask_25, mask_26, mask_25, mask_26);
    __m256i vec_mask2625 = _mm256_set_epi64x(mask_26, mask_25, mask_26, mask_25);

    __m256i vec_shift2526 = _mm256_set_epi64x(25, 26, 25, 26);
    __m256i vec_doubleshift2526 = _mm256_set_epi64x(25+26, 26+25, 25+26, 26+25);

    __m256i vec_topshift = _mm256_set_epi64x(25+26, 26, 25+26, 26);

  
    for (int i = 0; i < 5; i++) {
        L[i] = _mm256_and_si256(AB_v[i], vec_mask2526);
        M[i] = _mm256_sllv_epi64(AB_v[i], vec_shift2526);
        M[i] = _mm256_and_si256(M[i], vec_mask2625);
        H[i] = _mm256_sllv_epi64(AB_v[i], vec_doubleshift2526);
    }

    for (int i = 0; i < 5; i++) {
        M[i] = _mm256_blend_epi32(AB_v[i], AB_v[(i+4) % 5], 0b00110011);
        M[i] = _mm256_permute4x64_epi64(M[i], 0b10110001);
    }
    
    H[4] = _mm256_srlv_epi64(AB_v[4], vec_topshift);
    
    /** 
     * 
     * linearized:
    field_entry_mul_t carry[10];
    carry[0] = (mul_results[0] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[0] -= carry[0] << 26;
    mul_results[1] += carry[0];
    carry[1] = (mul_results[1] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[1] -= carry[1] << 25;
    mul_results[2] += carry[1];
    carry[2] = (mul_results[2] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[2] -= carry[2] << 26;
    mul_results[3] += carry[2];
    carry[3] = (mul_results[3] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[3] -= carry[3] << 25;
    mul_results[4] += carry[3];
    carry[4] = (mul_results[4] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[4] -= carry[4] << 26;
    mul_results[5] += carry[4];
    carry[5] = (mul_results[5] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[5] -= carry[5] << 25;
    mul_results[6] += carry[5];
    carry[6] = (mul_results[6] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[6] -= carry[6] << 26;
    mul_results[7] += carry[6];
    carry[7] = (mul_results[7] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[7] -= carry[7] << 25;
    mul_results[8] += carry[7];
    carry[8] = (mul_results[8] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[8] -= carry[8] << 26;
    mul_results[9] += carry[8];
    carry[9] = (mul_results[9] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[9] -= carry[9] << 25;
    mul_results[0] += carry[9] * 19;
    carry[0] = (mul_results[0] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[0] -= carry[0] << 26;
    mul_results[1] += carry[0];
    
    loops:
    int i = 0;
    int64_t temp1;
    int64_t temp2;
    for (; i < 5; i++) {
        temp1 = (mul_results[2*i] + (1 << 25)) >> 26;
        mul_results[2*i] -= temp1 << 26;
        mul_results[2*i+1] += temp1;

        if (i < 4) {
            temp2 = (mul_results[2*i+1] + (1 << 24)) >> 25;
            mul_results[2*i+1] -= temp2 << 25;
            mul_results[2*i+2] += temp2;
        }
    }

    temp1 = (mul_results[9] + (1 << (24))) >> 25;
    mul_results[9] -= temp1 << 25;
    mul_results[0] += temp1 * 19;

    temp2 = (mul_results[0] + (1 << (25))) >> 26;
    mul_results[0] -= temp2 << 26;
    mul_results[1] += temp2;
    */
}

void field_square_avx_parallel_wrapper(field_t dst, field_t src)
{
    // [0, a_2i+1, 0, a_2i, 0, b_2i+1, 0, b_2i]

    field_packed_t pack;
    for (int i = 0; i < 5; i++) {
        pack[i*4 + 0] = src[i*2+1];
        pack[i*4 + 1] = src[i*2];
        pack[i*4 + 2] = 0;
        pack[i*4 + 3] = 0;
    }

    __m256i src_pack[5];
    for(int i = 0; i < 5; ++i){
        src_pack[i] = _mm256_load_si256((__m256i*)(pack + 4*i));
    }

    __m256i dst_pack[5];
    field_square_avx_parallel(dst_pack, src_pack);

    for(int i = 0; i < 5; ++i){
        _mm256_store_si256((__m256i*)(pack + 4*i), dst_pack[i]);
    }

    int64_t mul_results[10];
    for (int i = 0; i < 5; i++) {
        mul_results[i*2 + 1] = pack[i*4];
        mul_results[i*2] = pack[i*4+1];
    }

    field_entry_mul_t carry[10];
    carry[0] = (mul_results[0] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[0] -= carry[0] << 26;
    mul_results[1] += carry[0];
    carry[1] = (mul_results[1] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[1] -= carry[1] << 25;
    mul_results[2] += carry[1];
    carry[2] = (mul_results[2] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[2] -= carry[2] << 26;
    mul_results[3] += carry[2];
    carry[3] = (mul_results[3] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[3] -= carry[3] << 25;
    mul_results[4] += carry[3];
    carry[4] = (mul_results[4] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[4] -= carry[4] << 26;
    mul_results[5] += carry[4];
    carry[5] = (mul_results[5] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[5] -= carry[5] << 25;
    mul_results[6] += carry[5];
    carry[6] = (mul_results[6] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[6] -= carry[6] << 26;
    mul_results[7] += carry[6];
    carry[7] = (mul_results[7] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[7] -= carry[7] << 25;
    mul_results[8] += carry[7];
    carry[8] = (mul_results[8] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[8] -= carry[8] << 26;
    mul_results[9] += carry[8];
    carry[9] = (mul_results[9] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[9] -= carry[9] << 25;
    mul_results[0] += carry[9] * 19;
    carry[0] = (mul_results[0] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[0] -= carry[0] << 26;
    mul_results[1] += carry[0];

    dst[0] = (field_entry_t)mul_results[0];
    dst[1] = (field_entry_t)mul_results[1];
    dst[2] = (field_entry_t)mul_results[2];
    dst[3] = (field_entry_t)mul_results[3];
    dst[4] = (field_entry_t)mul_results[4];
    dst[5] = (field_entry_t)mul_results[5];
    dst[6] = (field_entry_t)mul_results[6];
    dst[7] = (field_entry_t)mul_results[7];
    dst[8] = (field_entry_t)mul_results[8];
    dst[9] = (field_entry_t)mul_results[9];
}

void field_mul_avx_parallel(__m256i res[5], __m256i AC_v[5], __m256i BD_v[5]) {
    __m256i vec_0101 = _mm256_set_epi64x(1,0,1,0);
    __m256i vec_0000 = _mm256_setzero_si256();
    
    __m256i BD_vp[5];
    __m256i Z[10];

    for (int i = 0; i < 10; i++) {
        Z[i] = _mm256_setzero_si256();
    }
    
    for (int i = 0; i < 5; i++) {
        BD_vp[i] = _mm256_blend_epi32(BD_v[(i + 1) % 5], BD_v[i], 0b00110011);
        BD_vp[i] = _mm256_permute4x64_epi64(BD_vp[i], 0b10110001);
        BD_vp[i] = _mm256_sllv_epi64(BD_vp[i],vec_0101);
    }

    __m256i U;
    __m256i V;
    __m256i W;

    for (int i = 0; i < 5; i++) {
        U = _mm256_shuffle_epi32(AC_v[i], 0b11101110);
        
        for (int j = 0; j < 5; j++) {
            Z[i + j] = _mm256_add_epi64(Z[i + j], _mm256_mul_epi32(U, BD_v[j]));
        }

        V = _mm256_shuffle_epi32(AC_v[i], 0b01000100);
        
        for (int j = 0; j < 4; j++) {
            Z[i + j + 1] = _mm256_add_epi64(Z[i + j + 1], _mm256_mul_epi32(V, BD_vp[j]));
        }

        W = _mm256_mul_epi32(V, BD_vp[4]);
        Z[i] = _mm256_add_epi64(Z[i], _mm256_blend_epi32(W, vec_0000, 0b11001100));
        Z[i + 5] = _mm256_add_epi64(Z[i + 5], _mm256_blend_epi32(W, vec_0000, 0b00110011));
    }

    /*[[[cog
    modulo_after_multiplication("res", "Z")
    ]]]*/
    __m256i Zi_times_16;
    __m256i Zi_times_2;
    __m256i Zi_times_19;
    Zi_times_16 = _mm256_slli_epi64(Z[5], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[5], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[0] = _mm256_add_epi64(Zi_times_19, Z[5]);
    res[0] = _mm256_add_epi64(res[0], Z[0]);
    Zi_times_16 = _mm256_slli_epi64(Z[6], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[6], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[1] = _mm256_add_epi64(Zi_times_19, Z[6]);
    res[1] = _mm256_add_epi64(res[1], Z[1]);
    Zi_times_16 = _mm256_slli_epi64(Z[7], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[7], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[2] = _mm256_add_epi64(Zi_times_19, Z[7]);
    res[2] = _mm256_add_epi64(res[2], Z[2]);
    Zi_times_16 = _mm256_slli_epi64(Z[8], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[8], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[3] = _mm256_add_epi64(Zi_times_19, Z[8]);
    res[3] = _mm256_add_epi64(res[3], Z[3]);
    Zi_times_16 = _mm256_slli_epi64(Z[9], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[9], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[4] = _mm256_add_epi64(Zi_times_19, Z[9]);
    res[4] = _mm256_add_epi64(res[4], Z[4]);
    //[[[end]]]
}

void field_mul_avx_parallel_generated(__m256i res[5], __m256i AC_v[5], __m256i BD_v[5]) {
    __m256i vec_0101 = _mm256_set_epi64x(1,0,1,0);
    __m256i vec_0000 = _mm256_setzero_si256();
    
    __m256i BD_vp[5];
    __m256i Z[10];
    
    /*[[[cog
    for i in range(0, 10):
        cog.outl(f'Z[{i}] = _mm256_setzero_si256();')
    ]]]*/    
    Z[0] = _mm256_setzero_si256();
    Z[1] = _mm256_setzero_si256();
    Z[2] = _mm256_setzero_si256();
    Z[3] = _mm256_setzero_si256();
    Z[4] = _mm256_setzero_si256();
    Z[5] = _mm256_setzero_si256();
    Z[6] = _mm256_setzero_si256();
    Z[7] = _mm256_setzero_si256();
    Z[8] = _mm256_setzero_si256();
    Z[9] = _mm256_setzero_si256();
    //[[[end]]]
    
    /*[[[cog
    for i in range(0, 5):
        cog.outl(f'BD_vp[{i}] = _mm256_blend_epi32(BD_v[{(i + 1) % 5}], BD_v[{i}], 0b00110011);')
        cog.outl(f'BD_vp[{i}] = _mm256_permute4x64_epi64(BD_vp[{i}], 0b10110001);')
        cog.outl(f'BD_vp[{i}] = _mm256_sllv_epi64(BD_vp[{i}],vec_0101);')
    ]]]*/
    BD_vp[0] = _mm256_blend_epi32(BD_v[1], BD_v[0], 0b00110011);
    BD_vp[0] = _mm256_permute4x64_epi64(BD_vp[0], 0b10110001);
    BD_vp[0] = _mm256_sllv_epi64(BD_vp[0],vec_0101);
    BD_vp[1] = _mm256_blend_epi32(BD_v[2], BD_v[1], 0b00110011);
    BD_vp[1] = _mm256_permute4x64_epi64(BD_vp[1], 0b10110001);
    BD_vp[1] = _mm256_sllv_epi64(BD_vp[1],vec_0101);
    BD_vp[2] = _mm256_blend_epi32(BD_v[3], BD_v[2], 0b00110011);
    BD_vp[2] = _mm256_permute4x64_epi64(BD_vp[2], 0b10110001);
    BD_vp[2] = _mm256_sllv_epi64(BD_vp[2],vec_0101);
    BD_vp[3] = _mm256_blend_epi32(BD_v[4], BD_v[3], 0b00110011);
    BD_vp[3] = _mm256_permute4x64_epi64(BD_vp[3], 0b10110001);
    BD_vp[3] = _mm256_sllv_epi64(BD_vp[3],vec_0101);
    BD_vp[4] = _mm256_blend_epi32(BD_v[0], BD_v[4], 0b00110011);
    BD_vp[4] = _mm256_permute4x64_epi64(BD_vp[4], 0b10110001);
    BD_vp[4] = _mm256_sllv_epi64(BD_vp[4],vec_0101);
    //[[[end]]]

    /*[[[cog
    cog.outl(f'__m256i U;')
    cog.outl(f'__m256i V;')
    cog.outl(f'__m256i W;')

    for i in range(0, 5):
        cog.outl(f'U = _mm256_shuffle_epi32(AC_v[{i}], 0b11101110);')
        
        for j in range(0, 5):
            cog.outl(f'Z[{i + j}] = _mm256_add_epi64(Z[{i + j}], _mm256_mul_epi32(U, BD_v[{j}]));')
        
        cog.outl(f'V = _mm256_shuffle_epi32(AC_v[{i}], 0b01000100);')
        
        for j in range(0, 4):
            cog.outl(f'Z[{i + j + 1}] = _mm256_add_epi64(Z[{i + j + 1}], _mm256_mul_epi32(V, BD_vp[{j}]));')
        
        cog.outl(f'W = _mm256_mul_epi32(V, BD_vp[{4}]);')
        cog.outl(f'Z[{i}] = _mm256_add_epi64(Z[{i}], _mm256_blend_epi32(W, vec_0000, 0b11001100));')
        cog.outl(f'Z[{i + 5}] = _mm256_add_epi64(Z[{i + 5}], _mm256_blend_epi32(W, vec_0000, 0b00110011));')
    ]]]*/
    __m256i U;
    __m256i V;
    __m256i W;
    U = _mm256_shuffle_epi32(AC_v[0], 0b11101110);
    Z[0] = _mm256_add_epi64(Z[0], _mm256_mul_epi32(U, BD_v[0]));
    Z[1] = _mm256_add_epi64(Z[1], _mm256_mul_epi32(U, BD_v[1]));
    Z[2] = _mm256_add_epi64(Z[2], _mm256_mul_epi32(U, BD_v[2]));
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(U, BD_v[3]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(U, BD_v[4]));
    V = _mm256_shuffle_epi32(AC_v[0], 0b01000100);
    Z[1] = _mm256_add_epi64(Z[1], _mm256_mul_epi32(V, BD_vp[0]));
    Z[2] = _mm256_add_epi64(Z[2], _mm256_mul_epi32(V, BD_vp[1]));
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(V, BD_vp[2]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(V, BD_vp[3]));
    W = _mm256_mul_epi32(V, BD_vp[4]);
    Z[0] = _mm256_add_epi64(Z[0], _mm256_blend_epi32(W, vec_0000, 0b11001100));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_blend_epi32(W, vec_0000, 0b00110011));
    U = _mm256_shuffle_epi32(AC_v[1], 0b11101110);
    Z[1] = _mm256_add_epi64(Z[1], _mm256_mul_epi32(U, BD_v[0]));
    Z[2] = _mm256_add_epi64(Z[2], _mm256_mul_epi32(U, BD_v[1]));
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(U, BD_v[2]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(U, BD_v[3]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(U, BD_v[4]));
    V = _mm256_shuffle_epi32(AC_v[1], 0b01000100);
    Z[2] = _mm256_add_epi64(Z[2], _mm256_mul_epi32(V, BD_vp[0]));
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(V, BD_vp[1]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(V, BD_vp[2]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(V, BD_vp[3]));
    W = _mm256_mul_epi32(V, BD_vp[4]);
    Z[1] = _mm256_add_epi64(Z[1], _mm256_blend_epi32(W, vec_0000, 0b11001100));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_blend_epi32(W, vec_0000, 0b00110011));
    U = _mm256_shuffle_epi32(AC_v[2], 0b11101110);
    Z[2] = _mm256_add_epi64(Z[2], _mm256_mul_epi32(U, BD_v[0]));
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(U, BD_v[1]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(U, BD_v[2]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(U, BD_v[3]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_mul_epi32(U, BD_v[4]));
    V = _mm256_shuffle_epi32(AC_v[2], 0b01000100);
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(V, BD_vp[0]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(V, BD_vp[1]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(V, BD_vp[2]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_mul_epi32(V, BD_vp[3]));
    W = _mm256_mul_epi32(V, BD_vp[4]);
    Z[2] = _mm256_add_epi64(Z[2], _mm256_blend_epi32(W, vec_0000, 0b11001100));
    Z[7] = _mm256_add_epi64(Z[7], _mm256_blend_epi32(W, vec_0000, 0b00110011));
    U = _mm256_shuffle_epi32(AC_v[3], 0b11101110);
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(U, BD_v[0]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(U, BD_v[1]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(U, BD_v[2]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_mul_epi32(U, BD_v[3]));
    Z[7] = _mm256_add_epi64(Z[7], _mm256_mul_epi32(U, BD_v[4]));
    V = _mm256_shuffle_epi32(AC_v[3], 0b01000100);
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(V, BD_vp[0]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(V, BD_vp[1]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_mul_epi32(V, BD_vp[2]));
    Z[7] = _mm256_add_epi64(Z[7], _mm256_mul_epi32(V, BD_vp[3]));
    W = _mm256_mul_epi32(V, BD_vp[4]);
    Z[3] = _mm256_add_epi64(Z[3], _mm256_blend_epi32(W, vec_0000, 0b11001100));
    Z[8] = _mm256_add_epi64(Z[8], _mm256_blend_epi32(W, vec_0000, 0b00110011));
    U = _mm256_shuffle_epi32(AC_v[4], 0b11101110);
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(U, BD_v[0]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(U, BD_v[1]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_mul_epi32(U, BD_v[2]));
    Z[7] = _mm256_add_epi64(Z[7], _mm256_mul_epi32(U, BD_v[3]));
    Z[8] = _mm256_add_epi64(Z[8], _mm256_mul_epi32(U, BD_v[4]));
    V = _mm256_shuffle_epi32(AC_v[4], 0b01000100);
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(V, BD_vp[0]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_mul_epi32(V, BD_vp[1]));
    Z[7] = _mm256_add_epi64(Z[7], _mm256_mul_epi32(V, BD_vp[2]));
    Z[8] = _mm256_add_epi64(Z[8], _mm256_mul_epi32(V, BD_vp[3]));
    W = _mm256_mul_epi32(V, BD_vp[4]);
    Z[4] = _mm256_add_epi64(Z[4], _mm256_blend_epi32(W, vec_0000, 0b11001100));
    Z[9] = _mm256_add_epi64(Z[9], _mm256_blend_epi32(W, vec_0000, 0b00110011));
    //[[[end]]]

    /*[[[cog
    modulo_after_multiplication("res", "Z")
    ]]]*/
    __m256i Zi_times_16;
    __m256i Zi_times_2;
    __m256i Zi_times_19;
    Zi_times_16 = _mm256_slli_epi64(Z[5], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[5], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[0] = _mm256_add_epi64(Zi_times_19, Z[5]);
    res[0] = _mm256_add_epi64(res[0], Z[0]);
    Zi_times_16 = _mm256_slli_epi64(Z[6], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[6], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[1] = _mm256_add_epi64(Zi_times_19, Z[6]);
    res[1] = _mm256_add_epi64(res[1], Z[1]);
    Zi_times_16 = _mm256_slli_epi64(Z[7], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[7], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[2] = _mm256_add_epi64(Zi_times_19, Z[7]);
    res[2] = _mm256_add_epi64(res[2], Z[2]);
    Zi_times_16 = _mm256_slli_epi64(Z[8], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[8], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[3] = _mm256_add_epi64(Zi_times_19, Z[8]);
    res[3] = _mm256_add_epi64(res[3], Z[3]);
    Zi_times_16 = _mm256_slli_epi64(Z[9], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[9], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[4] = _mm256_add_epi64(Zi_times_19, Z[9]);
    res[4] = _mm256_add_epi64(res[4], Z[4]);
    //[[[end]]]
}

void field_mul_avx_parallel_wrapper(field_t dst, field_t a, field_t b) {
    // [0, a_2i+1, 0, a_2i, 0, b_2i+1, 0, b_2i]

    field_packed_t a_pack;
    field_packed_t b_pack;
    for (int i = 0; i < 5; i++) {
        a_pack[i*4 + 0] = a[i*2+1];
        a_pack[i*4 + 1] = a[i*2];
        a_pack[i*4 + 2] = 0;
        a_pack[i*4 + 3] = 0;

        b_pack[i*4 + 0] = b[i*2+1];
        b_pack[i*4 + 1] = b[i*2];
        b_pack[i*4 + 2] = 0;
        b_pack[i*4 + 3] = 0;
    }

    __m256i a_pack_m[5];
    __m256i b_pack_m[5];
    for(int i = 0; i < 5; ++i){
        a_pack_m[i] = _mm256_load_si256((__m256i*)(a_pack + 4*i));
        b_pack_m[i] = _mm256_load_si256((__m256i*)(b_pack + 4*i));
    }

    __m256i dst_pack[5];
    field_mul_avx_parallel(dst_pack, a_pack_m, b_pack_m);

    field_packed_t pack;
    for(int i = 0; i < 5; ++i){
        _mm256_store_si256((__m256i*)(pack + 4*i), dst_pack[i]);
    }

    int64_t mul_results[10];
    for (int i = 0; i < 5; i++) {
        mul_results[i*2 + 1] = pack[i*4];
        mul_results[i*2] = pack[i*4+1];
    }

    field_entry_mul_t carry[10];
    carry[0] = (mul_results[0] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[0] -= carry[0] << 26;
    mul_results[1] += carry[0];
    carry[1] = (mul_results[1] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[1] -= carry[1] << 25;
    mul_results[2] += carry[1];
    carry[2] = (mul_results[2] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[2] -= carry[2] << 26;
    mul_results[3] += carry[2];
    carry[3] = (mul_results[3] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[3] -= carry[3] << 25;
    mul_results[4] += carry[3];
    carry[4] = (mul_results[4] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[4] -= carry[4] << 26;
    mul_results[5] += carry[4];
    carry[5] = (mul_results[5] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[5] -= carry[5] << 25;
    mul_results[6] += carry[5];
    carry[6] = (mul_results[6] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[6] -= carry[6] << 26;
    mul_results[7] += carry[6];
    carry[7] = (mul_results[7] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[7] -= carry[7] << 25;
    mul_results[8] += carry[7];
    carry[8] = (mul_results[8] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[8] -= carry[8] << 26;
    mul_results[9] += carry[8];
    carry[9] = (mul_results[9] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[9] -= carry[9] << 25;
    mul_results[0] += carry[9] * 19;
    carry[0] = (mul_results[0] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[0] -= carry[0] << 26;
    mul_results[1] += carry[0];

    dst[0] = (field_entry_t)mul_results[0];
    dst[1] = (field_entry_t)mul_results[1];
    dst[2] = (field_entry_t)mul_results[2];
    dst[3] = (field_entry_t)mul_results[3];
    dst[4] = (field_entry_t)mul_results[4];
    dst[5] = (field_entry_t)mul_results[5];
    dst[6] = (field_entry_t)mul_results[6];
    dst[7] = (field_entry_t)mul_results[7];
    dst[8] = (field_entry_t)mul_results[8];
    dst[9] = (field_entry_t)mul_results[9];
}

void field_add(field_t dst, field_t a, field_t b) {
    dst[0] = a[0] + b[0];
    dst[1] = a[1] + b[1];
    dst[2] = a[2] + b[2];
    dst[3] = a[3] + b[3];
    dst[4] = a[4] + b[4];
    dst[5] = a[5] + b[5];
    dst[6] = a[6] + b[6];
    dst[7] = a[7] + b[7];
    dst[8] = a[8] + b[8];
    dst[9] = a[9] + b[9];
}

void field_sub(field_t dst, field_t a, field_t b) {
    dst[0] = a[0] - b[0];
    dst[1] = a[1] - b[1];
    dst[2] = a[2] - b[2];
    dst[3] = a[3] - b[3];
    dst[4] = a[4] - b[4];
    dst[5] = a[5] - b[5];
    dst[6] = a[6] - b[6];
    dst[7] = a[7] - b[7];
    dst[8] = a[8] - b[8];
    dst[9] = a[9] - b[9];
}

void field_square(field_t dst, field_t src) {
    field_entry_mul_t mul_results[10] = {0};

    field_entry_mul_t src_1_2 = (field_entry_mul_t)src[1] * 2;
    field_entry_mul_t src_2_2 = (field_entry_mul_t)src[2] * 2;
    field_entry_mul_t src_3_2 = (field_entry_mul_t)src[3] * 2;
    field_entry_mul_t src_4_2 = (field_entry_mul_t)src[4] * 2;
    field_entry_mul_t src_5_2 = (field_entry_mul_t)src[5] * 2;
    field_entry_mul_t src_6_2 = (field_entry_mul_t)src[6] * 2;
    field_entry_mul_t src_7_2 = (field_entry_mul_t)src[7] * 2;
    field_entry_mul_t src_8_2 = (field_entry_mul_t)src[8] * 2;
    field_entry_mul_t src_9_2 = (field_entry_mul_t)src[9] * 2;
    field_entry_mul_t src_3_4 = (field_entry_mul_t)src[3] * 4;
    field_entry_mul_t src_5_4 = (field_entry_mul_t)src[5] * 4;
    field_entry_mul_t src_7_4 = (field_entry_mul_t)src[7] * 4;
    field_entry_mul_t src_9_76 = (field_entry_mul_t)src[9] * 76;
    field_entry_mul_t src_8_38 = (field_entry_mul_t)src[8] * 38;
    field_entry_mul_t src_9_38 = (field_entry_mul_t)src[9] * 38;
    field_entry_mul_t src_7_76 = (field_entry_mul_t)src[7] * 76;
    field_entry_mul_t src_6_38 = (field_entry_mul_t)src[6] * 38;
    field_entry_mul_t src_7_38 = (field_entry_mul_t)src[7] * 38;
    field_entry_mul_t src_5_38 = (field_entry_mul_t)src[5] * 38;
    field_entry_mul_t src_6_19 = (field_entry_mul_t)src[6] * 19;
    field_entry_mul_t src_8_19 = (field_entry_mul_t)src[8] * 19;

    mul_results[0] += (field_entry_mul_t)src[0] * src[0];
    mul_results[1] += (field_entry_mul_t)src[0] * src_1_2;
    mul_results[2] += (field_entry_mul_t)src[0] * src_2_2;
    mul_results[3] += (field_entry_mul_t)src[0] * src_3_2;
    mul_results[4] += (field_entry_mul_t)src[0] * src_4_2;
    mul_results[5] += (field_entry_mul_t)src[0] * src_5_2;
    mul_results[6] += (field_entry_mul_t)src[0] * src_6_2;
    mul_results[7] += (field_entry_mul_t)src[0] * src_7_2;
    mul_results[8] += (field_entry_mul_t)src[0] * src_8_2;
    mul_results[9] += (field_entry_mul_t)src[0] * src_9_2;
    mul_results[2] += (field_entry_mul_t)src[1] * src_1_2;
    mul_results[3] += (field_entry_mul_t)src[1] * src_2_2;
    mul_results[4] += (field_entry_mul_t)src[1] * src_3_4;
    mul_results[5] += (field_entry_mul_t)src[1] * src_4_2;
    mul_results[6] += (field_entry_mul_t)src[1] * src_5_4;
    mul_results[7] += (field_entry_mul_t)src[1] * src_6_2;
    mul_results[8] += (field_entry_mul_t)src[1] * src_7_4;
    mul_results[9] += (field_entry_mul_t)src[1] * src_8_2;
    mul_results[0] += (field_entry_mul_t)src[1] * src_9_76;
    mul_results[4] += (field_entry_mul_t)src[2] * src[2];
    mul_results[5] += (field_entry_mul_t)src[2] * src_3_2;
    mul_results[6] += (field_entry_mul_t)src[2] * src_4_2;
    mul_results[7] += (field_entry_mul_t)src[2] * src_5_2;
    mul_results[8] += (field_entry_mul_t)src[2] * src_6_2;
    mul_results[9] += (field_entry_mul_t)src[2] * src_7_2;
    mul_results[0] += (field_entry_mul_t)src[2] * src_8_38;
    mul_results[1] += (field_entry_mul_t)src[2] * src_9_38;
    mul_results[6] += (field_entry_mul_t)src[3] * src_3_2;
    mul_results[7] += (field_entry_mul_t)src[3] * src_4_2;
    mul_results[8] += (field_entry_mul_t)src[3] * src_5_4;
    mul_results[9] += (field_entry_mul_t)src[3] * src_6_2;
    mul_results[0] += (field_entry_mul_t)src[3] * src_7_76;
    mul_results[1] += (field_entry_mul_t)src[3] * src_8_38;
    mul_results[2] += (field_entry_mul_t)src[3] * src_9_76;
    mul_results[8] += (field_entry_mul_t)src[4] * src[4];
    mul_results[9] += (field_entry_mul_t)src[4] * src_5_2;
    mul_results[0] += (field_entry_mul_t)src[4] * src_6_38;
    mul_results[1] += (field_entry_mul_t)src[4] * src_7_38;
    mul_results[2] += (field_entry_mul_t)src[4] * src_8_38;
    mul_results[3] += (field_entry_mul_t)src[4] * src_9_38;
    mul_results[0] += (field_entry_mul_t)src[5] * src_5_38;
    mul_results[1] += (field_entry_mul_t)src[5] * src_6_38;
    mul_results[2] += (field_entry_mul_t)src[5] * src_7_76;
    mul_results[3] += (field_entry_mul_t)src[5] * src_8_38;
    mul_results[4] += (field_entry_mul_t)src[5] * src_9_76;
    mul_results[2] += (field_entry_mul_t)src[6] * src_6_19;
    mul_results[3] += (field_entry_mul_t)src[6] * src_7_38;
    mul_results[4] += (field_entry_mul_t)src[6] * src_8_38;
    mul_results[5] += (field_entry_mul_t)src[6] * src_9_38;
    mul_results[4] += (field_entry_mul_t)src[7] * src_7_38;
    mul_results[5] += (field_entry_mul_t)src[7] * src_8_38;
    mul_results[6] += (field_entry_mul_t)src[7] * src_9_76;
    mul_results[6] += (field_entry_mul_t)src[8] * src_8_19;
    mul_results[7] += (field_entry_mul_t)src[8] * src_9_38;
    mul_results[8] += (field_entry_mul_t)src[9] * src_9_38;

    field_entry_mul_t carry[10];
    carry[0] = (mul_results[0] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[0] -= carry[0] << 26;
    mul_results[1] += carry[0];
    carry[1] = (mul_results[1] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[1] -= carry[1] << 25;
    mul_results[2] += carry[1];
    carry[2] = (mul_results[2] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[2] -= carry[2] << 26;
    mul_results[3] += carry[2];
    carry[3] = (mul_results[3] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[3] -= carry[3] << 25;
    mul_results[4] += carry[3];
    carry[4] = (mul_results[4] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[4] -= carry[4] << 26;
    mul_results[5] += carry[4];
    carry[5] = (mul_results[5] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[5] -= carry[5] << 25;
    mul_results[6] += carry[5];
    carry[6] = (mul_results[6] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[6] -= carry[6] << 26;
    mul_results[7] += carry[6];
    carry[7] = (mul_results[7] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[7] -= carry[7] << 25;
    mul_results[8] += carry[7];
    carry[8] = (mul_results[8] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[8] -= carry[8] << 26;
    mul_results[9] += carry[8];
    carry[9] = (mul_results[9] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[9] -= carry[9] << 25;
    mul_results[0] += carry[9] * 19;
    carry[0] = (mul_results[0] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[0] -= carry[0] << 26;
    mul_results[1] += carry[0];

    dst[0] = (field_entry_t)mul_results[0];
    dst[1] = (field_entry_t)mul_results[1];
    dst[2] = (field_entry_t)mul_results[2];
    dst[3] = (field_entry_t)mul_results[3];
    dst[4] = (field_entry_t)mul_results[4];
    dst[5] = (field_entry_t)mul_results[5];
    dst[6] = (field_entry_t)mul_results[6];
    dst[7] = (field_entry_t)mul_results[7];
    dst[8] = (field_entry_t)mul_results[8];
    dst[9] = (field_entry_t)mul_results[9];
}

void field_mul(field_t dst, field_t a, field_t b) {
    field_entry_mul_t mul_results[10] = {0};

    field_entry_mul_t b_1_2 = (field_entry_mul_t)b[1] * 2;
    field_entry_mul_t b_3_2 = (field_entry_mul_t)b[3] * 2;
    field_entry_mul_t b_5_2 = (field_entry_mul_t)b[5] * 2;
    field_entry_mul_t b_7_2 = (field_entry_mul_t)b[7] * 2;
    field_entry_mul_t b_9_38 = (field_entry_mul_t)b[9] * 38;
    field_entry_mul_t b_8_19 = (field_entry_mul_t)b[8] * 19;
    field_entry_mul_t b_9_19 = (field_entry_mul_t)b[9] * 19;
    field_entry_mul_t b_7_38 = (field_entry_mul_t)b[7] * 38;
    field_entry_mul_t b_6_19 = (field_entry_mul_t)b[6] * 19;
    field_entry_mul_t b_7_19 = (field_entry_mul_t)b[7] * 19;
    field_entry_mul_t b_5_38 = (field_entry_mul_t)b[5] * 38;
    field_entry_mul_t b_4_19 = (field_entry_mul_t)b[4] * 19;
    field_entry_mul_t b_5_19 = (field_entry_mul_t)b[5] * 19;
    field_entry_mul_t b_3_38 = (field_entry_mul_t)b[3] * 38;
    field_entry_mul_t b_2_19 = (field_entry_mul_t)b[2] * 19;
    field_entry_mul_t b_3_19 = (field_entry_mul_t)b[3] * 19;
    field_entry_mul_t b_1_38 = (field_entry_mul_t)b[1] * 38;

    mul_results[0] += (field_entry_mul_t)a[0] * b[0];
    mul_results[1] += (field_entry_mul_t)a[0] * b[1];
    mul_results[2] += (field_entry_mul_t)a[0] * b[2];
    mul_results[3] += (field_entry_mul_t)a[0] * b[3];
    mul_results[4] += (field_entry_mul_t)a[0] * b[4];
    mul_results[5] += (field_entry_mul_t)a[0] * b[5];
    mul_results[6] += (field_entry_mul_t)a[0] * b[6];
    mul_results[7] += (field_entry_mul_t)a[0] * b[7];
    mul_results[8] += (field_entry_mul_t)a[0] * b[8];
    mul_results[9] += (field_entry_mul_t)a[0] * b[9];
    mul_results[1] += (field_entry_mul_t)a[1] * b[0];
    mul_results[2] += (field_entry_mul_t)a[1] * b_1_2;
    mul_results[3] += (field_entry_mul_t)a[1] * b[2];
    mul_results[4] += (field_entry_mul_t)a[1] * b_3_2;
    mul_results[5] += (field_entry_mul_t)a[1] * b[4];
    mul_results[6] += (field_entry_mul_t)a[1] * b_5_2;
    mul_results[7] += (field_entry_mul_t)a[1] * b[6];
    mul_results[8] += (field_entry_mul_t)a[1] * b_7_2;
    mul_results[9] += (field_entry_mul_t)a[1] * b[8];
    mul_results[0] += (field_entry_mul_t)a[1] * b_9_38;
    mul_results[2] += (field_entry_mul_t)a[2] * b[0];
    mul_results[3] += (field_entry_mul_t)a[2] * b[1];
    mul_results[4] += (field_entry_mul_t)a[2] * b[2];
    mul_results[5] += (field_entry_mul_t)a[2] * b[3];
    mul_results[6] += (field_entry_mul_t)a[2] * b[4];
    mul_results[7] += (field_entry_mul_t)a[2] * b[5];
    mul_results[8] += (field_entry_mul_t)a[2] * b[6];
    mul_results[9] += (field_entry_mul_t)a[2] * b[7];
    mul_results[0] += (field_entry_mul_t)a[2] * b_8_19;
    mul_results[1] += (field_entry_mul_t)a[2] * b_9_19;
    mul_results[3] += (field_entry_mul_t)a[3] * b[0];
    mul_results[4] += (field_entry_mul_t)a[3] * b_1_2;
    mul_results[5] += (field_entry_mul_t)a[3] * b[2];
    mul_results[6] += (field_entry_mul_t)a[3] * b_3_2;
    mul_results[7] += (field_entry_mul_t)a[3] * b[4];
    mul_results[8] += (field_entry_mul_t)a[3] * b_5_2;
    mul_results[9] += (field_entry_mul_t)a[3] * b[6];
    mul_results[0] += (field_entry_mul_t)a[3] * b_7_38;
    mul_results[1] += (field_entry_mul_t)a[3] * b_8_19;
    mul_results[2] += (field_entry_mul_t)a[3] * b_9_38;
    mul_results[4] += (field_entry_mul_t)a[4] * b[0];
    mul_results[5] += (field_entry_mul_t)a[4] * b[1];
    mul_results[6] += (field_entry_mul_t)a[4] * b[2];
    mul_results[7] += (field_entry_mul_t)a[4] * b[3];
    mul_results[8] += (field_entry_mul_t)a[4] * b[4];
    mul_results[9] += (field_entry_mul_t)a[4] * b[5];
    mul_results[0] += (field_entry_mul_t)a[4] * b_6_19;
    mul_results[1] += (field_entry_mul_t)a[4] * b_7_19;
    mul_results[2] += (field_entry_mul_t)a[4] * b_8_19;
    mul_results[3] += (field_entry_mul_t)a[4] * b_9_19;
    mul_results[5] += (field_entry_mul_t)a[5] * b[0];
    mul_results[6] += (field_entry_mul_t)a[5] * b_1_2;
    mul_results[7] += (field_entry_mul_t)a[5] * b[2];
    mul_results[8] += (field_entry_mul_t)a[5] * b_3_2;
    mul_results[9] += (field_entry_mul_t)a[5] * b[4];
    mul_results[0] += (field_entry_mul_t)a[5] * b_5_38;
    mul_results[1] += (field_entry_mul_t)a[5] * b_6_19;
    mul_results[2] += (field_entry_mul_t)a[5] * b_7_38;
    mul_results[3] += (field_entry_mul_t)a[5] * b_8_19;
    mul_results[4] += (field_entry_mul_t)a[5] * b_9_38;
    mul_results[6] += (field_entry_mul_t)a[6] * b[0];
    mul_results[7] += (field_entry_mul_t)a[6] * b[1];
    mul_results[8] += (field_entry_mul_t)a[6] * b[2];
    mul_results[9] += (field_entry_mul_t)a[6] * b[3];
    mul_results[0] += (field_entry_mul_t)a[6] * b_4_19;
    mul_results[1] += (field_entry_mul_t)a[6] * b_5_19;
    mul_results[2] += (field_entry_mul_t)a[6] * b_6_19;
    mul_results[3] += (field_entry_mul_t)a[6] * b_7_19;
    mul_results[4] += (field_entry_mul_t)a[6] * b_8_19;
    mul_results[5] += (field_entry_mul_t)a[6] * b_9_19;
    mul_results[7] += (field_entry_mul_t)a[7] * b[0];
    mul_results[8] += (field_entry_mul_t)a[7] * b_1_2;
    mul_results[9] += (field_entry_mul_t)a[7] * b[2];
    mul_results[0] += (field_entry_mul_t)a[7] * b_3_38;
    mul_results[1] += (field_entry_mul_t)a[7] * b_4_19;
    mul_results[2] += (field_entry_mul_t)a[7] * b_5_38;
    mul_results[3] += (field_entry_mul_t)a[7] * b_6_19;
    mul_results[4] += (field_entry_mul_t)a[7] * b_7_38;
    mul_results[5] += (field_entry_mul_t)a[7] * b_8_19;
    mul_results[6] += (field_entry_mul_t)a[7] * b_9_38;
    mul_results[8] += (field_entry_mul_t)a[8] * b[0];
    mul_results[9] += (field_entry_mul_t)a[8] * b[1];
    mul_results[0] += (field_entry_mul_t)a[8] * b_2_19;
    mul_results[1] += (field_entry_mul_t)a[8] * b_3_19;
    mul_results[2] += (field_entry_mul_t)a[8] * b_4_19;
    mul_results[3] += (field_entry_mul_t)a[8] * b_5_19;
    mul_results[4] += (field_entry_mul_t)a[8] * b_6_19;
    mul_results[5] += (field_entry_mul_t)a[8] * b_7_19;
    mul_results[6] += (field_entry_mul_t)a[8] * b_8_19;
    mul_results[7] += (field_entry_mul_t)a[8] * b_9_19;
    mul_results[9] += (field_entry_mul_t)a[9] * b[0];
    mul_results[0] += (field_entry_mul_t)a[9] * b_1_38;
    mul_results[1] += (field_entry_mul_t)a[9] * b_2_19;
    mul_results[2] += (field_entry_mul_t)a[9] * b_3_38;
    mul_results[3] += (field_entry_mul_t)a[9] * b_4_19;
    mul_results[4] += (field_entry_mul_t)a[9] * b_5_38;
    mul_results[5] += (field_entry_mul_t)a[9] * b_6_19;
    mul_results[6] += (field_entry_mul_t)a[9] * b_7_38;
    mul_results[7] += (field_entry_mul_t)a[9] * b_8_19;
    mul_results[8] += (field_entry_mul_t)a[9] * b_9_38;

    field_entry_mul_t carry[10];
    carry[0] = (mul_results[0] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[0] -= carry[0] << 26;
    mul_results[1] += carry[0];
    carry[1] = (mul_results[1] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[1] -= carry[1] << 25;
    mul_results[2] += carry[1];
    carry[2] = (mul_results[2] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[2] -= carry[2] << 26;
    mul_results[3] += carry[2];
    carry[3] = (mul_results[3] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[3] -= carry[3] << 25;
    mul_results[4] += carry[3];
    carry[4] = (mul_results[4] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[4] -= carry[4] << 26;
    mul_results[5] += carry[4];
    carry[5] = (mul_results[5] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[5] -= carry[5] << 25;
    mul_results[6] += carry[5];
    carry[6] = (mul_results[6] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[6] -= carry[6] << 26;
    mul_results[7] += carry[6];
    carry[7] = (mul_results[7] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[7] -= carry[7] << 25;
    mul_results[8] += carry[7];
    carry[8] = (mul_results[8] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[8] -= carry[8] << 26;
    mul_results[9] += carry[8];
    carry[9] = (mul_results[9] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[9] -= carry[9] << 25;
    mul_results[0] += carry[9] * 19;
    carry[0] = (mul_results[0] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[0] -= carry[0] << 26;
    mul_results[1] += carry[0];

    dst[0] = (field_entry_t)mul_results[0];
    dst[1] = (field_entry_t)mul_results[1];
    dst[2] = (field_entry_t)mul_results[2];
    dst[3] = (field_entry_t)mul_results[3];
    dst[4] = (field_entry_t)mul_results[4];
    dst[5] = (field_entry_t)mul_results[5];
    dst[6] = (field_entry_t)mul_results[6];
    dst[7] = (field_entry_t)mul_results[7];
    dst[8] = (field_entry_t)mul_results[8];
    dst[9] = (field_entry_t)mul_results[9];
}

void field_mul_a24(field_t dst, field_t src) {
    const int a24 = 121665;
    
    field_entry_mul_t mul_results[10] = {0};

    mul_results[0] = (field_entry_mul_t)src[0] * a24;
    mul_results[1] = (field_entry_mul_t)src[1] * a24;
    mul_results[2] = (field_entry_mul_t)src[2] * a24;
    mul_results[3] = (field_entry_mul_t)src[3] * a24;
    mul_results[4] = (field_entry_mul_t)src[4] * a24;
    mul_results[5] = (field_entry_mul_t)src[5] * a24;
    mul_results[6] = (field_entry_mul_t)src[6] * a24;
    mul_results[7] = (field_entry_mul_t)src[7] * a24;
    mul_results[8] = (field_entry_mul_t)src[8] * a24;
    mul_results[9] = (field_entry_mul_t)src[9] * a24;

    field_entry_mul_t carry[10];
    carry[0] = (mul_results[0] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[0] -= carry[0] << 26;
    mul_results[1] += carry[0];
    carry[1] = (mul_results[1] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[1] -= carry[1] << 25;
    mul_results[2] += carry[1];
    carry[2] = (mul_results[2] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[2] -= carry[2] << 26;
    mul_results[3] += carry[2];
    carry[3] = (mul_results[3] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[3] -= carry[3] << 25;
    mul_results[4] += carry[3];
    carry[4] = (mul_results[4] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[4] -= carry[4] << 26;
    mul_results[5] += carry[4];
    carry[5] = (mul_results[5] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[5] -= carry[5] << 25;
    mul_results[6] += carry[5];
    carry[6] = (mul_results[6] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[6] -= carry[6] << 26;
    mul_results[7] += carry[6];
    carry[7] = (mul_results[7] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[7] -= carry[7] << 25;
    mul_results[8] += carry[7];
    carry[8] = (mul_results[8] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[8] -= carry[8] << 26;
    mul_results[9] += carry[8];
    carry[9] = (mul_results[9] + ((field_entry_t)1 << 24)) >> 25;
    mul_results[9] -= carry[9] << 25;
    mul_results[0] += carry[9] * 19;
    carry[0] = (mul_results[0] + ((field_entry_t)1 << 25)) >> 26;
    mul_results[0] -= carry[0] << 26;
    mul_results[1] += carry[0];

    dst[0] = (field_entry_t)mul_results[0];
    dst[1] = (field_entry_t)mul_results[1];
    dst[2] = (field_entry_t)mul_results[2];
    dst[3] = (field_entry_t)mul_results[3];
    dst[4] = (field_entry_t)mul_results[4];
    dst[5] = (field_entry_t)mul_results[5];
    dst[6] = (field_entry_t)mul_results[6];
    dst[7] = (field_entry_t)mul_results[7];
    dst[8] = (field_entry_t)mul_results[8];
    dst[9] = (field_entry_t)mul_results[9];
}

// source: supercop amd64-51
void decode_point(field_t dst, byte32_t src) {
    field_entry_t decode_results[10] = {0};

    decode_results[0] += (field_entry_t)src[0] << 0;
    decode_results[0] += (field_entry_t)src[1] << 8;
    decode_results[0] += (field_entry_t)src[2] << 16;
    decode_results[0] += ((field_entry_t)src[3] & 3) << 24;
    decode_results[1] = (field_entry_t)src[3] >> 2;
    decode_results[1] += (field_entry_t)src[4] << 6;
    decode_results[1] += (field_entry_t)src[5] << 14;
    decode_results[1] += ((field_entry_t)src[6] & 7) << 22;
    decode_results[2] = (field_entry_t)src[6] >> 3;
    decode_results[2] += (field_entry_t)src[7] << 5;
    decode_results[2] += (field_entry_t)src[8] << 13;
    decode_results[2] += ((field_entry_t)src[9] & 31) << 21;
    decode_results[3] = (field_entry_t)src[9] >> 5;
    decode_results[3] += (field_entry_t)src[10] << 3;
    decode_results[3] += (field_entry_t)src[11] << 11;
    decode_results[3] += ((field_entry_t)src[12] & 63) << 19;
    decode_results[4] = (field_entry_t)src[12] >> 6;
    decode_results[4] += (field_entry_t)src[13] << 2;
    decode_results[4] += (field_entry_t)src[14] << 10;
    decode_results[4] += (field_entry_t)src[15] << 18;
    decode_results[5] = (field_entry_t)src[16];
    decode_results[5] += (field_entry_t)src[17] << 8;
    decode_results[5] += (field_entry_t)src[18] << 16;
    decode_results[5] += ((field_entry_t)src[19] & 1) << 24;
    decode_results[6] = (field_entry_t)src[19] >> 1;
    decode_results[6] += (field_entry_t)src[20] << 7;
    decode_results[6] += (field_entry_t)src[21] << 15;
    decode_results[6] += ((field_entry_t)src[22] & 7) << 23;
    decode_results[7] = (field_entry_t)src[22] >> 3;
    decode_results[7] += (field_entry_t)src[23] << 5;
    decode_results[7] += (field_entry_t)src[24] << 13;
    decode_results[7] += ((field_entry_t)src[25] & 15) << 21;
    decode_results[8] = (field_entry_t)src[25] >> 4;
    decode_results[8] += (field_entry_t)src[26] << 4;
    decode_results[8] += (field_entry_t)src[27] << 12;
    decode_results[8] += ((field_entry_t)src[28] & 63) << 20;
    decode_results[9] = (field_entry_t)src[28] >> 6;
    decode_results[9] += (field_entry_t)src[29] << 2;
    decode_results[9] += (field_entry_t)src[30] << 10;
    decode_results[9] += ((field_entry_t)src[31] & 127) << 18;

    field_entry_t carry[10];
    carry[0] = (decode_results[0] + ((field_entry_t)1 << 25)) >> 26;
    decode_results[0] -= carry[0] << 26;
    decode_results[1] += carry[0];
    carry[1] = (decode_results[1] + ((field_entry_t)1 << 24)) >> 25;
    decode_results[1] -= carry[1] << 25;
    decode_results[2] += carry[1];
    carry[2] = (decode_results[2] + ((field_entry_t)1 << 25)) >> 26;
    decode_results[2] -= carry[2] << 26;
    decode_results[3] += carry[2];
    carry[3] = (decode_results[3] + ((field_entry_t)1 << 24)) >> 25;
    decode_results[3] -= carry[3] << 25;
    decode_results[4] += carry[3];
    carry[4] = (decode_results[4] + ((field_entry_t)1 << 25)) >> 26;
    decode_results[4] -= carry[4] << 26;
    decode_results[5] += carry[4];
    carry[5] = (decode_results[5] + ((field_entry_t)1 << 24)) >> 25;
    decode_results[5] -= carry[5] << 25;
    decode_results[6] += carry[5];
    carry[6] = (decode_results[6] + ((field_entry_t)1 << 25)) >> 26;
    decode_results[6] -= carry[6] << 26;
    decode_results[7] += carry[6];
    carry[7] = (decode_results[7] + ((field_entry_t)1 << 24)) >> 25;
    decode_results[7] -= carry[7] << 25;
    decode_results[8] += carry[7];
    carry[8] = (decode_results[8] + ((field_entry_t)1 << 25)) >> 26;
    decode_results[8] -= carry[8] << 26;
    decode_results[9] += carry[8];
    carry[9] = (decode_results[9] + ((field_entry_t)1 << 24)) >> 25;
    decode_results[9] -= carry[9] << 25;
    decode_results[0] += carry[9] * 19;
    carry[0] = (decode_results[0] + ((field_entry_t)1 << 25)) >> 26;
    decode_results[0] -= carry[0] << 26;
    decode_results[1] += carry[0];

    dst[0] = (field_entry_t)decode_results[0];
    dst[1] = (field_entry_t)decode_results[1];
    dst[2] = (field_entry_t)decode_results[2];
    dst[3] = (field_entry_t)decode_results[3];
    dst[4] = (field_entry_t)decode_results[4];
    dst[5] = (field_entry_t)decode_results[5];
    dst[6] = (field_entry_t)decode_results[6];
    dst[7] = (field_entry_t)decode_results[7];
    dst[8] = (field_entry_t)decode_results[8];
    dst[9] = (field_entry_t)decode_results[9];
}

// source: supercop amd64-51
void encode_point(byte32_t dst, field_t src) {
    field_entry_mul_t carry[10];

    field_entry_t q = (19*src[9] + ((field_entry_t)1 << 24)) >> 25;

    q = (src[0] + q) >> 26;
    q = (src[1] + q) >> 25;
    q = (src[2] + q) >> 26;
    q = (src[3] + q) >> 25;
    q = (src[4] + q) >> 26;
    q = (src[5] + q) >> 25;
    q = (src[6] + q) >> 26;
    q = (src[7] + q) >> 25;
    q = (src[8] + q) >> 26;
    q = (src[9] + q) >> 25;
    src[0] += 19 * q;

    carry[0] = src[0] >> 26;
    src[0] -= carry[0] << 26;
    src[1] += carry[0];
    carry[1] = src[1] >> 25;
    src[1] -= carry[1] << 25;
    src[2] += carry[1];
    carry[2] = src[2] >> 26;
    src[2] -= carry[2] << 26;
    src[3] += carry[2];
    carry[3] = src[3] >> 25;
    src[3] -= carry[3] << 25;
    src[4] += carry[3];
    carry[4] = src[4] >> 26;
    src[4] -= carry[4] << 26;
    src[5] += carry[4];
    carry[5] = src[5] >> 25;
    src[5] -= carry[5] << 25;
    src[6] += carry[5];
    carry[6] = src[6] >> 26;
    src[6] -= carry[6] << 26;
    src[7] += carry[6];
    carry[7] = src[7] >> 25;
    src[7] -= carry[7] << 25;
    src[8] += carry[7];
    carry[8] = src[8] >> 26;
    src[8] -= carry[8] << 26;
    src[9] += carry[8];
    carry[9] = src[9] >> 25;
    src[9] -= carry[9] << 25;

    dst[0] = (input_t)(src[0]);
    dst[1] = (input_t)(src[0] >> 8);
    dst[2] = (input_t)(src[0] >> 16);
    dst[3] = (input_t)(src[0] >> 24);
    dst[3] |= (input_t)(src[1] << 2);
    dst[4] = (input_t)(src[1] >> 6);
    dst[5] = (input_t)(src[1] >> 14);
    dst[6] = (input_t)(src[1] >> 22);
    dst[6] |= (input_t)(src[2] << 3);
    dst[7] = (input_t)(src[2] >> 5);
    dst[8] = (input_t)(src[2] >> 13);
    dst[9] = (input_t)(src[2] >> 21);
    dst[9] |= (input_t)(src[3] << 5);
    dst[10] = (input_t)(src[3] >> 3);
    dst[11] = (input_t)(src[3] >> 11);
    dst[12] = (input_t)(src[3] >> 19);
    dst[12] |= (input_t)(src[4] << 6);
    dst[13] = (input_t)(src[4] >> 2);
    dst[14] = (input_t)(src[4] >> 10);
    dst[15] = (input_t)(src[4] >> 18);
    dst[16] = (input_t)(src[4] >> 26);
    dst[16] |= (input_t)(src[5]);
    dst[17] = (input_t)(src[5] >> 8);
    dst[18] = (input_t)(src[5] >> 16);
    dst[19] = (input_t)(src[5] >> 24);
    dst[19] |= (input_t)(src[6] << 1);
    dst[20] = (input_t)(src[6] >> 7);
    dst[21] = (input_t)(src[6] >> 15);
    dst[22] = (input_t)(src[6] >> 23);
    dst[22] |= (input_t)(src[7] << 3);
    dst[23] = (input_t)(src[7] >> 5);
    dst[24] = (input_t)(src[7] >> 13);
    dst[25] = (input_t)(src[7] >> 21);
    dst[25] |= (input_t)(src[8] << 4);
    dst[26] = (input_t)(src[8] >> 4);
    dst[27] = (input_t)(src[8] >> 12);
    dst[28] = (input_t)(src[8] >> 20);
    dst[28] |= (input_t)(src[9] << 6);
    dst[29] = (input_t)(src[9] >> 2);
    dst[30] = (input_t)(src[9] >> 10);
    dst[31] = (input_t)(src[9] >> 18);
}

// swap (a, b) with (b, a) iff swap == 1.
void cswap(field_entry_t swap, field_t a, field_t b) {
    swap = -swap;

    field_entry_t t;
    t = swap & (a[0] ^ b[0]);
    a[0] ^= t;
    b[0] ^= t;
    t = swap & (a[1] ^ b[1]);
    a[1] ^= t;
    b[1] ^= t;
    t = swap & (a[2] ^ b[2]);
    a[2] ^= t;
    b[2] ^= t;
    t = swap & (a[3] ^ b[3]);
    a[3] ^= t;
    b[3] ^= t;
    t = swap & (a[4] ^ b[4]);
    a[4] ^= t;
    b[4] ^= t;
    t = swap & (a[5] ^ b[5]);
    a[5] ^= t;
    b[5] ^= t;
    t = swap & (a[6] ^ b[6]);
    a[6] ^= t;
    b[6] ^= t;
    t = swap & (a[7] ^ b[7]);
    a[7] ^= t;
    b[7] ^= t;
    t = swap & (a[8] ^ b[8]);
    a[8] ^= t;
    b[8] ^= t;
    t = swap & (a[9] ^ b[9]);
    a[9] ^= t;
    b[9] ^= t;
}

// taken from djb's original implementation
void field_invert(field_t dst, field_t src) {
    field_t z2, z9, z11, z2_5_0, z2_10_0, z2_20_0, z2_50_0, z2_100_0, t0, t1;
    int i;

    field_square(z2,src);           // 2
    field_square(t1,z2);            // 4
    field_square(t0,t1);            // 8
    field_mul(z9,t0,src);           // 9
    field_mul(z11,z9,z2);           // 11
    field_square(t0,z11);           // 22
    field_mul(z2_5_0,t0,z9);        // 2^5 - 2^0 = 31

    field_square(t0,z2_5_0);        // 2^6 - 2^1
    field_square(t1,t0);            // 2^7 - 2^2
    field_square(t0,t1);            // 2^8 - 2^3
    field_square(t1,t0);            // 2^9 - 2^4
    field_square(t0,t1);            // 2^10 - 2^5
    field_mul(z2_10_0,t0,z2_5_0);   // 2^10 - 2^0

    field_square(t0,z2_10_0);       // 2^11 - 2^1
    field_square(t1,t0);            // 2^12 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^20 - 2^10
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_20_0,t1,z2_10_0);  // 2^20 - 2^0

    field_square(t0,z2_20_0);       // 2^21 - 2^1
    field_square(t1,t0);            // 2^22 - 2^2
    for (i = 2;i < 20;i += 2) {     // 2^40 - 2^20
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_20_0);       // 2^40 - 2^0

    field_square(t1,t0);            // 2^41 - 2^1
    field_square(t0,t1);            // 2^42 - 2^2
    for (i = 2;i < 10;i += 2) {     // 2^50 - 2^10
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(z2_50_0,t0,z2_10_0);  // 2^50 - 2^0

    field_square(t0,z2_50_0);       // 2^51 - 2^1
    field_square(t1,t0);            // 2^52 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^100 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(z2_100_0,t1,z2_50_0); // 2^100 - 2^0

    field_square(t1,z2_100_0);      // 2^101 - 2^1
    field_square(t0,t1);            // 2^102 - 2^2
    for (i = 2;i < 100;i += 2) {    // 2^200 - 2^100
        field_square(t1,t0);
        field_square(t0,t1);
    }
    field_mul(t1,t0,z2_100_0);      // 2^200 - 2^0

    field_square(t0,t1);            // 2^201 - 2^1
    field_square(t1,t0);            // 2^202 - 2^2
    for (i = 2;i < 50;i += 2) {     // 2^250 - 2^50
        field_square(t0,t1);
        field_square(t1,t0);
    }
    field_mul(t0,t1,z2_50_0);       // 2^250 - 2^0

    field_square(t1,t0);            // 2^251 - 2^1
    field_square(t0,t1);            // 2^252 - 2^2
    field_square(t1,t0);            // 2^253 - 2^3
    field_square(t0,t1);            // 2^254 - 2^4
    field_square(t1,t0);            // 2^255 - 2^5
    field_mul(dst,t1,z11);          // 2^255 - 21
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
// see bernstein page 5, upper paragrpah for secret key definition
void decode_scalar(byte32_t dst, byte32_t src) {
    memcpy(dst, src, sizeof(byte32_t));
    dst[0] &= 248; // ensure multiple of 8 (248 = 1111 1000)
    dst[31] &= 127; // ensure biggest secret key <= 8*(2^251 - 1) = 2^254 - 1 (127 = 0111 1111)
    dst[31] |= 64; // ensure secret key offset of + 2^254 (64 = 0100 0000) 
}

// As per RFC 7748, Chapter 5
void curve_scalar_mult(field_t dst, byte32_t n, field_t P) {
    field_t x_1; memcpy(x_1, P, sizeof(field_t));
    field_t x_2 = { 1 };
    field_t z_2 = { 0 };
    field_t x_3; memcpy(x_3, P, sizeof(field_t));
    field_t z_3 = { 1 };
    field_entry_t swap = 0;

    for (int32_t i = 254; i >= 0; i--) {
        int32_t bit = (n[i / 8] >> (i & 7)) & 1;
        swap ^= bit;
        cswap(swap, x_2, x_3);
        cswap(swap, z_2, z_3);
        swap = bit;

        field_t A, AA, B, BB, E, C, D, DA, CB;
        field_t t0;

        field_add(A, x_2, z_2);     // A = x_2 + z_2
        field_square_avx_parallel_wrapper(AA, A);        // AA = A^2
        field_sub(B, x_2, z_2);     // B = x_2 - z_2
        field_square(BB, B);        // BB = B^2
        field_sub(E, AA, BB);       // E = AA - BB
        field_add(C, x_3, z_3);     // C = x_3 + z_3
        field_sub(D, x_3, z_3);     // D = x_3 - z_3
        field_mul_avx_parallel_wrapper(DA, D, A);        // DA = D * A
        field_mul(CB, C, B);        // CB = C * B
        field_add(t0, DA, CB);      // x_3 = (DA + CB)^2
        field_square(x_3, t0);
        field_sub(t0, DA, CB);      // z_3 = x_1 * (DA - CB)^2
        field_square(t0, t0);
        field_mul(z_3, t0, x_1);
        field_mul(x_2, AA, BB);     // x_2 = AA * BB
        field_mul_a24(t0, E);       // z_2 = E * (AA + a24 * E)
        field_add(t0, AA, t0);
        field_mul(z_2, E, t0);
    }

    cswap(swap, x_2, x_3);
    cswap(swap, z_2, z_3);
    field_invert(z_2, z_2);         // z_2 = z_2 ^-1
    field_mul(dst, x_2, z_2);       // dst = x_2 * z_2
}

void curve25519(byte32_t dst, byte32_t n, byte32_t P) {
    byte32_t scalar;
    decode_scalar(scalar, n);

    field_t base, result;
    decode_point(base, P);
    curve_scalar_mult(result, scalar, base);

    encode_point(dst, result);
}

int crypto_scalarmult(unsigned char * dst,
                      const unsigned char *n,
                      const unsigned char *P) {
    curve25519((uint8_t *) dst, (uint8_t *) n, (uint8_t *) P);
    return 0;
}

