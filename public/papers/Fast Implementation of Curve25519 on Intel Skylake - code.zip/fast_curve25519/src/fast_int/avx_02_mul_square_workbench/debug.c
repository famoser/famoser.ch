#include <immintrin.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdio.h>

#define debug 0

void print_m256i(__m256i value, char * description) {
    int64_t EF[4];
    _mm256_storeu_si256((__m256i*) EF, value);
    
    if (debug) {
        printf(description);
        printf(": %d, %d, %d, %d\n", EF[0], EF[1], EF[2], EF[3]);
    }
}

void print_m256i_array_entry(__m256i *value, int index, char * description) {
    int64_t EF[4];
    _mm256_storeu_si256((__m256i*) EF, value[index]);
    
    if (debug) {
        printf(description);
        printf("[%i]: %d, %d, %d, %d\n", index, EF[0], EF[1], EF[2], EF[3]);
    }
}

void print_newline() {
    if (debug) {
        printf("\n");
    }
}