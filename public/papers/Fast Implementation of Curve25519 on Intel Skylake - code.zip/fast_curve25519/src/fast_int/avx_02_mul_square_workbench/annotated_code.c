#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <assert.h>
#include <math.h>
#include <immintrin.h>
#include <inttypes.h>

void field_square_avx_parallel(__m256i res[5], __m256i AB_v[5]){
    __m256i vec_0101 = _mm256_set_epi64x(1,0,1,0);
    __m256i vec_0000 = _mm256_setzero_si256();
    
    __m256i Z[10];
    __m256i U[10];
    __m256i V[10];
    
    for (int i = 0; i < 5; ++i){
        // U2i <- (A,B)i
        U[2*i] = AB_v[i]; // [0, a_2i+1, 0, a_2i, 0, b_2i+1, 0, b_2i]

        // U2i+1 <- ALIGN((A,B)i+1mod5, (A,B)i)
        U[2*i + 1] = _mm256_blend_epi32(AB_v[(i + 1) % 5], AB_v[i], 0b00110011); // [0, a_2i+1, 0, a_2i+2, 0, b_2i+1, 0, b_2i+2]
        U[2*i + 1] = _mm256_permute4x64_epi64 (U[2*i + 1], 0b10110001); //shuffle [2301] // [0, a_2i+2, 0, a_2i+1, 0, b_2i+2, 0, b_2i+1]
    
        // U2i+1 <- SHLV(U2i+1, [0,1,0,1])
        U[2*i + 1] = _mm256_sllv_epi64(U[2*i + 1],vec_0101); // [0, a_2i+2, 0, 2*a_2i+1, 0, b_2i+2, 0, 2*b_2i+1]

        // V2i <- SHUF((A,B)i, 0)
        V[2*i] = _mm256_shuffle_epi32(AB_v[i], 0b11101110); // [0, a_2i, 0, a_2i, 0, b_2i, 0, b_2i]

        // V2i+1 <- SHUF((A,B)i, 1)
        V[2*i+1] = _mm256_shuffle_epi32(AB_v[i], 0b01000100); // [0, a_2i+1, 0, a_2i+1, 0, b_2i+1, 0, b_2i+1]
    }
    print_m256i(U[0], "U[0]");
    print_m256i(U[1], "U[1]");
    print_m256i(U[2], "U[2]");
    print_m256i(U[3], "U[3]");
    print_m256i(V[0], "V[0]");
    print_m256i(V[1], "V[1]");
    print_m256i(V[2], "V[2]");
    print_m256i(V[3], "V[3]");
    print_newline();

    for (int i = 0; i < 5; i++) {
        // T <- MUL(Ui, Vi)
        __m256i T = _mm256_mul_epi32(U[i], V[i]); // [a_i+1*a_i, a_i*a_i, b_i+1*b_i, b_i*b_i]
        print_m256i(T, "T");

        // Zi <- BLEND(T, [0,0,0,0], 1010)
        Z[i] = _mm256_blend_epi32(T, vec_0000, 0b00110011); // [0, a_i*a_i, 0, b_i*b_i]
        print_m256i_array_entry(Z, i, "Z");

        // W <- BLEND(T, [0,0,0,0], 0101)
        __m256i W = _mm256_blend_epi32(T, vec_0000, 0b11001100); // [a_i+1*a_i, 0, a_i+1*a_i, 0]
        print_m256i(W, "W");

        for (int j = 1; j <= i; j++) {
            // t <- i - j mod 10
            int t = ((i-j)%10+10)%10;
            int index = i + j;

            // W <- ADD(W, MUL(U_j, V_t))
            // print("W = W + U[%i] * V[%i]\n", index, t);
            W = _mm256_add_epi64(W, _mm256_mul_epi32(U[index], V[t])); 
            print_m256i(W, "W");
        }

        // Z_i <- ADD(Z_i, SHL(W, 1))
        Z[i] = _mm256_add_epi64(Z[i], _mm256_slli_epi64(W, 1));
        print_m256i_array_entry(Z, i, "Z");

        // S <- MUL(U_i+5, V_i+5)
        __m256i S = _mm256_mul_epi32(U[i+5], V[i+5]); // [a_i+6*a_i+5, a_i+5*a_i+5, b_i+6*b_i+5, b_i+5*b_i+5]
        print_m256i(S, "S");

        // Z_i+5 <- BLEND(S, [0,0,0,0], 1010)
        Z[i+5] = _mm256_blend_epi32(S, vec_0000, 0b00110011); // [0, a_i+5*a_i+5, 0, a_i+5*a_i+5]
        print_m256i_array_entry(Z, i+5, "Z");

        // X <- [0,0,0,0]
        __m256i X = _mm256_setzero_si256();

        for (int j = i+1; j < 5; j++) {
            // t <- i - j mod 10
            int t = ((i-j)%10+10)%10;
            int index = j+i;

            // X <- ADD(X, MUL(U_j, V_t))
            // printf("X = X + U[%i] * V[%i]\n", index, t);
            X = _mm256_add_epi64(X, _mm256_mul_epi32(U[index], V[t])); 
            print_m256i(X, "X");
        }

        // Z_i+5 <- ADD(Z_i+5, SHL(X, 1))
        Z[i+5] = _mm256_add_epi64(Z[i+5], _mm256_slli_epi64(X, 1));
        print_m256i_array_entry(Z, i+5, "Z");
        print_newline();
    }

    for(int i = 0; i < 5; ++i){
        __m256i Zi_times_16 = _mm256_slli_epi64(Z[i + 5], 4);
        __m256i Zi_times_2 = _mm256_slli_epi64(Z[i + 5], 1);
        __m256i Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
        res[i] = _mm256_add_epi64(Zi_times_19, Z[i + 5]);
        res[i] = _mm256_add_epi64(res[i], Z[i]);
    }
}