#include <stdio.h>
#include <string.h>
#include <immintrin.h>
#include <inttypes.h>

#include "crypto_scalarmult.h"
#include "radix51.h"

#define force_inline __attribute__((always_inline)) inline
#define a24 121665

typedef uint8_t byte32_t[32] __attribute__((aligned(32)));
typedef int32_t field_t[16] __attribute__((aligned(32)));

force_inline
void convert_field_t_to_interleaved(__m256i AC_v[5], field_t A, field_t C){
    int64_t AC[20];
    for(int i = 0; i < 5; i += 1){
        AC[4*i + 0] = A[i*2 + 1];
        AC[4*i + 1] = A[i*2];
        AC[4*i + 2] = C[i*2 + 1];
        AC[4*i + 3] = C[i*2];
    }
    AC_v[0] = _mm256_loadu_si256((__m256i*) (AC+0));
    AC_v[1] = _mm256_loadu_si256((__m256i*) (AC+4));
    AC_v[2] = _mm256_loadu_si256((__m256i*) (AC+8));
    AC_v[3] = _mm256_loadu_si256((__m256i*) (AC+12));
    AC_v[4] = _mm256_loadu_si256((__m256i*) (AC+16));
}


force_inline
__m256i custom__mm256_srai_epi64(__m256i arg, int8_t N){
    __m256i vec_0000 = _mm256_setzero_si256();

    __m256i logic_shifted_arg = _mm256_srli_epi64(arg, N);

    __m256i extension_bits = _mm256_cmpgt_epi64(vec_0000, arg);
    __m256i extension_bits_shifted = _mm256_slli_epi64(extension_bits, 64 - N);
    __m256i res = _mm256_or_si256(logic_shifted_arg, extension_bits_shifted);
    return res;
}

force_inline
void reduction_avx_parallel(__m256i * dst, __m256i * EF_v){

    __m256i EF_v0_shuffled = _mm256_shuffle_epi32(EF_v[0], 0b01001110);
    __m256i vec_h0h4 = _mm256_blend_epi32(EF_v0_shuffled,EF_v[2], 0b11001100);

    __m256i EF_v2_shuffled = _mm256_shuffle_epi32(EF_v[2], 0b01001110);
    __m256i vec_h1h5 = _mm256_blend_epi32(EF_v[0],EF_v2_shuffled, 0b11001100);


    __m256i EF_v1_shuffled = _mm256_shuffle_epi32(EF_v[1], 0b01001110);
    __m256i vec_h2h6 = _mm256_blend_epi32(EF_v1_shuffled,EF_v[3], 0b11001100);

    __m256i EF_v3_shuffled = _mm256_shuffle_epi32(EF_v[3], 0b01001110);
    __m256i vec_h3h7 = _mm256_blend_epi32(EF_v[1],EF_v3_shuffled, 0b11001100);

    __m256i vec_2pow25 = _mm256_set_epi64x(1 << 25,1 << 25,1 << 25,1 << 25);
    __m256i vec_2pow24 = _mm256_set_epi64x(1 << 24,1 << 24,1 << 24,1 << 24);
    // __m256i vec_25 = _mm256_set_epi64x(25,25,25,25);
    __m256i vec_26 = _mm256_set_epi64x(26,26,26,26);
    // __m256i vec_4 = _mm256_set_epi64x(4,4,4,4);
    // __m256i vec_1 = _mm256_set_epi64x(1,1,1,1);
    __m256i vec_0000 = _mm256_setzero_si256();


/*
int64_t increased_h0 = h0 + (1 << 25);
int64_t increased_h4 = h4 + (1 << 25);
int64_t carry0 = increased_h0 >> 26;
int64_t carry4 = increased_h4 >> 26;
h1 = h1 + carry0;
h5 = h5 + carry4;
int64_t lshifted_carry0 = carry0 << 26;
int64_t lshifted_carry4 = carry4 << 26;
h0 = h0 - lshifted_carry0;
h4 = h4 - lshifted_carry4;
*/
    __m256i increased_vec_h0h4 = _mm256_add_epi64(vec_h0h4, vec_2pow25);
    __m256i carry_h0h4 = custom__mm256_srai_epi64(increased_vec_h0h4, 26);
    vec_h1h5 = _mm256_add_epi64(vec_h1h5, carry_h0h4);
    __m256i lshifted_carry_h0h4 = _mm256_slli_epi64(carry_h0h4, 26);
    vec_h0h4 = _mm256_sub_epi64(vec_h0h4, lshifted_carry_h0h4);


/*
int64_t increased_h1 = h1 + (1 << 24);
int64_t increased_h5 = h5 + (1 << 24);
int64_t carry1 = increased_h1 >> 25;
int64_t carry5 = increased_h5 >> 25;
h2 = h2 + carry0;
h6 = h6 + carry4;
int64_t lshifted_carry1 = carry1 << 25;
int64_t lshifted_carry5 = carry5 << 25;
h1 = h1 - lshifted_carry1;
h5 = h5 - lshifted_carry5;
*/
    __m256i increased_vec_h1h5 = _mm256_add_epi64(vec_h1h5, vec_2pow24);
    __m256i carry_h1h5 = custom__mm256_srai_epi64(increased_vec_h1h5, 25);
    vec_h2h6 = _mm256_add_epi64(vec_h2h6, carry_h1h5);
    __m256i lshifted_carry_h1h5 = _mm256_slli_epi64(carry_h1h5, 25);
    vec_h1h5 = _mm256_sub_epi64(vec_h1h5, lshifted_carry_h1h5);

/*
int64_t increased_h2 = h2 + (1 << 25);
int64_t increased_h6 = h6 + (1 << 25);
int64_t carry2 = increased_h2 >> 26;
int64_t carry6 = increased_h6 >> 26;
h3 = h3 + carry2;
h7 = h7 + carry6;
int64_t lshifted_carry2 = carry2 << 26;
int64_t lshifted_carry6 = carry6 << 26;
h2 = h2 - lshifted_carry2;
h6 = h6 - lshifted_carry6;
*/
    __m256i increased_vec_h2h6 = _mm256_add_epi64(vec_h2h6, vec_2pow25);
    __m256i carry_h2h6 = custom__mm256_srai_epi64(increased_vec_h2h6, 26);
    vec_h3h7 = _mm256_add_epi64(vec_h3h7, carry_h2h6);
    __m256i lshifted_carry_h2h6 = _mm256_slli_epi64(carry_h2h6, 26);
    vec_h2h6 = _mm256_sub_epi64(vec_h2h6, lshifted_carry_h2h6);


//here load h4h8 and h5h9 with h4 and h5 from carried vecs

    __m256i vec_h0h4_shuffled = _mm256_shuffle_epi32(vec_h0h4, 0b01001110);
    __m256i vec_h4h8 = _mm256_blend_epi32(vec_h0h4_shuffled,EF_v[4], 0b11001100);

    __m256i vec_h9h5 = _mm256_blend_epi32(EF_v[4],vec_h1h5, 0b11001100);
    __m256i vec_h5h9 = _mm256_shuffle_epi32(vec_h9h5, 0b01001110);

//here do next two blocks

/*
int64_t increased_h3 = h3 + (1 << 24);
int64_t increased_h7 = h7 + (1 << 24);
int64_t carry3 = increased_h3 >> 25;
int64_t carry7 = increased_h7 >> 25;
h4 = h4 + carry3;
h8 = h8 + carry7;
int64_t lshifted_carry3 = carry3 << 25;
int64_t lshifted_carry7 = carry7 << 25;
h3 = h3 - lshifted_carry3;
h7 = h7 - lshifted_carry7;
*/
    __m256i increased_vec_h3h7 = _mm256_add_epi64(vec_h3h7, vec_2pow24);
    __m256i carry_h3h7 = custom__mm256_srai_epi64(increased_vec_h3h7, 25);
    vec_h4h8 = _mm256_add_epi64(vec_h4h8, carry_h3h7);
    __m256i lshifted_carry_h3h7 = _mm256_slli_epi64(carry_h3h7, 25);
    vec_h3h7 = _mm256_sub_epi64(vec_h3h7, lshifted_carry_h3h7);

/*
int64_t increased_h4b = h4 + (1 << 25);
int64_t increased_h8 = h8 + (1 << 25);
int64_t carry4b = increased_h4b >> 26;
int64_t carry8 = increased_h8 >> 26;
h5 = h5 + carry4b;
h9 = h9 + carry8;
int64_t lshifted_carry4b = carry4b << 26;
int64_t lshifted_carry8 = carry8 << 26;
h4 = h4 - lshifted_carry4b;
h8 = h8 - lshifted_carry8;
*/
    __m256i increased_vec_h4h8 = _mm256_add_epi64(vec_h4h8, vec_2pow25);
    __m256i carry_h4h8 = custom__mm256_srai_epi64(increased_vec_h4h8, 26);
    vec_h5h9 = _mm256_add_epi64(vec_h5h9, carry_h4h8);
    __m256i lshifted_carry_h4h8 = _mm256_slli_epi64(carry_h4h8, 26);
    vec_h4h8 = _mm256_sub_epi64(vec_h4h8, lshifted_carry_h4h8);

/*
int64_t increased_h9 = h9 + (1 << 24);
int64_t carry9 = increased_h9 >> 25;
int64_t carry9_times19 = carry9 * 19;
h0 = h0 + carry9_times19;
int64_t lshifted_carry9 = carry9_times19 << 25;
h9 = h9 - lshifted_carry9;
*/
    __m256i increased_vec_h9 = _mm256_add_epi64(vec_h5h9, vec_2pow24);
    __m256i carry_h9 = custom__mm256_srai_epi64(increased_vec_h9, 25);
    /*
    __m256i vec_0_19_0_19 = _mm256_set_epi64x(0,19,0,19);
    __m256i carry_h9_times_19 = _mm256_mul_epi32(carry_h9, vec_0_19_0_19);
    __m256i carry_h9_times_19_shuffled = _mm256_shuffle_epi32(carry_h9_times_19, 0b01001110);
    */
    __m256i carry_h9_blended = _mm256_blend_epi32(vec_0000,carry_h9, 0b11001100);
    carry_h9 = carry_h9_blended;

    __m256i sixteen_carry_h9 = _mm256_slli_epi64 (carry_h9, 4);
    __m256i two_carry_h9 = _mm256_slli_epi64 (carry_h9, 1);
    __m256i eighteen_carry_h9 = _mm256_add_epi64(sixteen_carry_h9, two_carry_h9);
    __m256i nineteen_carry_h9 = _mm256_add_epi64(eighteen_carry_h9, carry_h9);

    __m256i carry_h9_times_19_shuffled = _mm256_shuffle_epi32(nineteen_carry_h9, 0b01001110);

    vec_h0h4 = _mm256_add_epi64(vec_h0h4, carry_h9_times_19_shuffled);



    __m256i lshifted_carry_h9 = _mm256_slli_epi64(carry_h9_blended, 25);
    vec_h5h9 = _mm256_sub_epi64(vec_h5h9, lshifted_carry_h9);

/*
int64_t increased_h0b = h0 + (1 << 25);
int64_t carry0b = increased_h0b >> 26;
h1 = h1 + carry0b;
int64_t lshifted_carry0b = carry0b << 26;
h0 = h0 - lshifted_carry0b;
*/
    __m256i increased_vec_h0 = _mm256_add_epi64(vec_h0h4, vec_2pow25);
    __m256i carry_h0 = _mm256_srlv_epi64(increased_vec_h0, vec_26);
//__m256i carry_h0_blended _mm256_blend_epi32(carry_h0,vec_0000, 0b11001100); // we take h4 and h5 from different vecs
    vec_h1h5 = _mm256_add_epi64(vec_h1h5, carry_h0);
    __m256i lshifted_carry_h0 = _mm256_sllv_epi64(carry_h0, vec_26);
    vec_h0h4 = _mm256_sub_epi64(vec_h0h4, lshifted_carry_h0);

/*
h0h4 -> h0
h1h5 -> h1
h2h6 -> h2, h6
h3h7 -> h3, h7
h4h8 -> h4, h8
h5h9 -> h5, h9
*/

    __m256i vec_h4h0 = _mm256_shuffle_epi32(vec_h0h4, 0b01001110);
    dst[0] = _mm256_blend_epi32(vec_h1h5,vec_h4h0, 0b11001100);

    __m256i vec_h6h2 = _mm256_shuffle_epi32(vec_h2h6, 0b01001110);
    dst[1] = _mm256_blend_epi32(vec_h3h7,vec_h6h2, 0b11001100);

    __m256i vec_h8h4 = _mm256_shuffle_epi32(vec_h4h8, 0b01001110);
    dst[2] = _mm256_blend_epi32(vec_h5h9,vec_h8h4, 0b11001100);

    __m256i vec_h7h3 = _mm256_shuffle_epi32(vec_h3h7, 0b01001110);
    dst[3] = _mm256_blend_epi32(vec_h7h3,vec_h2h6, 0b11001100);

    vec_h9h5 = _mm256_shuffle_epi32(vec_h5h9, 0b01001110);
    dst[4] = _mm256_blend_epi32(vec_h9h5,vec_h4h8, 0b11001100);
}

force_inline
void field_mul_avx_parallel(__m256i res[5], __m256i AC_v[5], __m256i BD_v[5]) {
    __m256i vec_0101 = _mm256_set_epi64x(1,0,1,0);
    __m256i vec_0000 = _mm256_setzero_si256();

    __m256i BD_vp[5];
    __m256i Z[10];

    /*[[[cog
    for i in range(0, 10):
        cog.outl(f'Z[{i}] = _mm256_setzero_si256();')
    ]]]*/
    Z[0] = _mm256_setzero_si256();
    Z[1] = _mm256_setzero_si256();
    Z[2] = _mm256_setzero_si256();
    Z[3] = _mm256_setzero_si256();
    Z[4] = _mm256_setzero_si256();
    Z[5] = _mm256_setzero_si256();
    Z[6] = _mm256_setzero_si256();
    Z[7] = _mm256_setzero_si256();
    Z[8] = _mm256_setzero_si256();
    Z[9] = _mm256_setzero_si256();
    //[[[end]]]

    /*[[[cog
    for i in range(0, 5):
        cog.outl(f'BD_vp[{i}] = _mm256_blend_epi32(BD_v[{(i + 1) % 5}], BD_v[{i}], 0b00110011);')
        cog.outl(f'BD_vp[{i}] = _mm256_permute4x64_epi64(BD_vp[{i}], 0b10110001);')
        cog.outl(f'BD_vp[{i}] = _mm256_sllv_epi64(BD_vp[{i}],vec_0101);')
    ]]]*/
    BD_vp[0] = _mm256_blend_epi32(BD_v[1], BD_v[0], 0b00110011);
    BD_vp[0] = _mm256_permute4x64_epi64(BD_vp[0], 0b10110001);
    BD_vp[0] = _mm256_sllv_epi64(BD_vp[0],vec_0101);
    BD_vp[1] = _mm256_blend_epi32(BD_v[2], BD_v[1], 0b00110011);
    BD_vp[1] = _mm256_permute4x64_epi64(BD_vp[1], 0b10110001);
    BD_vp[1] = _mm256_sllv_epi64(BD_vp[1],vec_0101);
    BD_vp[2] = _mm256_blend_epi32(BD_v[3], BD_v[2], 0b00110011);
    BD_vp[2] = _mm256_permute4x64_epi64(BD_vp[2], 0b10110001);
    BD_vp[2] = _mm256_sllv_epi64(BD_vp[2],vec_0101);
    BD_vp[3] = _mm256_blend_epi32(BD_v[4], BD_v[3], 0b00110011);
    BD_vp[3] = _mm256_permute4x64_epi64(BD_vp[3], 0b10110001);
    BD_vp[3] = _mm256_sllv_epi64(BD_vp[3],vec_0101);
    BD_vp[4] = _mm256_blend_epi32(BD_v[0], BD_v[4], 0b00110011);
    BD_vp[4] = _mm256_permute4x64_epi64(BD_vp[4], 0b10110001);
    BD_vp[4] = _mm256_sllv_epi64(BD_vp[4],vec_0101);
    //[[[end]]]

    /*[[[cog
    cog.outl(f'__m256i U;')
    cog.outl(f'__m256i V;')
    cog.outl(f'__m256i W;')

    for i in range(0, 5):
        cog.outl(f'U = _mm256_shuffle_epi32(AC_v[{i}], 0b11101110);')

        for j in range(0, 5):
            cog.outl(f'Z[{i + j}] = _mm256_add_epi64(Z[{i + j}], _mm256_mul_epi32(U, BD_v[{j}]));')

        cog.outl(f'V = _mm256_shuffle_epi32(AC_v[{i}], 0b01000100);')

        for j in range(0, 4):
            cog.outl(f'Z[{i + j + 1}] = _mm256_add_epi64(Z[{i + j + 1}], _mm256_mul_epi32(V, BD_vp[{j}]));')

        cog.outl(f'W = _mm256_mul_epi32(V, BD_vp[{4}]);')
        cog.outl(f'Z[{i}] = _mm256_add_epi64(Z[{i}], _mm256_blend_epi32(W, vec_0000, 0b11001100));')
        cog.outl(f'Z[{i + 5}] = _mm256_add_epi64(Z[{i + 5}], _mm256_blend_epi32(W, vec_0000, 0b00110011));')
    ]]]*/
    __m256i U;
    __m256i V;
    __m256i W;
    U = _mm256_shuffle_epi32(AC_v[0], 0b11101110);
    Z[0] = _mm256_add_epi64(Z[0], _mm256_mul_epi32(U, BD_v[0]));
    Z[1] = _mm256_add_epi64(Z[1], _mm256_mul_epi32(U, BD_v[1]));
    Z[2] = _mm256_add_epi64(Z[2], _mm256_mul_epi32(U, BD_v[2]));
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(U, BD_v[3]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(U, BD_v[4]));
    V = _mm256_shuffle_epi32(AC_v[0], 0b01000100);
    Z[1] = _mm256_add_epi64(Z[1], _mm256_mul_epi32(V, BD_vp[0]));
    Z[2] = _mm256_add_epi64(Z[2], _mm256_mul_epi32(V, BD_vp[1]));
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(V, BD_vp[2]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(V, BD_vp[3]));
    W = _mm256_mul_epi32(V, BD_vp[4]);
    Z[0] = _mm256_add_epi64(Z[0], _mm256_blend_epi32(W, vec_0000, 0b11001100));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_blend_epi32(W, vec_0000, 0b00110011));
    U = _mm256_shuffle_epi32(AC_v[1], 0b11101110);
    Z[1] = _mm256_add_epi64(Z[1], _mm256_mul_epi32(U, BD_v[0]));
    Z[2] = _mm256_add_epi64(Z[2], _mm256_mul_epi32(U, BD_v[1]));
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(U, BD_v[2]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(U, BD_v[3]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(U, BD_v[4]));
    V = _mm256_shuffle_epi32(AC_v[1], 0b01000100);
    Z[2] = _mm256_add_epi64(Z[2], _mm256_mul_epi32(V, BD_vp[0]));
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(V, BD_vp[1]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(V, BD_vp[2]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(V, BD_vp[3]));
    W = _mm256_mul_epi32(V, BD_vp[4]);
    Z[1] = _mm256_add_epi64(Z[1], _mm256_blend_epi32(W, vec_0000, 0b11001100));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_blend_epi32(W, vec_0000, 0b00110011));
    U = _mm256_shuffle_epi32(AC_v[2], 0b11101110);
    Z[2] = _mm256_add_epi64(Z[2], _mm256_mul_epi32(U, BD_v[0]));
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(U, BD_v[1]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(U, BD_v[2]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(U, BD_v[3]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_mul_epi32(U, BD_v[4]));
    V = _mm256_shuffle_epi32(AC_v[2], 0b01000100);
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(V, BD_vp[0]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(V, BD_vp[1]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(V, BD_vp[2]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_mul_epi32(V, BD_vp[3]));
    W = _mm256_mul_epi32(V, BD_vp[4]);
    Z[2] = _mm256_add_epi64(Z[2], _mm256_blend_epi32(W, vec_0000, 0b11001100));
    Z[7] = _mm256_add_epi64(Z[7], _mm256_blend_epi32(W, vec_0000, 0b00110011));
    U = _mm256_shuffle_epi32(AC_v[3], 0b11101110);
    Z[3] = _mm256_add_epi64(Z[3], _mm256_mul_epi32(U, BD_v[0]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(U, BD_v[1]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(U, BD_v[2]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_mul_epi32(U, BD_v[3]));
    Z[7] = _mm256_add_epi64(Z[7], _mm256_mul_epi32(U, BD_v[4]));
    V = _mm256_shuffle_epi32(AC_v[3], 0b01000100);
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(V, BD_vp[0]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(V, BD_vp[1]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_mul_epi32(V, BD_vp[2]));
    Z[7] = _mm256_add_epi64(Z[7], _mm256_mul_epi32(V, BD_vp[3]));
    W = _mm256_mul_epi32(V, BD_vp[4]);
    Z[3] = _mm256_add_epi64(Z[3], _mm256_blend_epi32(W, vec_0000, 0b11001100));
    Z[8] = _mm256_add_epi64(Z[8], _mm256_blend_epi32(W, vec_0000, 0b00110011));
    U = _mm256_shuffle_epi32(AC_v[4], 0b11101110);
    Z[4] = _mm256_add_epi64(Z[4], _mm256_mul_epi32(U, BD_v[0]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(U, BD_v[1]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_mul_epi32(U, BD_v[2]));
    Z[7] = _mm256_add_epi64(Z[7], _mm256_mul_epi32(U, BD_v[3]));
    Z[8] = _mm256_add_epi64(Z[8], _mm256_mul_epi32(U, BD_v[4]));
    V = _mm256_shuffle_epi32(AC_v[4], 0b01000100);
    Z[5] = _mm256_add_epi64(Z[5], _mm256_mul_epi32(V, BD_vp[0]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_mul_epi32(V, BD_vp[1]));
    Z[7] = _mm256_add_epi64(Z[7], _mm256_mul_epi32(V, BD_vp[2]));
    Z[8] = _mm256_add_epi64(Z[8], _mm256_mul_epi32(V, BD_vp[3]));
    W = _mm256_mul_epi32(V, BD_vp[4]);
    Z[4] = _mm256_add_epi64(Z[4], _mm256_blend_epi32(W, vec_0000, 0b11001100));
    Z[9] = _mm256_add_epi64(Z[9], _mm256_blend_epi32(W, vec_0000, 0b00110011));
    //[[[end]]]

    /*[[[cog
    modulo_after_multiplication("res", "Z")
    ]]]*/
    __m256i Zi_times_16;
    __m256i Zi_times_2;
    __m256i Zi_times_19;
    Zi_times_16 = _mm256_slli_epi64(Z[5], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[5], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[0] = _mm256_add_epi64(Zi_times_19, Z[5]);
    res[0] = _mm256_add_epi64(res[0], Z[0]);
    Zi_times_16 = _mm256_slli_epi64(Z[6], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[6], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[1] = _mm256_add_epi64(Zi_times_19, Z[6]);
    res[1] = _mm256_add_epi64(res[1], Z[1]);
    Zi_times_16 = _mm256_slli_epi64(Z[7], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[7], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[2] = _mm256_add_epi64(Zi_times_19, Z[7]);
    res[2] = _mm256_add_epi64(res[2], Z[2]);
    Zi_times_16 = _mm256_slli_epi64(Z[8], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[8], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[3] = _mm256_add_epi64(Zi_times_19, Z[8]);
    res[3] = _mm256_add_epi64(res[3], Z[3]);
    Zi_times_16 = _mm256_slli_epi64(Z[9], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[9], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[4] = _mm256_add_epi64(Zi_times_19, Z[9]);
    res[4] = _mm256_add_epi64(res[4], Z[4]);
    //[[[end]]]

    reduction_avx_parallel(res, res);
}

force_inline
void field_square_avx_parallel(__m256i res[5], __m256i AB_v[5]){
    __m256i vec_0101 = _mm256_set_epi64x(1,0,1,0);
    __m256i vec_0000 = _mm256_setzero_si256();

    __m256i Z[10];
    __m256i U[10];
    __m256i V[10];

    /*[[[cog
    for i in range(0, 5):
        cog.outl(f'U[{2*i}] = AB_v[{i}];')
        cog.outl(f'U[{2*i + 1}] = _mm256_blend_epi32(AB_v[{(i + 1) % 5}], AB_v[{i}], 0b00110011);')
        cog.outl(f'U[{2*i + 1}] = _mm256_permute4x64_epi64(U[{2*i + 1}], 0b10110001);')
        cog.outl(f'U[{2*i + 1}] = _mm256_sllv_epi64(U[{2*i + 1}], vec_0101);')
        cog.outl(f'V[{2*i}] = _mm256_shuffle_epi32(AB_v[{i}], 0b11101110);')
        cog.outl(f'V[{2*i+1}] = _mm256_shuffle_epi32(AB_v[{i}], 0b01000100);')
    ]]]*/
    U[0] = AB_v[0];
    U[1] = _mm256_blend_epi32(AB_v[1], AB_v[0], 0b00110011);
    U[1] = _mm256_permute4x64_epi64(U[1], 0b10110001);
    U[1] = _mm256_sllv_epi64(U[1], vec_0101);
    V[0] = _mm256_shuffle_epi32(AB_v[0], 0b11101110);
    V[1] = _mm256_shuffle_epi32(AB_v[0], 0b01000100);
    U[2] = AB_v[1];
    U[3] = _mm256_blend_epi32(AB_v[2], AB_v[1], 0b00110011);
    U[3] = _mm256_permute4x64_epi64(U[3], 0b10110001);
    U[3] = _mm256_sllv_epi64(U[3], vec_0101);
    V[2] = _mm256_shuffle_epi32(AB_v[1], 0b11101110);
    V[3] = _mm256_shuffle_epi32(AB_v[1], 0b01000100);
    U[4] = AB_v[2];
    U[5] = _mm256_blend_epi32(AB_v[3], AB_v[2], 0b00110011);
    U[5] = _mm256_permute4x64_epi64(U[5], 0b10110001);
    U[5] = _mm256_sllv_epi64(U[5], vec_0101);
    V[4] = _mm256_shuffle_epi32(AB_v[2], 0b11101110);
    V[5] = _mm256_shuffle_epi32(AB_v[2], 0b01000100);
    U[6] = AB_v[3];
    U[7] = _mm256_blend_epi32(AB_v[4], AB_v[3], 0b00110011);
    U[7] = _mm256_permute4x64_epi64(U[7], 0b10110001);
    U[7] = _mm256_sllv_epi64(U[7], vec_0101);
    V[6] = _mm256_shuffle_epi32(AB_v[3], 0b11101110);
    V[7] = _mm256_shuffle_epi32(AB_v[3], 0b01000100);
    U[8] = AB_v[4];
    U[9] = _mm256_blend_epi32(AB_v[0], AB_v[4], 0b00110011);
    U[9] = _mm256_permute4x64_epi64(U[9], 0b10110001);
    U[9] = _mm256_sllv_epi64(U[9], vec_0101);
    V[8] = _mm256_shuffle_epi32(AB_v[4], 0b11101110);
    V[9] = _mm256_shuffle_epi32(AB_v[4], 0b01000100);
    //[[[end]]]

    /*[[[cog
    cog.outl(f'__m256i T;')
    cog.outl(f'__m256i W;')
    cog.outl(f'__m256i S;')
    cog.outl(f'__m256i X;')

    for i in range(0, 5):
        cog.outl(f'T = _mm256_mul_epi32(U[{i}], V[{i}]);')
        cog.outl(f'Z[{i}] = _mm256_blend_epi32(T, vec_0000, 0b00110011);')
        cog.outl(f'W = _mm256_blend_epi32(T, vec_0000, 0b11001100);')

        for j in range(1, i+1):
            cog.outl(f'W = _mm256_add_epi64(W, _mm256_mul_epi32(U[{i+j}], V[{(i-j)%10}]));')

        cog.outl(f'Z[{i}] = _mm256_add_epi64(Z[{i}], _mm256_slli_epi64(W, 1));')
        cog.outl(f'S = _mm256_mul_epi32(U[{i+5}], V[{i+5}]);')
        cog.outl(f'Z[{i+5}] = _mm256_blend_epi32(S, vec_0000, 0b00110011);')
        cog.outl(f'X = _mm256_setzero_si256();')

        for j in range(i+1, 5):
            cog.outl(f'X = _mm256_add_epi64(X, _mm256_mul_epi32(U[{j+i}], V[{(i-j)%10}]));')

        cog.outl(f'Z[{i+5}] = _mm256_add_epi64(Z[{i+5}], _mm256_slli_epi64(X, 1));')
    ]]]*/
    __m256i T;
    __m256i W;
    __m256i S;
    __m256i X;
    T = _mm256_mul_epi32(U[0], V[0]);
    Z[0] = _mm256_blend_epi32(T, vec_0000, 0b00110011);
    W = _mm256_blend_epi32(T, vec_0000, 0b11001100);
    Z[0] = _mm256_add_epi64(Z[0], _mm256_slli_epi64(W, 1));
    S = _mm256_mul_epi32(U[5], V[5]);
    Z[5] = _mm256_blend_epi32(S, vec_0000, 0b00110011);
    X = _mm256_setzero_si256();
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[1], V[9]));
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[2], V[8]));
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[3], V[7]));
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[4], V[6]));
    Z[5] = _mm256_add_epi64(Z[5], _mm256_slli_epi64(X, 1));
    T = _mm256_mul_epi32(U[1], V[1]);
    Z[1] = _mm256_blend_epi32(T, vec_0000, 0b00110011);
    W = _mm256_blend_epi32(T, vec_0000, 0b11001100);
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[2], V[0]));
    Z[1] = _mm256_add_epi64(Z[1], _mm256_slli_epi64(W, 1));
    S = _mm256_mul_epi32(U[6], V[6]);
    Z[6] = _mm256_blend_epi32(S, vec_0000, 0b00110011);
    X = _mm256_setzero_si256();
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[3], V[9]));
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[4], V[8]));
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[5], V[7]));
    Z[6] = _mm256_add_epi64(Z[6], _mm256_slli_epi64(X, 1));
    T = _mm256_mul_epi32(U[2], V[2]);
    Z[2] = _mm256_blend_epi32(T, vec_0000, 0b00110011);
    W = _mm256_blend_epi32(T, vec_0000, 0b11001100);
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[3], V[1]));
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[4], V[0]));
    Z[2] = _mm256_add_epi64(Z[2], _mm256_slli_epi64(W, 1));
    S = _mm256_mul_epi32(U[7], V[7]);
    Z[7] = _mm256_blend_epi32(S, vec_0000, 0b00110011);
    X = _mm256_setzero_si256();
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[5], V[9]));
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[6], V[8]));
    Z[7] = _mm256_add_epi64(Z[7], _mm256_slli_epi64(X, 1));
    T = _mm256_mul_epi32(U[3], V[3]);
    Z[3] = _mm256_blend_epi32(T, vec_0000, 0b00110011);
    W = _mm256_blend_epi32(T, vec_0000, 0b11001100);
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[4], V[2]));
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[5], V[1]));
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[6], V[0]));
    Z[3] = _mm256_add_epi64(Z[3], _mm256_slli_epi64(W, 1));
    S = _mm256_mul_epi32(U[8], V[8]);
    Z[8] = _mm256_blend_epi32(S, vec_0000, 0b00110011);
    X = _mm256_setzero_si256();
    X = _mm256_add_epi64(X, _mm256_mul_epi32(U[7], V[9]));
    Z[8] = _mm256_add_epi64(Z[8], _mm256_slli_epi64(X, 1));
    T = _mm256_mul_epi32(U[4], V[4]);
    Z[4] = _mm256_blend_epi32(T, vec_0000, 0b00110011);
    W = _mm256_blend_epi32(T, vec_0000, 0b11001100);
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[5], V[3]));
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[6], V[2]));
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[7], V[1]));
    W = _mm256_add_epi64(W, _mm256_mul_epi32(U[8], V[0]));
    Z[4] = _mm256_add_epi64(Z[4], _mm256_slli_epi64(W, 1));
    S = _mm256_mul_epi32(U[9], V[9]);
    Z[9] = _mm256_blend_epi32(S, vec_0000, 0b00110011);
    X = _mm256_setzero_si256();
    Z[9] = _mm256_add_epi64(Z[9], _mm256_slli_epi64(X, 1));
    //[[[end]]]

    /*[[[cog
    modulo_after_multiplication("res", "Z")
    ]]]*/
    __m256i Zi_times_16;
    __m256i Zi_times_2;
    __m256i Zi_times_19;
    Zi_times_16 = _mm256_slli_epi64(Z[5], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[5], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[0] = _mm256_add_epi64(Zi_times_19, Z[5]);
    res[0] = _mm256_add_epi64(res[0], Z[0]);
    Zi_times_16 = _mm256_slli_epi64(Z[6], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[6], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[1] = _mm256_add_epi64(Zi_times_19, Z[6]);
    res[1] = _mm256_add_epi64(res[1], Z[1]);
    Zi_times_16 = _mm256_slli_epi64(Z[7], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[7], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[2] = _mm256_add_epi64(Zi_times_19, Z[7]);
    res[2] = _mm256_add_epi64(res[2], Z[2]);
    Zi_times_16 = _mm256_slli_epi64(Z[8], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[8], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[3] = _mm256_add_epi64(Zi_times_19, Z[8]);
    res[3] = _mm256_add_epi64(res[3], Z[3]);
    Zi_times_16 = _mm256_slli_epi64(Z[9], 4);
    Zi_times_2 = _mm256_slli_epi64(Z[9], 1);
    Zi_times_19 = _mm256_add_epi64(Zi_times_16, Zi_times_2);
    res[4] = _mm256_add_epi64(Zi_times_19, Z[9]);
    res[4] = _mm256_add_epi64(res[4], Z[4]);
    //[[[end]]]

    reduction_avx_parallel(res, res);
}

force_inline
void field_mul_a24_avx_parallel(__m256i res[5], __m256i EE_v[5]){
    __m256i vec_a24 = _mm256_set_epi64x(a24,a24,a24,a24);
    res[0] = _mm256_mul_epi32(EE_v[0], vec_a24);
    res[1] = _mm256_mul_epi32(EE_v[1], vec_a24);
    res[2] = _mm256_mul_epi32(EE_v[2], vec_a24);
    res[3] = _mm256_mul_epi32(EE_v[3], vec_a24);
    res[4] = _mm256_mul_epi32(EE_v[4], vec_a24);

    reduction_avx_parallel(res, res);
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
// see bernstein page 5, upper paragrpah for secret key definition
void decode_scalar(byte32_t dst, byte32_t src) {
    memcpy(dst, src, sizeof(byte32_t));
    dst[0] &= 248; // ensure multiple of 8 (248 = 1111 1000)
    dst[31] &= 127; // ensure biggest secret key <= 8*(2^251 - 1) = 2^254 - 1 (127 = 0111 1111)
    dst[31] |= 64; // ensure secret key offset of + 2^254 (64 = 0100 0000)
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
int64_t load3(uint8_t *in) {
    int64_t r = 0;
    r |= ((int64_t) in[0]);
    r |= ((int64_t) in[1]) << 8;
    r |= ((int64_t) in[2]) << 16;
    return r;
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
int64_t load4(uint8_t *in) {
    int64_t r = 0;
    r |= ((int64_t) in[0]);
    r |= ((int64_t) in[1]) << 8;
    r |= ((int64_t) in[2]) << 16;
    r |= ((int64_t) in[3]) << 24;
    return r;
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void decode_point(field_t dst, byte32_t src) {
    int64_t h0 = load4(src);
    int64_t h1 = load3(src+4) << 6;
    int64_t h2 = load3(src+7) << 5;
    int64_t h3 = load3(src+10) << 3;
    int64_t h4 = load3(src+13) << 2;
    int64_t h5 = load4(src+16);
    int64_t h6 = load3(src+20) << 7;
    int64_t h7 = load3(src+23) << 5;
    int64_t h8 = load3(src+26) << 4;
    int64_t h9 = (load3(src+29) & 0x7fffff) << 2;

    int64_t carry[10] = { 0 };
    carry[9] = (h9 + (1<<24)) >> 25;
    h0 += carry[9] * 19;
    h9 -= carry[9] << 25;
    carry[1] = (h1 + (1<<24)) >> 25;
    h2 += carry[1];
    h1 -= carry[1] << 25;
    carry[3] = (h3 + (1<<24)) >> 25;
    h4 += carry[3];
    h3 -= carry[3] << 25;
    carry[5] = (h5 + (1<<24)) >> 25;
    h6 += carry[5];
    h5 -= carry[5] << 25;
    carry[7] = (h7 + (1<<24)) >> 25;
    h8 += carry[7];
    h7 -= carry[7] << 25;

    carry[0] = (h0 + (1<<25)) >> 26;
    h1 += carry[0];
    h0 -= carry[0] << 26;
    carry[2] = (h2 + (1<<25)) >> 26;
    h3 += carry[2];
    h2 -= carry[2] << 26;
    carry[4] = (h4 + (1<<25)) >> 26;
    h5 += carry[4];
    h4 -= carry[4] << 26;
    carry[6] = (h6 + (1<<25)) >> 26;
    h7 += carry[6];
    h6 -= carry[6] << 26;
    carry[8] = (h8 + (1<<25)) >> 26;
    h9 += carry[8];
    h8 -= carry[8] << 26;

    dst[0] = (int32_t) h0;
    dst[1] = (int32_t) h1;
    dst[2] = (int32_t) h2;
    dst[3] = (int32_t) h3;
    dst[4] = (int32_t) h4;
    dst[5] = (int32_t) h5;
    dst[6] = (int32_t) h6;
    dst[7] = (int32_t) h7;
    dst[8] = (int32_t) h8;
    dst[9] = (int32_t) h9;
}

// source: https://github.com/golang/crypto/blob/master/curve25519/curve25519_generic.go
void encode_point(byte32_t dst, field_t src) {
    int32_t carry[10];

    int32_t q = (19*src[9] + (1 << 24)) >> 25;
    q = (src[0] + q) >> 26;
    q = (src[1] + q) >> 25;
    q = (src[2] + q) >> 26;
    q = (src[3] + q) >> 25;
    q = (src[4] + q) >> 26;
    q = (src[5] + q) >> 25;
    q = (src[6] + q) >> 26;
    q = (src[7] + q) >> 25;
    q = (src[8] + q) >> 26;
    q = (src[9] + q) >> 25;

    // Goal: Output h-(2^255-19)q, which is between 0 and 2^255-20.
    src[0] += 19 * q;
    // Goal: Output h-2^255 q, which is between 0 and 2^255-20.

    carry[0] = src[0] >> 26;
    src[1] += carry[0];
    src[0] -= carry[0] << 26;
    carry[1] = src[1] >> 25;
    src[2] += carry[1];
    src[1] -= carry[1] << 25;
    carry[2] = src[2] >> 26;
    src[3] += carry[2];
    src[2] -= carry[2] << 26;
    carry[3] = src[3] >> 25;
    src[4] += carry[3];
    src[3] -= carry[3] << 25;
    carry[4] = src[4] >> 26;
    src[5] += carry[4];
    src[4] -= carry[4] << 26;
    carry[5] = src[5] >> 25;
    src[6] += carry[5];
    src[5] -= carry[5] << 25;
    carry[6] = src[6] >> 26;
    src[7] += carry[6];
    src[6] -= carry[6] << 26;
    carry[7] = src[7] >> 25;
    src[8] += carry[7];
    src[7] -= carry[7] << 25;
    carry[8] = src[8] >> 26;
    src[9] += carry[8];
    src[8] -= carry[8] << 26;
    carry[9] = src[9] >> 25;
    src[9] -= carry[9] << 25;
    // h10 = carry9

    // Goal: Output h[0]+...+2^255 h10-2^255 q, which is between 0 and 2^255-20.
    // Have h[0]+...+2^230 h[9] between 0 and 2^255-1;
    // evidently 2^255 h10-2^255 q = 0.
    // Goal: Output h[0]+...+2^230 h[9].

    dst[0] = (uint8_t) (src[0] >> 0);
    dst[1] = (uint8_t) (src[0] >> 8);
    dst[2] = (uint8_t) (src[0] >> 16);
    dst[3] = (uint8_t) ((src[0] >> 24) | (src[1] << 2));
    dst[4] = (uint8_t) (src[1] >> 6);
    dst[5] = (uint8_t) (src[1] >> 14);
    dst[6] = (uint8_t) ((src[1] >> 22) | (src[2] << 3));
    dst[7] = (uint8_t) (src[2] >> 5);
    dst[8] = (uint8_t) (src[2] >> 13);
    dst[9] = (uint8_t) ((src[2] >> 21) | (src[3] << 5));
    dst[10] = (uint8_t) (src[3] >> 3);
    dst[11] = (uint8_t) (src[3] >> 11);
    dst[12] = (uint8_t) ((src[3] >> 19) | (src[4] << 6));
    dst[13] = (uint8_t) (src[4] >> 2);
    dst[14] = (uint8_t) (src[4] >> 10);
    dst[15] = (uint8_t) (src[4] >> 18);
    dst[16] = (uint8_t) (src[5] >> 0);
    dst[17] = (uint8_t) (src[5] >> 8);
    dst[18] = (uint8_t) (src[5] >> 16);
    dst[19] = (uint8_t) ((src[5] >> 24) | (src[6] << 1));
    dst[20] = (uint8_t) (src[6] >> 7);
    dst[21] = (uint8_t) (src[6] >> 15);
    dst[22] = (uint8_t) ((src[6] >> 23) | (src[7] << 3));
    dst[23] = (uint8_t) (src[7] >> 5);
    dst[24] = (uint8_t) (src[7] >> 13);
    dst[25] = (uint8_t) ((src[7] >> 21) | (src[8] << 4));
    dst[26] = (uint8_t) (src[8] >> 4);
    dst[27] = (uint8_t) (src[8] >> 12);
    dst[28] = (uint8_t) ((src[8] >> 20) | (src[9] << 6));
    dst[29] = (uint8_t) (src[9] >> 2);
    dst[30] = (uint8_t) (src[9] >> 10);
    dst[31] = (uint8_t) (src[9] >> 18);
}

// swap (a, b) with (b, a) iff swap == 1.
force_inline
void cswap_avx(int32_t swap, __m256i a[3], __m256i b[3]) {
    __m256i swapv = _mm256_set1_epi64x(-swap);

    __m256i ab0_xor = _mm256_xor_si256(a[0], b[0]);
    __m256i ab1_xor = _mm256_xor_si256(a[1], b[1]);
    __m256i ab2_xor = _mm256_xor_si256(a[2], b[2]);

    __m256i t0 = _mm256_and_si256(swapv, ab0_xor);
    __m256i t1 = _mm256_and_si256(swapv, ab1_xor);
    __m256i t2 = _mm256_and_si256(swapv, ab2_xor);


    a[0] = _mm256_xor_si256(a[0], t0);
    a[1] = _mm256_xor_si256(a[1], t1);
    a[2] = _mm256_xor_si256(a[2], t2);

    b[0] = _mm256_xor_si256(b[0], t0);
    b[1] = _mm256_xor_si256(b[1], t1);
    b[2] = _mm256_xor_si256(b[2], t2);

}

force_inline
void interleave_two_avx_vectors(__m256i A_inter_B[5], __m256i A[3], __m256i B[3]){
    //gen a1,a0,b1,b0
    __m256i tmp_a0 = _mm256_shuffle_epi32(A[0], 0b01001110);
    __m256i tmp_b0 = _mm256_permute4x64_epi64(B[0], 0b00011011);
    A_inter_B[0] = _mm256_blend_epi32(tmp_a0,tmp_b0, 0b11110000);

    //gen a3,a2,b3,b2
    __m256i tmp_a1 = _mm256_permute4x64_epi64(A[0], 0b00011011);
    __m256i tmp_b1 = _mm256_shuffle_epi32(B[0], 0b01001110);
    A_inter_B[1] = _mm256_blend_epi32(tmp_a1,tmp_b1, 0b11110000);

    //gen a1,a0,b1,b0
    __m256i tmp_a2 = _mm256_shuffle_epi32(A[1], 0b01001110);
    __m256i tmp_b2 = _mm256_permute4x64_epi64(B[1], 0b00011011);
    A_inter_B[2] = _mm256_blend_epi32(tmp_a2,tmp_b2, 0b11110000);

    //gen a3,a2,b3,b2
    __m256i tmp_a3 = _mm256_permute4x64_epi64(A[1], 0b00011011);
    __m256i tmp_b3 = _mm256_shuffle_epi32(B[1], 0b01001110);
    A_inter_B[3] = _mm256_blend_epi32(tmp_a3,tmp_b3, 0b11110000);

    //gen a1,a0,b1,b0
    __m256i tmp_a4 = _mm256_shuffle_epi32(A[2], 0b01001110);
    __m256i tmp_b4 = _mm256_permute4x64_epi64(B[2], 0b00011011);
    A_inter_B[4] = _mm256_blend_epi32(tmp_a4,tmp_b4, 0b11110000);
}

force_inline
void gen_two_avx_from_interleaved(__m256i A[3], __m256i B[3], __m256i A_inter_B[5]){
    //gen a1,a0,b1,b0
    __m256i tmp_a0u = _mm256_shuffle_epi32(A_inter_B[0], 0b01001110);
    __m256i tmp_a0l = _mm256_permute4x64_epi64(A_inter_B[1], 0b00011011);
    A[0] = _mm256_blend_epi32(tmp_a0u,tmp_a0l, 0b11110000);

    __m256i tmp_a1u = _mm256_shuffle_epi32(A_inter_B[2], 0b01001110);
    __m256i tmp_a1l = _mm256_permute4x64_epi64(A_inter_B[3], 0b00011011);
    A[1] = _mm256_blend_epi32(tmp_a1u,tmp_a1l, 0b11110000);

    A[2] = _mm256_shuffle_epi32(A_inter_B[4], 0b01001110);

    __m256i tmp_b0u = _mm256_permute4x64_epi64(A_inter_B[0], 0b01001011);
    __m256i tmp_b0l = _mm256_shuffle_epi32(A_inter_B[1], 0b01001110);
    B[0] = _mm256_blend_epi32(tmp_b0u,tmp_b0l, 0b11110000);

    __m256i tmp_b1u = _mm256_permute4x64_epi64(A_inter_B[2], 0b01001011);
    __m256i tmp_b1l = _mm256_shuffle_epi32(A_inter_B[3], 0b01001110);
    B[1] = _mm256_blend_epi32(tmp_b1u,tmp_b1l, 0b11110000);

    B[2] = _mm256_permute4x64_epi64(A_inter_B[4], 0b01001011);
}

force_inline
void load_field_to_avx(__m256i dst[3], field_t src){
    int64_t src64[12];

    for(int i = 0; i < 10; ++i){
        src64[i] = (int64_t) src[i];
    }
    dst[0] = _mm256_loadu_si256((__m256i*) (src64 + 4*0));
    dst[1] = _mm256_loadu_si256((__m256i*) (src64 + 4*1));
    dst[2] = _mm256_loadu_si256((__m256i*) (src64 + 4*2));
}

force_inline
void store_avx_to_field(field_t dst, __m256i src[3]){
    int64_t dst64[12];
    _mm256_storeu_si256((__m256i*) (dst64 + 4*0), src[0]);
    _mm256_storeu_si256((__m256i*) (dst64 + 4*1), src[1]);
    _mm256_storeu_si256((__m256i*) (dst64 + 4*2), src[2]);

    for(int i = 0; i < 10; ++i){
        dst[i] = (int32_t) dst64[i];
    }
}

force_inline
void interleave_x_1_with_BB(__m256i x_1_inter_BB[5], __m256i x_1[3], __m256i BB[3]){
    __m256i tmp_b0 = _mm256_permute4x64_epi64(BB[0], 0b00011011);
    x_1_inter_BB[0] = _mm256_blend_epi32(x_1[0],tmp_b0, 0b11110000);

    __m256i tmp_b1 = _mm256_shuffle_epi32(BB[0], 0b01001110);
    x_1_inter_BB[1] = _mm256_blend_epi32(x_1[1],tmp_b1, 0b11110000);

    __m256i tmp_b2 = _mm256_permute4x64_epi64(BB[1], 0b00011011);
    x_1_inter_BB[2] = _mm256_blend_epi32(x_1[2],tmp_b2, 0b11110000);

    __m256i tmp_b3 = _mm256_shuffle_epi32(BB[1], 0b01001110);
    x_1_inter_BB[3] = _mm256_blend_epi32(x_1[3],tmp_b3, 0b11110000);

    __m256i tmp_b4 = _mm256_permute4x64_epi64(BB[2], 0b00011011);
    x_1_inter_BB[4] = _mm256_blend_epi32(x_1[4],tmp_b4, 0b11110000);
}

force_inline
void field_mul_a24_avx_single(__m256i res[3], __m256i E_v[3]){
    //TODO: implement more efficiently
    __m256i Ea24_inter_Ea24[5];
    __m256i E_inter_E[5];

    interleave_two_avx_vectors(E_inter_E, E_v, E_v);
    field_mul_a24_avx_parallel(Ea24_inter_Ea24, E_inter_E);
    gen_two_avx_from_interleaved(res, res, Ea24_inter_Ea24);
}

force_inline
void field_mul_avx_single(__m256i res[3], __m256i A_v[3], __m256i B_v[3]){
    __m256i A_inter_A[5];
    __m256i B_inter_B[5];
    __m256i res_inter_res[5];

    interleave_two_avx_vectors(A_inter_A, A_v, A_v);
    interleave_two_avx_vectors(B_inter_B, B_v, B_v);
    field_mul_avx_parallel(res_inter_res, A_inter_A, B_inter_B);
    gen_two_avx_from_interleaved(res, res, res_inter_res);
}



// As per RFC 7748, Chapter 5
void curve_scalar_mult(field_t dst_x_2, field_t dst_z_2, byte32_t n, field_t P) {
    field_t x_1; memcpy(x_1, P, sizeof(field_t));
    field_t x_2 = { 1 };
    field_t z_2 = { 0 };
    field_t x_3; memcpy(x_3, P, sizeof(field_t));
    field_t z_3 = { 1 };
    int32_t swap = 0;

    //loading stuff
    //---
    __m256i x_1_interleave_prepared[5];
    convert_field_t_to_interleaved(x_1_interleave_prepared, x_1, x_1);
    //---

    __m256i x_2_v[3];
    load_field_to_avx(x_2_v, x_2);

    __m256i x_3_v[3];
    load_field_to_avx(x_3_v, x_3);

    __m256i z_2_v[3];
    load_field_to_avx(z_2_v, z_2);

    __m256i z_3_v[3];
    load_field_to_avx(z_3_v, z_3);

    for (int32_t i = 254; i >= 0; i--) {
        int32_t bit = (n[i / 8] >> (i & 7)) & 1;
        swap ^= bit;

        //cswap(swap, x_2, x_3);
        //cswap(swap, z_2, z_3);


        cswap_avx(swap, x_2_v, x_3_v);
        cswap_avx(swap, z_2_v, z_3_v);

        swap = bit;
        /*
        field_t A, AA, B, BB, E, C, D, DA, CB;
        field_t t0, t1;
        field_t t_new0, t3;
        */
        // __m256i x_2_inter_x_3[5];
        // __m256i z_2_inter_z_3[5];
        // __m256i A_inter_C[5];
        // __m256i B_inter_D[5];
        __m256i D_inter_C[5];
        __m256i A_inter_B[5];
        __m256i DA_inter_CB[5];
        __m256i t1_inter_AA[5];
        __m256i x_1_inter_BB[5];
        __m256i z_3_inter_x_2[5];
        // __m256i A_inter_B_2[5];
        __m256i AA_inter_BB[5];
        __m256i x_3_inter_t1[5];
        __m256i t0_inter_t1[5];

        __m256i A_v[3];
        __m256i B_v[3];
        __m256i C_v[3];
        __m256i D_v[3];
        __m256i E_v[3];
        __m256i DA_v[3];
        __m256i CB_v[3];
        __m256i t0_v[3];
        __m256i t1_v[3];
        __m256i AA_v[3];
        __m256i BB_v[3];
        __m256i Ea24_v[3];
        __m256i t3_v[3];


        /*
        field_add(A, x_2, z_2);
        field_add(C, x_3, z_3);
        */
        A_v[0] = _mm256_add_epi64(x_2_v[0], z_2_v[0]);
        A_v[1] = _mm256_add_epi64(x_2_v[1], z_2_v[1]);
        A_v[2] = _mm256_add_epi64(x_2_v[2], z_2_v[2]);

        C_v[0] = _mm256_add_epi64(x_3_v[0], z_3_v[0]);
        C_v[1] = _mm256_add_epi64(x_3_v[1], z_3_v[1]);
        C_v[2] = _mm256_add_epi64(x_3_v[2], z_3_v[2]);

        /*
        field_sub(B, x_2, z_2);
        field_sub(D, x_3, z_3);
        */
        B_v[0] = _mm256_sub_epi64(x_2_v[0], z_2_v[0]);
        B_v[1] = _mm256_sub_epi64(x_2_v[1], z_2_v[1]);
        B_v[2] = _mm256_sub_epi64(x_2_v[2], z_2_v[2]);

        D_v[0] = _mm256_sub_epi64(x_3_v[0], z_3_v[0]);
        D_v[1] = _mm256_sub_epi64(x_3_v[1], z_3_v[1]);
        D_v[2] = _mm256_sub_epi64(x_3_v[2], z_3_v[2]);

        /*
        field_square(AA, A);
        field_square(BB, B);
        */
        interleave_two_avx_vectors(A_inter_B, A_v, B_v);
        field_square_avx_parallel(AA_inter_BB, A_inter_B);
        gen_two_avx_from_interleaved(AA_v, BB_v, AA_inter_BB);

        /*
        field_mul(DA, D, A);
        field_mul(CB, C, B);
        */
        interleave_two_avx_vectors(D_inter_C, D_v, C_v);
        field_mul_avx_parallel(DA_inter_CB, D_inter_C, A_inter_B);
        gen_two_avx_from_interleaved(DA_v, CB_v, DA_inter_CB);

        //field_add(t0, DA, CB);
        t0_v[0] = _mm256_add_epi64(DA_v[0], CB_v[0]);
        t0_v[1] = _mm256_add_epi64(DA_v[1], CB_v[1]);
        t0_v[2] = _mm256_add_epi64(DA_v[2], CB_v[2]);

        //field_sub(t1, DA, CB);
        t1_v[0] = _mm256_sub_epi64(DA_v[0], CB_v[0]);
        t1_v[1] = _mm256_sub_epi64(DA_v[1], CB_v[1]);
        t1_v[2] = _mm256_sub_epi64(DA_v[2], CB_v[2]);

        /*
        field_square(x_3, t0);
        field_square(t1, t1);
        */
        interleave_two_avx_vectors(t0_inter_t1, t0_v, t1_v);
        field_square_avx_parallel(x_3_inter_t1, t0_inter_t1);
        gen_two_avx_from_interleaved(x_3_v, t1_v, x_3_inter_t1);

        /*
        field_mul(z_3, t1, x_1);
        field_mul(x_2, AA, BB);
        */
        interleave_two_avx_vectors(t1_inter_AA, t1_v, AA_v);
        interleave_x_1_with_BB(x_1_inter_BB, x_1_interleave_prepared, BB_v);
        field_mul_avx_parallel(z_3_inter_x_2, t1_inter_AA, x_1_inter_BB);
        gen_two_avx_from_interleaved(z_3_v, x_2_v, z_3_inter_x_2);


        //field_sub(E, AA, BB);
        E_v[0] = _mm256_sub_epi64(AA_v[0], BB_v[0]);
        E_v[1] = _mm256_sub_epi64(AA_v[1], BB_v[1]);
        E_v[2] = _mm256_sub_epi64(AA_v[2], BB_v[2]);

        //field_mul_a24(t_new0, E);
        field_mul_a24_avx_single(Ea24_v, E_v);

        //field_add(t3, AA, t_new0);
        t3_v[0] = _mm256_add_epi64(AA_v[0], Ea24_v[0]);
        t3_v[1] = _mm256_add_epi64(AA_v[1], Ea24_v[1]);
        t3_v[2] = _mm256_add_epi64(AA_v[2], Ea24_v[2]);


        //field_mul(z_2, E, t3);
        field_mul_avx_single(z_2_v, E_v, t3_v);


    }

    cswap_avx(swap, x_2_v, x_3_v);
    cswap_avx(swap, z_2_v, z_3_v);
    store_avx_to_field(dst_x_2, x_2_v);
    store_avx_to_field(dst_z_2, z_2_v);
}

int crypto_scalarmult(unsigned char * dst,
                      const unsigned char *n,
                      const unsigned char *P) {
    byte32_t scalar;
    decode_scalar(scalar, (uint8_t *) n);

    field_t base, x_2, z_2;
    decode_point(base, (uint8_t *) P);
    curve_scalar_mult(x_2, z_2, scalar, base);

    byte32_t enc_x, enc_z;
    encode_point(enc_x, x_2);
    encode_point(enc_z, z_2);

    field51_t x, z;
    decode_point_51(x, enc_x);
    decode_point_51(z, enc_z);
    field_invert_51(z, z);
    field_mul_51(x, x, z);
    encode_point_51(dst, x);

    return 0;
}

