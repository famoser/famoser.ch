#include <inttypes.h>

#include "curve25519_basic.h"
#include "radix51.h"

void decode_point_51(field51_t dst, unsigned char *src) {
    dst[0] = *((const uint64_t *)(src)) & 0x7ffffffffffff;
    dst[1] = (*((const uint64_t *)(src+6)) >> 3) & 0x7ffffffffffff;
    dst[2] = (*((const uint64_t *)(src+12)) >> 6) & 0x7ffffffffffff;
    dst[3] = (*((const uint64_t *)(src+19)) >> 1) & 0x7ffffffffffff;
    dst[4] = (*((const uint64_t *)(src+25)) >> 4) & 0x7ffffffffffff;
}

void field_square_51(field51_t dst, field51_t src) {
    uint128_t t[5];
    uint64_t r0, r1, r2, r3, r4, c0, c1;
    uint64_t d0, d1, d2, d4, d419;

    r0 = src[0];
    r1 = src[1];
    r2 = src[2];
    r3 = src[3];
    r4 = src[4];

    d0 = r0 * 2;
    d1 = r1 * 2;
    d2 = r2 * 2 * 19;
    d419 = r4 * 19;
    d4 = d419 * 2;

    t[0] = ((uint128_t) r0) * r0 + ((uint128_t) d4) * r1 + (((uint128_t) d2) * (r3     ));
    t[1] = ((uint128_t) d0) * r1 + ((uint128_t) d4) * r2 + (((uint128_t) r3) * (r3 * 19));
    t[2] = ((uint128_t) d0) * r2 + ((uint128_t) r1) * r1 + (((uint128_t) d4) * (r3     ));
    t[3] = ((uint128_t) d0) * r3 + ((uint128_t) d1) * r2 + (((uint128_t) r4) * (d419   ));
    t[4] = ((uint128_t) d0) * r4 + ((uint128_t) d1) * r3 + (((uint128_t) r2) * (r2     ));

                    r0 = (uint64_t)t[0] & 0x7ffffffffffff; c0 = (uint64_t)(t[0] >> 51);
                    r3 = (uint64_t)t[3] & 0x7ffffffffffff; c1 = (uint64_t)(t[3] >> 51);
    t[1] += c0;     r1 = (uint64_t)t[1] & 0x7ffffffffffff; c0 = (uint64_t)(t[1] >> 51);
    t[4] += c1;     r4 = (uint64_t)t[4] & 0x7ffffffffffff; c1 = (uint64_t)(t[4] >> 51);
    t[2] += c0;     r2 = (uint64_t)t[2] & 0x7ffffffffffff; c0 = (uint64_t)(t[2] >> 51);
    r0 += c1 * 19;  c1 = r0 >> 51; r0 = r0 & 0x7ffffffffffff;
    r3 += c0;       c0 = r3 >> 51; r3 = r3 & 0x7ffffffffffff;
    r1 += c1;       c1 = r1 >> 51; r1 = r1 & 0x7ffffffffffff;
    r4 += c0;

    dst[0] = r0;
    dst[1] = r1;
    dst[2] = r2;
    dst[3] = r3;
    dst[4] = r4;
}

void field_mul_51(field51_t dst, field51_t a, field51_t b) {
    uint128_t t[5];
    uint64_t r0, r1, r2, r3, r4,
             s0, s1, s2, s3, s4,
             c0, c1;

    r0 = a[0];
    r1 = a[1];
    r2 = a[2];
    r3 = a[3];
    r4 = a[4];

    s0 = b[0];
    s1 = b[1];
    s2 = b[2];
    s3 = b[3];
    s4 = b[4];

    t[0] = ((uint128_t) r0) * s0;
    t[1] = ((uint128_t) r0) * s1 + ((uint128_t) r1) * s0;
    t[2] = ((uint128_t) r0) * s2 + ((uint128_t) r2) * s0 + ((uint128_t) r1) * s1;
    t[3] = ((uint128_t) r0) * s3 + ((uint128_t) r3) * s0 + ((uint128_t) r1) * s2 + ((uint128_t) r2) * s1;
    t[4] = ((uint128_t) r0) * s4 + ((uint128_t) r4) * s0 + ((uint128_t) r3) * s1 + ((uint128_t) r1) * s3 + ((uint128_t) r2) * s2;

    r4 *= 19;
    r1 *= 19;
    r2 *= 19;
    r3 *= 19;

    t[0] += ((uint128_t) r4) * s1 + ((uint128_t) r1) * s4 + ((uint128_t) r2) * s3 + ((uint128_t) r3) * s2;
    t[1] += ((uint128_t) r4) * s2 + ((uint128_t) r2) * s4 + ((uint128_t) r3) * s3;
    t[2] += ((uint128_t) r4) * s3 + ((uint128_t) r3) * s4;
    t[3] += ((uint128_t) r4) * s4;

                    r0 = (uint64_t)t[0] & 0x7ffffffffffff; c0 = (uint64_t)(t[0] >> 51);
                    r3 = (uint64_t)t[3] & 0x7ffffffffffff; c1 = (uint64_t)(t[3] >> 51);
    t[1] += c0;     r1 = (uint64_t)t[1] & 0x7ffffffffffff; c0 = (uint64_t)(t[1] >> 51);
    t[4] += c1;     r4 = (uint64_t)t[4] & 0x7ffffffffffff; c1 = (uint64_t)(t[4] >> 51);
    t[2] += c0;     r2 = (uint64_t)t[2] & 0x7ffffffffffff; c0 = (uint64_t)(t[2] >> 51);
    r0 += c1 * 19;  c1 = r0 >> 51; r0 = r0 & 0x7ffffffffffff;
    r3 += c0;       c0 = r3 >> 51; r3 = r3 & 0x7ffffffffffff;
    r1 += c1;       c1 = r1 >> 51; r1 = r1 & 0x7ffffffffffff;
    r4 += c0;

    dst[0] = r0;
    dst[1] = r1;
    dst[2] = r2;
    dst[3] = r3;
    dst[4] = r4;
}

void field_invert_51(field51_t dst, field51_t src) {
    field51_t z2, z9, z11, z2_5_0, z2_10_0, z2_20_0, z2_50_0, z2_100_0, t0, t1;
    int i;

    field_square_51(z2,src);            // 2
    field_square_51(t1,z2);             // 4
    field_square_51(t0,t1);             // 8
    field_mul_51(z9,t0,src);            // 9
    field_mul_51(z11,z9,z2);            // 11
    field_square_51(t0,z11);            // 22
    field_mul_51(z2_5_0,t0,z9);         // 2^5 - 2^0 = 31

    field_square_51(t0,z2_5_0);         // 2^6 - 2^1
    field_square_51(t1,t0);             // 2^7 - 2^2
    field_square_51(t0,t1);             // 2^8 - 2^3
    field_square_51(t1,t0);             // 2^9 - 2^4
    field_square_51(t0,t1);             // 2^10 - 2^5
    field_mul_51(z2_10_0,t0,z2_5_0);    // 2^10 - 2^0

    field_square_51(t0,z2_10_0);        // 2^11 - 2^1
    field_square_51(t1,t0);             // 2^12 - 2^2
    for (i = 2; i < 10; i += 2) {       // 2^20 - 2^10
        field_square_51(t0,t1);
        field_square_51(t1,t0);
    }
    field_mul_51(z2_20_0,t1,z2_10_0);   // 2^20 - 2^0

    field_square_51(t0,z2_20_0);        // 2^21 - 2^1
    field_square_51(t1,t0);             // 2^22 - 2^2
    for (i = 2; i < 20; i += 2) {       // 2^40 - 2^20
        field_square_51(t0,t1);
        field_square_51(t1,t0);
    }
    field_mul_51(t0,t1,z2_20_0);        // 2^40 - 2^0

    field_square_51(t1,t0);             // 2^41 - 2^1
    field_square_51(t0,t1);             // 2^42 - 2^2
    for (i = 2; i < 10; i += 2) {       // 2^50 - 2^10
        field_square_51(t1,t0);
        field_square_51(t0,t1);
    }
    field_mul_51(z2_50_0,t0,z2_10_0);   // 2^50 - 2^0

    field_square_51(t0,z2_50_0);        // 2^51 - 2^1
    field_square_51(t1,t0);             // 2^52 - 2^2
    for (i = 2; i < 50; i += 2) {       // 2^100 - 2^50
        field_square_51(t0,t1);
        field_square_51(t1,t0);
    }
    field_mul_51(z2_100_0,t1,z2_50_0);  // 2^100 - 2^0

    field_square_51(t1,z2_100_0);       // 2^101 - 2^1
    field_square_51(t0,t1);             // 2^102 - 2^2
    for (i = 2; i < 100; i += 2) {      // 2^200 - 2^100
        field_square_51(t1,t0);
        field_square_51(t0,t1);
    }
    field_mul_51(t1,t0,z2_100_0);       // 2^200 - 2^0

    field_square_51(t0,t1);             // 2^201 - 2^1
    field_square_51(t1,t0);             // 2^202 - 2^2
    for (i = 2; i < 50; i += 2) {       // 2^250 - 2^50
        field_square_51(t0,t1);
        field_square_51(t1,t0);
    }
    field_mul_51(t0,t1,z2_50_0);        // 2^250 - 2^0

    field_square_51(t1,t0);             // 2^251 - 2^1
    field_square_51(t0,t1);             // 2^252 - 2^2
    field_square_51(t1,t0);             // 2^253 - 2^3
    field_square_51(t0,t1);             // 2^254 - 2^4
    field_square_51(t1,t0);             // 2^255 - 2^5
    field_mul_51(dst,t1,z11);           // 2^255 - 21
}

void encode_point_51(unsigned char *dst, field51_t src) {
    uint128_t t[5];

    t[0] = src[0];
    t[1] = src[1];
    t[2] = src[2];
    t[3] = src[3];
    t[4] = src[4];

    t[1] += t[0] >> 51; t[0] &= 0x7ffffffffffff;
    t[2] += t[1] >> 51; t[1] &= 0x7ffffffffffff;
    t[3] += t[2] >> 51; t[2] &= 0x7ffffffffffff;
    t[4] += t[3] >> 51; t[3] &= 0x7ffffffffffff;
    t[0] += 19 * (t[4] >> 51); t[4] &= 0x7ffffffffffff;

    t[1] += t[0] >> 51; t[0] &= 0x7ffffffffffff;
    t[2] += t[1] >> 51; t[1] &= 0x7ffffffffffff;
    t[3] += t[2] >> 51; t[2] &= 0x7ffffffffffff;
    t[4] += t[3] >> 51; t[3] &= 0x7ffffffffffff;
    t[0] += 19 * (t[4] >> 51); t[4] &= 0x7ffffffffffff;

    /* now t is between 0 and 2^255-1, properly carried. */
    /* case 1: between 0 and 2^255-20. case 2: between 2^255-19 and 2^255-1. */

    t[0] += 19;

    t[1] += t[0] >> 51; t[0] &= 0x7ffffffffffff;
    t[2] += t[1] >> 51; t[1] &= 0x7ffffffffffff;
    t[3] += t[2] >> 51; t[2] &= 0x7ffffffffffff;
    t[4] += t[3] >> 51; t[3] &= 0x7ffffffffffff;
    t[0] += 19 * (t[4] >> 51); t[4] &= 0x7ffffffffffff;

    /* now between 19 and 2^255-1 in both cases, and offset by 19. */

    t[0] += 0x8000000000000 - 19;
    t[1] += 0x8000000000000 - 1;
    t[2] += 0x8000000000000 - 1;
    t[3] += 0x8000000000000 - 1;
    t[4] += 0x8000000000000 - 1;

    /* now between 2^255 and 2^256-20, and offset by 2^255. */

    t[1] += t[0] >> 51; t[0] &= 0x7ffffffffffff;
    t[2] += t[1] >> 51; t[1] &= 0x7ffffffffffff;
    t[3] += t[2] >> 51; t[2] &= 0x7ffffffffffff;
    t[4] += t[3] >> 51; t[3] &= 0x7ffffffffffff;
    t[4] &= 0x7ffffffffffff;

    *((uint64_t *)(dst)) = t[0] | (t[1] << 51);
    *((uint64_t *)(dst+8)) = (t[1] >> 13) | (t[2] << 38);
    *((uint64_t *)(dst+16)) = (t[2] >> 26) | (t[3] << 25);
    *((uint64_t *)(dst+24)) = (t[3] >> 39) | (t[4] << 12);
}
